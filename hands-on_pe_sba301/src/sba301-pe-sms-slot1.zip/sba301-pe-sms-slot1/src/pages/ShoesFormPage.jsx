/**
 * File: src/pages/ShoesFormPage.jsx
 * Mục đích: Màn hình create/edit Shoes dùng chung một page điều phối.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { useEffect, useState } from 'react';
import { Alert, Col, Row } from 'react-bootstrap';
import { useNavigate, useParams } from 'react-router-dom';
import ErrorAlert from '../components/ErrorAlert.jsx';
import LoadingSpinner from '../components/LoadingSpinner.jsx';
import ShoesForm from '../components/ShoesForm.jsx';
import {
  createShoes,
  getCategories,
  getShoesById,
  updateShoes,
} from '../services/shoesService.js';
import { getErrorMessage } from '../utils/errorUtils.js';
import {
  createEmptyShoesForm,
  mapFormToShoesRequest,
  mapShoesResponseToForm,
} from '../utils/shoesMapper.js';

/**
 * Component ShoesFormPage
 * @param {Object} props
 * @param {'create'|'edit'} props.mode - Xác định page đang tạo mới hay cập nhật.
 */
function ShoesFormPage({ mode }) {
  const navigate = useNavigate();
  const { id } = useParams();

  const [categories, setCategories] = useState([]);
  const [initialValues, setInitialValues] = useState(createEmptyShoesForm());
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  /**
   * useEffect loadFormData
   * Mục đích:
   * - Load category cho select box.
   * - Nếu là edit thì load thêm shoes detail.
   */
  useEffect(() => {
    const loadFormData = async () => {
      try {
        setLoading(true);
        setErrorMessage('');

        const categoryResponse = await getCategories();
        setCategories(Array.isArray(categoryResponse) ? categoryResponse : []);

        if (mode === 'edit' && id) {
          const shoesResponse = await getShoesById(id);
          setInitialValues(mapShoesResponseToForm(shoesResponse));
        }
      } catch (error) {
        setErrorMessage(getErrorMessage(error, 'Failed to load form data.'));
      } finally {
        setLoading(false);
      }
    };

    loadFormData();
  }, [mode, id]);

  /**
   * Hàm handleSubmit
   * Mục đích: Submit create hoặc update tuỳ theo mode.
   */
  const handleSubmit = async (formData) => {
    try {
      setSubmitting(true);
      setErrorMessage('');
      setSuccessMessage('');

      const payload = mapFormToShoesRequest(formData);

      if (mode === 'create') {
        await createShoes(payload);
        setSuccessMessage('Create successfully. Redirecting to list...');
      } else {
        await updateShoes(id, payload);
        setSuccessMessage('Update successfully. Redirecting to list...');
      }

      setTimeout(() => {
        navigate('/shoes');
      }, 600);
    } catch (error) {
      setErrorMessage(getErrorMessage(error, `Failed to ${mode} shoes.`));
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <LoadingSpinner message="Loading form..." />;
  }

  return (
    <div className="d-flex flex-column gap-3">
      <Row className="align-items-center">
        <Col>
          <h2 className="mb-1">{mode === 'create' ? 'Create Shoes' : 'Update Shoes'}</h2>
          <div className="text-muted">
            {mode === 'create'
              ? 'Enter shoes information to create a new record.'
              : 'Update the selected shoes information.'}
          </div>
        </Col>
      </Row>

      <ErrorAlert message={errorMessage} />
      {successMessage ? <Alert variant="success">{successMessage}</Alert> : null}

      <ShoesForm
        initialValues={initialValues}
        categories={categories}
        submitting={submitting}
        onSubmit={handleSubmit}
        submitLabel={mode === 'create' ? 'Create' : 'Update'}
      />
    </div>
  );
}

export default ShoesFormPage;
