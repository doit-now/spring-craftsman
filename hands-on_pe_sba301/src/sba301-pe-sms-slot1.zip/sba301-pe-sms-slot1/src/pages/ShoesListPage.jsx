/**
 * File: src/pages/ShoesListPage.jsx
 * Mục đích: Màn hình danh sách Shoes có phân trang, sort và xoá.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { useEffect, useState } from 'react';
import { Alert, Card, Col, Row } from 'react-bootstrap';
import ConfirmDeleteModal from '../components/ConfirmDeleteModal.jsx';
import EmptyState from '../components/EmptyState.jsx';
import ErrorAlert from '../components/ErrorAlert.jsx';
import LoadingSpinner from '../components/LoadingSpinner.jsx';
import PaginationBar from '../components/PaginationBar.jsx';
import ShoesFilterBar from '../components/ShoesFilterBar.jsx';
import ShoesTable from '../components/ShoesTable.jsx';
import { deleteShoes, getShoesPage } from '../services/shoesService.js';
import { getErrorMessage } from '../utils/errorUtils.js';

/**
 * Component ShoesListPage
 * Mục đích: Điều phối toàn bộ logic cho màn hình danh sách.
 */
function ShoesListPage() {
  const [query, setQuery] = useState({
    currentPage: 0,
    pageSize: 5,
    sortBy: 'shoesName',
    sortDir: 'asc',
  });

  const [pageData, setPageData] = useState({
    content: [],
    currentPage: 0,
    pageSize: 5,
    totalElements: 0,
    totalPages: 0,
    first: true,
    last: true,
  });

  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [selectedItem, setSelectedItem] = useState(null);
  const [deleting, setDeleting] = useState(false);

  /**
   * useEffect loadData
   * Mục đích:
   * - Lấy categories cho app.
   * - Lấy page shoes mỗi khi query thay đổi.
   */
  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        setErrorMessage('');

        const shoesPageResponse = await getShoesPage({
          page: query.currentPage,
          size: query.pageSize,
          sortBy: query.sortBy,
          direction: query.sortDir,
        });

        setPageData(shoesPageResponse);
      } catch (error) {
        setErrorMessage(getErrorMessage(error, 'Failed to load shoes list.'));
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [query]);

  /**
   * Hàm handlePageChange
   * Mục đích: Đổi trang đang xem.
   */
  const handlePageChange = (page) => {
    setQuery((previousState) => ({
      ...previousState,
      currentPage: page,
    }));
  };

  /**
   * Hàm handleDeleteConfirm
   * Mục đích: Xoá bản ghi và reload lại danh sách.
   */
  const handleDeleteConfirm = async () => {
    if (!selectedItem) {
      return;
    }

    try {
      setDeleting(true);
      setErrorMessage('');
      setSuccessMessage('');

      await deleteShoes(selectedItem.shoesId);

      setSelectedItem(null);
      setSuccessMessage('Delete successfully.');

      // Sau khi xoá, nên tính lại trang hiện tại tránh trường hợp trang bị rỗng hoàn toàn.
      setQuery((previousState) => ({
        ...previousState,
        currentPage:
          previousState.currentPage > 0 && pageData.content.length === 1
            ? previousState.currentPage - 1
            : previousState.currentPage,
      }));
    } catch (error) {
      setErrorMessage(getErrorMessage(error, 'Failed to delete shoes.'));
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return <LoadingSpinner message="Loading shoes list..." />;
  }

  return (
    <div className="d-flex flex-column gap-3">
      <Row className="align-items-center">
        <Col>
          <h2 className="mb-1">Shoes List</h2>
          <div className="text-muted">Manage shoes data with pagination and CRUD actions.</div>
        </Col>
      </Row>

      <ErrorAlert message={errorMessage} />
      {successMessage ? <Alert variant="success">{successMessage}</Alert> : null}

      <ShoesFilterBar query={query} onQueryChange={setQuery} />

      <Card className="shadow-sm border-0">
        <Card.Body>
          {pageData.content?.length ? (
            <>
              <ShoesTable items={pageData.content} onDeleteClick={setSelectedItem} />

              <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mt-3">
                <div className="text-muted small">
                  Total Elements: <strong>{pageData.totalElements}</strong> | Current Page:{' '}
                  <strong>{pageData.currentPage + 1}</strong> / <strong>{pageData.totalPages}</strong>
                </div>

                <PaginationBar
                  currentPage={pageData.currentPage}
                  totalPages={pageData.totalPages}
                  onPageChange={handlePageChange}
                />
              </div>
            </>
          ) : (
            <EmptyState
              title="No shoes found"
              description="There is no shoes data available for the current query."
            />
          )}
        </Card.Body>
      </Card>

      <ConfirmDeleteModal
        show={Boolean(selectedItem)}
        itemName={selectedItem?.shoesName}
        submitting={deleting}
        onClose={() => setSelectedItem(null)}
        onConfirm={handleDeleteConfirm}
      />
    </div>
  );
}

export default ShoesListPage;
