/**
 * File: src/App.jsx
 * Mục đích: Component gốc của toàn ứng dụng.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import AppRouter from './AppRouter.jsx';

/**
 * Component App
 * Mục đích: Trả về router tổng của hệ thống.
 */
function App() {
  return <AppRouter />;
}

export default App;
