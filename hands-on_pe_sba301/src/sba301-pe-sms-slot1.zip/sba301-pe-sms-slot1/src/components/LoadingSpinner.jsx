/**
 * File: src/components/LoadingSpinner.jsx
 * Mục đích: Hiển thị trạng thái đang tải dữ liệu.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { Spinner } from 'react-bootstrap';

/**
 * Component LoadingSpinner
 * @param {Object} props
 * @param {string} props.message - Nội dung mô tả trạng thái loading.
 */
function LoadingSpinner({ message = 'Loading data...' }) {
  return (
    <div className="d-flex flex-column align-items-center justify-content-center py-5 gap-3">
      <Spinner animation="border" role="status" />
      <div className="text-muted">{message}</div>
    </div>
  );
}

export default LoadingSpinner;
