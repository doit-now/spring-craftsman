/**
 * File: src/components/ErrorAlert.jsx
 * Mục đích: Hiển thị lỗi theo format thống nhất.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { Alert } from 'react-bootstrap';

/**
 * Component ErrorAlert
 * @param {Object} props
 * @param {string} props.message - Nội dung lỗi.
 */
function ErrorAlert({ message }) {
  if (!message) {
    return null;
  }

  return <Alert variant="danger">{message}</Alert>;
}

export default ErrorAlert;
