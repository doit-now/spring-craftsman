/**
 * File: src/components/ShoesFilterBar.jsx
 * Mục đích: Thanh điều khiển list gồm sort, page size và nút create.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { Button, Card, Col, Form, Row } from 'react-bootstrap';
import { Link } from 'react-router-dom';

/**
 * Component ShoesFilterBar
 * @param {Object} props
 * @param {Object} props.query - Trạng thái query hiện tại.
 * @param {Function} props.onQueryChange - Hàm cập nhật query.
 */
function ShoesFilterBar({ query, onQueryChange }) {
  /**
   * Hàm handleChange
   * Mục đích: Cập nhật từng field query theo tên input.
   */
  const handleChange = (event) => {
    const { name, value } = event.target;

    onQueryChange((previousState) => ({
      ...previousState,
      [name]: name === 'pageSize' ? Number(value) : value,
      currentPage: 0,
    }));
  };

  return (
    <Card className="shadow-sm border-0 mb-3">
      <Card.Body>
        <Row className="g-3 align-items-end">
          <Col md={4}>
            <Form.Group>
              <Form.Label>Sort By</Form.Label>
              <Form.Select name="sortBy" value={query.sortBy} onChange={handleChange}>
                <option value="shoesName">Shoes Name</option>
                <option value="price">Price</option>
                <option value="quantity">Quantity</option>
                <option value="manufacturer">Manufacturer</option>
                <option value="productionDate">Production Date</option>
                <option value="importDate">Import Date</option>
              </Form.Select>
            </Form.Group>
          </Col>

          <Col md={3}>
            <Form.Group>
              <Form.Label>Direction</Form.Label>
              <Form.Select name="sortDir" value={query.sortDir} onChange={handleChange}>
                <option value="asc">Ascending</option>
                <option value="desc">Descending</option>
              </Form.Select>
            </Form.Group>
          </Col>

          <Col md={2}>
            <Form.Group>
              <Form.Label>Page Size</Form.Label>
              <Form.Select name="pageSize" value={query.pageSize} onChange={handleChange}>
                <option value={5}>5</option>
                <option value={10}>10</option>
                <option value={20}>20</option>
              </Form.Select>
            </Form.Group>
          </Col>

          <Col md={3} className="d-grid">
            <Button as={Link} to="/shoes/create" variant="primary">
              Create Shoes
            </Button>
          </Col>
        </Row>
      </Card.Body>
    </Card>
  );
}

export default ShoesFilterBar;
