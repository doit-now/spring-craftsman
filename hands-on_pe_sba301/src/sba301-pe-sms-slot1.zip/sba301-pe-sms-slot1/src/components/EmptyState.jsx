/**
 * File: src/components/EmptyState.jsx
 * Mục đích: Hiển thị khi danh sách không có dữ liệu.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { Card } from 'react-bootstrap';

/**
 * Component EmptyState
 * @param {Object} props
 * @param {string} props.title - Tiêu đề vùng rỗng.
 * @param {string} props.description - Mô tả vùng rỗng.
 */
function EmptyState({ title = 'No data found', description = 'Please try again later.' }) {
  return (
    <Card className="text-center shadow-sm border-0">
      <Card.Body className="py-5">
        <Card.Title>{title}</Card.Title>
        <Card.Text className="text-muted">{description}</Card.Text>
      </Card.Body>
    </Card>
  );
}

export default EmptyState;
