/**
 * File: src/components/ConfirmDeleteModal.jsx
 * Mục đích: Hộp thoại xác nhận xoá bản ghi.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { Button, Modal } from 'react-bootstrap';

/**
 * Component ConfirmDeleteModal
 * @param {Object} props
 * @param {boolean} props.show - Có hiển thị modal hay không.
 * @param {string} props.itemName - Tên đối tượng cần xoá.
 * @param {boolean} props.submitting - Đang xử lý xoá hay không.
 * @param {Function} props.onClose - Đóng modal.
 * @param {Function} props.onConfirm - Xác nhận xoá.
 */
function ConfirmDeleteModal({ show, itemName, submitting, onClose, onConfirm }) {
  return (
    <Modal show={show} onHide={onClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>Delete Shoes</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        Are you sure you want to delete <strong>{itemName || 'this shoes item'}</strong>?
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onClose} disabled={submitting}>
          Cancel
        </Button>
        <Button variant="danger" onClick={onConfirm} disabled={submitting}>
          {submitting ? 'Deleting...' : 'Delete'}
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

export default ConfirmDeleteModal;
