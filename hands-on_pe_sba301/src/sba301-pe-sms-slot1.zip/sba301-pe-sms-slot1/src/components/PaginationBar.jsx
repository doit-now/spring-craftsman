/**
 * File: src/components/PaginationBar.jsx
 * Mục đích: Thanh phân trang dùng lại cho bảng dữ liệu.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { Pagination } from 'react-bootstrap';

/**
 * Hàm buildPageItems
 * Mục đích: Sinh ra danh sách số trang cần hiển thị, tránh render quá dài.
 * Kỹ thuật: Chỉ hiển thị một vùng trang xung quanh currentPage.
 */
function buildPageItems(currentPage, totalPages) {
  const pages = [];
  const start = Math.max(0, currentPage - 2);
  const end = Math.min(totalPages - 1, currentPage + 2);

  for (let page = start; page <= end; page += 1) {
    pages.push(page);
  }

  return pages;
}

/**
 * Component PaginationBar
 * @param {Object} props
 * @param {number} props.currentPage - Trang hiện tại theo index bắt đầu từ 0.
 * @param {number} props.totalPages - Tổng số trang.
 * @param {Function} props.onPageChange - Hàm đổi trang.
 */
function PaginationBar({ currentPage, totalPages, onPageChange }) {
  if (!totalPages || totalPages <= 1) {
    return null;
  }

  const pages = buildPageItems(currentPage, totalPages);

  return (
    <Pagination className="mb-0 flex-wrap">
      <Pagination.First onClick={() => onPageChange(0)} disabled={currentPage === 0} />
      <Pagination.Prev
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 0}
      />

      {pages.map((page) => (
        <Pagination.Item
          key={page}
          active={page === currentPage}
          onClick={() => onPageChange(page)}
        >
          {page + 1}
        </Pagination.Item>
      ))}

      <Pagination.Next
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage >= totalPages - 1}
      />
      <Pagination.Last
        onClick={() => onPageChange(totalPages - 1)}
        disabled={currentPage >= totalPages - 1}
      />
    </Pagination>
  );
}

export default PaginationBar;
