/**
 * File: src/components/ShoesTable.jsx
 * Mục đích: Bảng hiển thị danh sách Shoes.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { Button, Table } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { formatDateForDisplay } from '../utils/dateUtils.js';

/**
 * Component ShoesTable
 * @param {Object} props
 * @param {Array} props.items - Danh sách shoes.
 * @param {Function} props.onDeleteClick - Hàm mở modal xoá.
 */
function ShoesTable({ items, onDeleteClick }) {
  return (
    <Table striped bordered hover responsive className="align-middle mb-0">
      <thead className="table-dark">
        <tr>
          <th>ID</th>
          <th>Shoes Name</th>
          <th>Price</th>
          <th>Quantity</th>
          <th>Manufacturer</th>
          <th>Production Date</th>
          <th>Import Date</th>
          <th>Category</th>
          <th className="text-center">Actions</th>
        </tr>
      </thead>
      <tbody>
        {items.map((item) => (
          <tr key={item.shoesId}>
            <td>{item.shoesId}</td>
            <td>{item.shoesName}</td>
            <td>{item.price}</td>
            <td>{item.quantity}</td>
            <td>{item.manufacturer}</td>
            <td>{formatDateForDisplay(item.productionDate)}</td>
            <td>{formatDateForDisplay(item.importDate)}</td>
            <td>{item.categoryName}</td>
            <td className="text-center">
              <div className="d-flex gap-2 justify-content-center flex-wrap">
                <Button
                  as={Link}
                  to={`/shoes/${item.shoesId}/edit`}
                  variant="warning"
                  size="sm"
                >
                  Edit
                </Button>
                <Button
                  variant="danger"
                  size="sm"
                  onClick={() => onDeleteClick(item)}
                >
                  Delete
                </Button>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
}

export default ShoesTable;
