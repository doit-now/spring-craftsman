/**
 * File: src/components/ShoesForm.jsx
 * Mục đích: Form dùng chung cho cả create và edit Shoes.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { useMemo, useState } from 'react';
import { Button, Card, Col, Form, Row } from 'react-bootstrap';
import { Link } from 'react-router-dom';

/**
 * Hàm validateForm
 * Mục đích: Validate mức cơ bản ngay trên client để giảm lỗi submit không cần thiết.
 */
function validateForm(formData) {
  const errors = {};

  if (!formData.shoesName.trim()) {
    errors.shoesName = 'Shoes Name is required.';
  }

  if (formData.price === '' || Number(formData.price) < 0) {
    errors.price = 'Price must be greater than or equal to 0.';
  }

  if (formData.quantity === '' || Number(formData.quantity) < 0) {
    errors.quantity = 'Quantity must be greater than or equal to 0.';
  }

  if (!formData.manufacturer.trim()) {
    errors.manufacturer = 'Manufacturer is required.';
  }

  if (!formData.productionDate) {
    errors.productionDate = 'Production Date is required.';
  }

  if (!formData.importDate) {
    errors.importDate = 'Import Date is required.';
  }

  if (
    formData.productionDate &&
    formData.importDate &&
    new Date(formData.importDate) < new Date(formData.productionDate)
  ) {
    errors.importDate = 'Import Date must be later than or equal to Production Date.';
  }

  if (!formData.categoryId) {
    errors.categoryId = 'Category is required.';
  }

  return errors;
}

/**
 * Component ShoesForm
 * @param {Object} props
 * @param {Object} props.initialValues - Dữ liệu ban đầu của form.
 * @param {Array} props.categories - Danh sách category.
 * @param {boolean} props.submitting - Có đang submit hay không.
 * @param {Function} props.onSubmit - Hàm submit ra ngoài page.
 * @param {string} props.submitLabel - Nhãn nút submit.
 */
function ShoesForm({
  initialValues,
  categories,
  submitting,
  onSubmit,
  submitLabel = 'Save',
}) {
  const [formData, setFormData] = useState(initialValues);
  const [errors, setErrors] = useState({});

  /**
   * useMemo
   * Mục đích: Tính trạng thái form có category hay không.
   */
  const hasCategories = useMemo(() => categories.length > 0, [categories]);

  /**
   * Hàm handleChange
   * Mục đích: Đồng bộ input HTML vào state formData.
   */
  const handleChange = (event) => {
    const { name, value } = event.target;

    setFormData((previousState) => ({
      ...previousState,
      [name]: value,
    }));

    setErrors((previousErrors) => ({
      ...previousErrors,
      [name]: '',
    }));
  };

  /**
   * Hàm handleSubmit
   * Mục đích: Validate trước khi gọi hàm submit của page cha.
   */
  const handleSubmit = async (event) => {
    event.preventDefault();

    const validationErrors = validateForm(formData);
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      return;
    }

    await onSubmit(formData);
  };

  return (
    <Card className="shadow-sm border-0">
      <Card.Body>
        <Form onSubmit={handleSubmit}>
          <Row className="g-3">
            <Col md={6}>
              <Form.Group>
                <Form.Label>Shoes Name</Form.Label>
                <Form.Control
                  name="shoesName"
                  value={formData.shoesName}
                  onChange={handleChange}
                  isInvalid={Boolean(errors.shoesName)}
                />
                <Form.Control.Feedback type="invalid">{errors.shoesName}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group>
                <Form.Label>Manufacturer</Form.Label>
                <Form.Control
                  name="manufacturer"
                  value={formData.manufacturer}
                  onChange={handleChange}
                  isInvalid={Boolean(errors.manufacturer)}
                />
                <Form.Control.Feedback type="invalid">
                  {errors.manufacturer}
                </Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={4}>
              <Form.Group>
                <Form.Label>Price</Form.Label>
                <Form.Control
                  name="price"
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.price}
                  onChange={handleChange}
                  isInvalid={Boolean(errors.price)}
                />
                <Form.Control.Feedback type="invalid">{errors.price}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={4}>
              <Form.Group>
                <Form.Label>Quantity</Form.Label>
                <Form.Control
                  name="quantity"
                  type="number"
                  min="0"
                  step="1"
                  value={formData.quantity}
                  onChange={handleChange}
                  isInvalid={Boolean(errors.quantity)}
                />
                <Form.Control.Feedback type="invalid">{errors.quantity}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={4}>
              <Form.Group>
                <Form.Label>Category</Form.Label>
                <Form.Select
                  name="categoryId"
                  value={formData.categoryId}
                  onChange={handleChange}
                  isInvalid={Boolean(errors.categoryId)}
                  disabled={!hasCategories}
                >
                  <option value="">Select category</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.categoryName}
                    </option>
                  ))}
                </Form.Select>
                <Form.Control.Feedback type="invalid">{errors.categoryId}</Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group>
                <Form.Label>Production Date</Form.Label>
                <Form.Control
                  name="productionDate"
                  type="date"
                  value={formData.productionDate}
                  onChange={handleChange}
                  isInvalid={Boolean(errors.productionDate)}
                />
                <Form.Control.Feedback type="invalid">
                  {errors.productionDate}
                </Form.Control.Feedback>
              </Form.Group>
            </Col>

            <Col md={6}>
              <Form.Group>
                <Form.Label>Import Date</Form.Label>
                <Form.Control
                  name="importDate"
                  type="date"
                  value={formData.importDate}
                  onChange={handleChange}
                  isInvalid={Boolean(errors.importDate)}
                />
                <Form.Control.Feedback type="invalid">{errors.importDate}</Form.Control.Feedback>
              </Form.Group>
            </Col>
          </Row>

          <div className="d-flex gap-2 justify-content-end mt-4">
            <Button as={Link} to="/shoes" variant="secondary">
              Back to List
            </Button>
            <Button type="submit" variant="primary" disabled={submitting}>
              {submitting ? 'Saving...' : submitLabel}
            </Button>
          </div>
        </Form>
      </Card.Body>
    </Card>
  );
}

export default ShoesForm;
