/**
 * File: src/components/AppNavbar.jsx
 * Mục đích: Thanh điều hướng đơn giản cho bài thi.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { Container, Navbar } from 'react-bootstrap';
import { Link } from 'react-router-dom';

/**
 * Component AppNavbar
 * Mục đích: Hiển thị tiêu đề ứng dụng và link về trang Shoes List.
 */
function AppNavbar() {
  return (
    <Navbar bg="dark" variant="dark" expand="lg" className="shadow-sm">
      <Container>
        <Navbar.Brand as={Link} to="/shoes">
          SBA301 Shoes Management
        </Navbar.Brand>
      </Container>
    </Navbar>
  );
}

export default AppNavbar;
