/**
 * File: src/AppRouter.jsx
 * Mục đích: Khai báo toàn bộ route của ứng dụng.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Container } from 'react-bootstrap';
import AppNavbar from './components/AppNavbar.jsx';
import ShoesListPage from './pages/ShoesListPage.jsx';
import ShoesFormPage from './pages/ShoesFormPage.jsx';

/**
 * Component AppRouter
 * Mục đích: Điều hướng giữa các màn hình chính.
 */
function AppRouter() {
  return (
    <BrowserRouter>
      <div className="app-shell">
        <AppNavbar />

        <Container className="py-4">
          <Routes>
            {/* Route mặc định chuyển người dùng sang màn hình chính của bài */}
            <Route path="/" element={<Navigate to="/shoes" replace />} />

            {/* Màn hình danh sách + phân trang */}
            <Route path="/shoes" element={<ShoesListPage />} />

            {/* Màn hình thêm mới */}
            <Route path="/shoes/create" element={<ShoesFormPage mode="create" />} />

            {/* Màn hình cập nhật */}
            <Route path="/shoes/:id/edit" element={<ShoesFormPage mode="edit" />} />

            {/* Nếu gõ sai URL thì quay về danh sách */}
            <Route path="*" element={<Navigate to="/shoes" replace />} />
          </Routes>
        </Container>
      </div>
    </BrowserRouter>
  );
}

export default AppRouter;
