/**
 * File: src/utils/shoesMapper.js
 * Mục đích: Chứa các hàm map dữ liệu giữa form UI và DTO backend.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { formatDateForInput } from '../utils/dateUtils.js';

/**
 * Hàm createEmptyShoesForm
 * Mục đích: Tạo state rỗng ban đầu cho form Shoes.
 */
export function createEmptyShoesForm() {
  return {
    shoesName: '',
    price: '',
    quantity: '',
    manufacturer: '',
    productionDate: '',
    importDate: '',
    categoryId: '',
  };
}

/**
 * Hàm mapShoesResponseToForm
 * Mục đích: Đưa dữ liệu lấy từ API về state mà input HTML có thể dùng được.
 */
export function mapShoesResponseToForm(shoes) {
  if (!shoes) {
    return createEmptyShoesForm();
  }

  return {
    shoesName: shoes.shoesName ?? '',
    price: shoes.price ?? '',
    quantity: shoes.quantity ?? '',
    manufacturer: shoes.manufacturer ?? '',
    productionDate: formatDateForInput(shoes.productionDate),
    importDate: formatDateForInput(shoes.importDate),
    categoryId: shoes.categoryId ?? '',
  };
}

/**
 * Hàm mapFormToShoesRequest
 * Mục đích: Chuyển dữ liệu form (đa số là string) sang DTO request đúng kiểu hơn.
 */
export function mapFormToShoesRequest(formData) {
  return {
    shoesName: formData.shoesName.trim(),
    price: Number(formData.price),
    quantity: Number(formData.quantity),
    manufacturer: formData.manufacturer.trim(),
    productionDate: formData.productionDate,
    importDate: formData.importDate,
    categoryId: Number(formData.categoryId),
  };
}
