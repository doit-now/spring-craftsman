/**
 * File: src/utils/errorUtils.js
 * Mục đích: Chuẩn hoá cách đọc lỗi từ Axios/API.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */

/**
 * Hàm getErrorMessage
 * Mục đích: Rút ra câu lỗi dễ hiểu từ nhiều dạng response backend khác nhau.
 */
export function getErrorMessage(error, fallbackMessage = 'Something went wrong.') {
  if (!error) {
    return fallbackMessage;
  }

  const responseData = error.response?.data;

  if (typeof responseData === 'string') {
    return responseData;
  }

  if (responseData?.message) {
    return responseData.message;
  }

  if (responseData?.error) {
    return responseData.error;
  }

  if (error.message) {
    return error.message;
  }

  return fallbackMessage;
}
