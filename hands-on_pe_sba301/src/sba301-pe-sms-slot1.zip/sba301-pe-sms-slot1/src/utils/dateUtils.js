/**
 * File: src/utils/dateUtils.js
 * Mục đích: Chứa các hàm xử lý ngày tháng cho màn hình Shoes.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */

/**
 * Hàm formatDateForInput
 * Mục đích: Đưa dữ liệu date từ API về định dạng yyyy-MM-dd cho input type="date".
 */
export function formatDateForInput(value) {
  if (!value) {
    return '';
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return '';
  }

  return date.toISOString().split('T')[0];
}

/**
 * Hàm formatDateForDisplay
 * Mục đích: Hiển thị ngày tháng ở bảng theo định dạng dễ đọc.
 */
export function formatDateForDisplay(value) {
  if (!value) {
    return 'N/A';
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return 'N/A';
  }

  return new Intl.DateTimeFormat('en-GB').format(date);
}
