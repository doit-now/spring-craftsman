/**
 * File: src/main.jsx
 * Mục đích: Điểm khởi động của ứng dụng React, mount App vào DOM.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import React from 'react';
import ReactDOM from 'react-dom/client';
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles.css';
import App from './App.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
