/**
 * File: src/services/shoesService.js
 * Mục đích: Chứa toàn bộ lời gọi API liên quan tới Shoes và Category.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import axiosClient from './apiClient.js';

/**
 * Lưu ý:
 * - Đây là nơi nên sửa nhanh nếu endpoint đề thi thực tế khác tên.
 * - Gom endpoint về đây giúp page/component không bị dính chặt vào URL backend.
 */
const SHOES_ENDPOINT = '/api/shoes';
const CATEGORIES_ENDPOINT = '/api/categories';

/**
 * Hàm getCategories
 * Mục đích: Lấy danh sách category để đổ vào select box.
 */
export async function getCategories() {
  const response = await axiosClient.get(CATEGORIES_ENDPOINT);
  return response.data;
}

/**
 * Hàm getShoesPage
 * Mục đích: Lấy danh sách Shoes có phân trang.
 * @param {Object} params - Tham số query cho backend.
 */
export async function getShoesPage(params) {
  const response = await axiosClient.get(SHOES_ENDPOINT, { params });
  return response.data;
}

/**
 * Hàm getShoesById
 * Mục đích: Lấy chi tiết 1 shoes để phục vụ edit.
 */
export async function getShoesById(id) {
  const response = await axiosClient.get(`${SHOES_ENDPOINT}/${id}`);
  return response.data;
}

/**
 * Hàm createShoes
 * Mục đích: Gửi request thêm mới shoes.
 */
export async function createShoes(payload) {
  const response = await axiosClient.post(SHOES_ENDPOINT, payload);
  return response.data;
}

/**
 * Hàm updateShoes
 * Mục đích: Gửi request cập nhật shoes.
 */
export async function updateShoes(id, payload) {
  const response = await axiosClient.put(`${SHOES_ENDPOINT}/${id}`, payload);
  return response.data;
}

/**
 * Hàm deleteShoes
 * Mục đích: Gửi request xoá shoes.
 */
export async function deleteShoes(id) {
  const response = await axiosClient.delete(`${SHOES_ENDPOINT}/${id}`);
  return response.data;
}
