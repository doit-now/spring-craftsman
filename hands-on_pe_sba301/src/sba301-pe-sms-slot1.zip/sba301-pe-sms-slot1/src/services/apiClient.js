/**
 * File: src/services/apiClient.js
 * Mục đích: Tạo axios instance dùng chung cho toàn dự án.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import axios from 'axios';

/**
 * axiosClient
 * Mục đích:
 * - Gom baseURL về một nơi duy nhất.
 * - Dễ bổ sung interceptor sau này nếu cần auth/token.
 * - Đảm bảo các request có timeout để tránh treo vô hạn.
 */
const axiosClient = axios.create({
  baseURL: 'http://localhost:8080',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

export default axiosClient;
