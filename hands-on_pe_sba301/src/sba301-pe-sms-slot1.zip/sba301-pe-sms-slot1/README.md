# sba301-pe-sms-slot1

> © 2026 giáo.làng with AI support, version 2026.031

## 1) Mục tiêu dự án
Đây là project React JavaScript theo phong cách **clean 1 cấp, gọn nhẹ, dễ dạy cho người mới bắt đầu** để giải bài PE CRUD cho cặp bảng **Category - Shoes**. Trọng tâm bài là CRUD trên bảng **Shoes**, gọi API Spring Boot có sẵn.

Project dùng đúng nhóm công nghệ đề yêu cầu:
- React
- Vite
- React Bootstrap
- Axios
- React Router DOM
- JavaScript thuần, **không dùng TypeScript**

## 2) Tư duy kiến trúc
Bản này đã được rút gọn lại theo kiểu **clean 1 cấp** để sinh viên mới nhìn vào dễ hiểu hơn. Không tách sâu theo feature-base nữa.

Nguyên tắc chia thư mục:
- `components/`: các component giao diện có thể tái sử dụng
- `pages/`: các màn hình chính
- `services/`: nơi gọi API
- `utils/`: hàm tiện ích nhỏ

Cách này có ưu điểm:
- dễ tìm file
- ít cấp thư mục
- vẫn còn tinh thần tách lớp UI / API / util
- phù hợp để dạy trong 80 phút

## 3) Luồng chạy tổng quát
1. `main.jsx` mount React vào `#root`
2. `App.jsx` gọi `AppRouter`
3. `AppRouter.jsx` định tuyến:
   - `/` chuyển sang `/shoes`
   - `/shoes` hiển thị danh sách
   - `/shoes/create` hiển thị form thêm mới
   - `/shoes/:id/edit` hiển thị form cập nhật
4. `ShoesListPage.jsx` gọi API phân trang shoes
5. `ShoesFormPage.jsx` gọi API category + create/update/detail
6. `ShoesForm.jsx` là form dùng chung cho create và edit

## 4) Quy ước endpoint
Project hiện giả định các endpoint sau:
- `GET /api/categories`
- `GET /api/shoes`
- `GET /api/shoes/{id}`
- `POST /api/shoes`
- `PUT /api/shoes/{id}`
- `DELETE /api/shoes/{id}`

Nếu đề thật dùng URL khác, chỉ cần sửa file:
- `src/services/shoesService.js`
- hoặc `src/services/apiClient.js`

## 5) Cấu trúc thư mục
```text
sba301-pe-sms-slot1/
├─ src/
│  ├─ components/
│  │  ├─ AppNavbar.jsx
│  │  ├─ ConfirmDeleteModal.jsx
│  │  ├─ EmptyState.jsx
│  │  ├─ ErrorAlert.jsx
│  │  ├─ LoadingSpinner.jsx
│  │  ├─ PaginationBar.jsx
│  │  ├─ ShoesFilterBar.jsx
│  │  ├─ ShoesForm.jsx
│  │  └─ ShoesTable.jsx
│  ├─ pages/
│  │  ├─ ShoesFormPage.jsx
│  │  └─ ShoesListPage.jsx
│  ├─ services/
│  │  ├─ apiClient.js
│  │  └─ shoesService.js
│  ├─ utils/
│  │  ├─ dateUtils.js
│  │  ├─ errorUtils.js
│  │  └─ shoesMapper.js
│  ├─ App.jsx
│  ├─ AppRouter.jsx
│  ├─ main.jsx
│  └─ styles.css
├─ index.html
├─ package.json
└─ vite.config.js
```

## 6) Vai trò từng nhóm file
### `components/`
Chứa các mảnh giao diện nhỏ và vừa:
- `ShoesTable`: bảng danh sách
- `ShoesForm`: form nhập liệu
- `ShoesFilterBar`: vùng sort, page size, nút create
- `PaginationBar`: thanh phân trang
- `ConfirmDeleteModal`: xác nhận xoá
- `ErrorAlert`, `LoadingSpinner`, `EmptyState`: chuẩn hoá trạng thái UI
- `AppNavbar`: thanh tiêu đề trên cùng

### `pages/`
Chứa màn hình hoàn chỉnh:
- `ShoesListPage`: load dữ liệu list, phân trang, xoá
- `ShoesFormPage`: load dữ liệu form, create, edit

### `services/`
Chứa phần giao tiếp backend:
- `apiClient.js`: axios instance dùng chung
- `shoesService.js`: các hàm CRUD và category

### `utils/`
Chứa hàm hỗ trợ:
- `dateUtils.js`: format ngày
- `errorUtils.js`: rút thông báo lỗi
- `shoesMapper.js`: map dữ liệu form sang request DTO

## 7) Kỹ thuật áp dụng
### a. Tách page và component
- Page lo điều phối dữ liệu
- Component lo hiển thị UI

### b. Tách service khỏi UI
Không gọi axios trực tiếp trong component. Làm vậy giúp code dễ đọc và dễ sửa endpoint.

### c. Dùng chung form cho create và edit
Giảm trùng lặp code, giúp sinh viên thấy cách tái sử dụng component.

### d. Validate phía client ở mức cơ bản
Kiểm tra field rỗng, số âm, ngày import không nhỏ hơn ngày sản xuất.

### e. Quản lý query phân trang bằng state
Giúp sinh viên hiểu rõ mối liên hệ giữa state UI và request API.

## 8) Cách dạy sinh viên từ project này
Có thể dạy theo thứ tự:
1. Dựng khung router
2. Làm service gọi API
3. Làm list page
4. Làm table + pagination
5. Làm form create/edit
6. Làm delete confirm
7. Tối ưu lại cấu trúc code

## 9) Cách chạy project
```bash
npm install
npm run dev
```

App chạy tại:
- React: `http://localhost:5173`
- API giả định: `http://localhost:8080`

## 10) Điểm mạnh của bản clean 1 cấp này
- Sinh viên mới dễ tìm file hơn
- Giảm cảm giác “ngợp” vì thư mục sâu
- Vẫn giữ được chuẩn tách lớp cơ bản
- Sau này vẫn có thể nâng cấp lên feature-base nếu cần

## 11) Kết luận
Đây là bản phù hợp hơn để dạy lớp mới bắt đầu: **gọn, sạch, ít cấp thư mục, vẫn đúng tinh thần code chuẩn công nghiệp ở mức vừa đủ cho bài PE 80 phút**.
