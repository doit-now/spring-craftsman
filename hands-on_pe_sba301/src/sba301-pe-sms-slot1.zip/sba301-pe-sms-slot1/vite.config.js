/**
 * File: vite.config.js
 * Mục đích: Cấu hình Vite cho ứng dụng React JavaScript.
 * Bản quyền: © 2026 giáo.làng with AI support, version 2026.031
 */
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
  },
});
