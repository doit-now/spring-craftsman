package com.giaolang.sundayshop.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
//@Table(name = "TRAI_CAY")   //TRONG SQLSERVER SẼ CÓ TABLE LÀ TRAI_CAY
//                            //MẶC ĐỊNH LẤY TÊN CLASS LÀM TÊN TABLE
public class Fruit {

    @Id
    @Column(length = 5)
    private String id;   //PK LÀ BĂT BUỘC

    //mặc định String sẽ biến thành varchar. Muốn biến thành nvarchar ta cần độ 1 xíu
    @Column(columnDefinition = "nvarchar(40)", nullable = false, unique = true)
    //mặc định tên field là tên cột trong table
    private String name;

    @Column(name = "description", columnDefinition = "nvarchar(100)")
    private String desc;   //nguy hiểm khi xuống table: cấm cột table tên desc

    @Column(nullable = false)
    private double price;

    public Fruit() {
    }

    public Fruit(String id, String name, String desc, double price) {
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.price = price;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Fruit{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", desc='" + desc + '\'' +
                ", price=" + price +
                '}';
    }
}
