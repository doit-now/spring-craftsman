package com.giaolang.sundayshop.entity;

import jakarta.persistence.*;

@Entity  //ko có @Table với tên độ lại thỉ tên table lấy từ tên class
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //tự tăng tính từ 1
    private Long id;   //PK LÀ BĂT BUỘC

    //mặc định String sẽ biến thành varchar. Muốn biến thành nvarchar ta cần độ 1 xíu
    @Column(columnDefinition = "nvarchar(40)", nullable = false, unique = true)
    //mặc định tên field là tên cột trong table
    private String name;

    @Column(name = "description", columnDefinition = "nvarchar(100)")
    private String desc;   //nguy hiểm khi xuống table: cấm cột table tên desc

    public Category() {
    }

    public Category(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }
}
