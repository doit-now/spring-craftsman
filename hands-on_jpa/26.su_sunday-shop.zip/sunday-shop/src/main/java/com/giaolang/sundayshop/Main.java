package com.giaolang.sundayshop;

import com.giaolang.sundayshop.entity.Category;
import com.giaolang.sundayshop.entity.Fruit;
import jakarta.persistence.*;

import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    //object kết nối tới SQL Server, MySQL -> chơi với DB Server
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.giaolang.sundayshop-PU");

    //object quản lý các table / entity: EntityManager
    private static EntityManager em = emf.createEntityManager();

    static void main() {
        createFruits();
        //getFruits();
        //getFruitById();
        //updateFruitById();
        //deleteFruitById();
        createCategories();
    }

    public static void createCategories() {

        Category c1 = new Category();
        c1 = new Category("Trái cây nhập khẩu", "Trái cây nhập khẩu theo mùa...");
        Category c2 = new Category("Trái cây trong nước", "Trái cây đến từ các nhà vườn VietGAP");
        Category c3 = new Category("Trái cây sấy khô", "Trái cây sấy khô...");

        em.getTransaction().begin();  //báo hiệu table sắp bị table, tracking theo dõi nhen

        em.persist(c1);   //save xuống table
        em.persist(c2);
        em.persist(c3);

        em.getTransaction().commit();

    }

    public static void deleteFruitById() {

        Fruit fruit = em.find(Fruit.class, "DD");
        if (fruit == null) {
            System.out.println("No such fruit exists");
        }
        //fruit.setName("ZDỪA ZDỪA CŨNG CŨNG");

        em.getTransaction().begin();
        em.remove(fruit);
        em.getTransaction().commit();
        //in luôn danh sách
        getFruits();
    }

    public static void updateFruitById() {

        Fruit fruit = em.find(Fruit.class, "DD");
        if (fruit == null) {
            System.out.println("No such fruit exists");
        }
        fruit.setName("ZDỪA ZDỪA CŨNG CŨNG");
        em.getTransaction().begin();
        em.merge(fruit);
        em.getTransaction().commit();
        //in luôn danh sách
        getFruits();
    }


    public static void getFruitById() {

        Fruit fruit = em.find(Fruit.class, "abc");
        if (fruit == null) {
            System.out.println("No such fruit exists");
        }
        fruit = em.find(Fruit.class, "dd");
        System.out.println("FOUND: " + fruit.toString());
    }

    public static void getFruits() {
        //câu sql style object: JPQL

        Query query = em.createQuery("select f from Fruit f"); //f là Fruit f
        List<Fruit> fruits = query.getResultList();
        System.out.println("Total Fruits: " + fruits.size());
        for (Fruit x : fruits) { //toán tử với mọi trong Toán, A ngược
            System.out.println(x.toString());
        }

        //List<Fruit> fruits = em.createQuery("select f from Fruit f").getResultList();

    }

    public static void createFruits() {

        //tạo object new Fruit(...)
        //nhờ đến em - EntityManager có sẵn 1 loạt hàm CRUD table Fruit luôn!!!!!!!!!
        //ko cần, chưa cần viết SQL

        Fruit cau = new Fruit("MC", "MÃNG CẦU", "MÃNG CẦU LÀ TRÁI ĐẦU TIÊN...", 5.0);
        Fruit sung = new Fruit("SS", "SUNG SƯỚNG", "SUNG SƯỚNG LÀ TRÁI THỨ...", 6.0);
        Fruit dua = new Fruit("DD", "ZDỪA ZDỪA", "DỪA DỪA CX CX LÀ TRÁI THỨ...", 7.0);

        em.getTransaction().begin();  //báo hiệu table sắp bị table, tracking theo dõi nhen

        em.persist(cau);   //save xuống table
        em.persist(sung);
        em.persist(dua);

        em.getTransaction().commit();

    }


}
