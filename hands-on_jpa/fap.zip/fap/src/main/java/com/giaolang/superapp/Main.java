package com.giaolang.superapp;

import com.giaolang.superapp.entity.Student;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.giaolang.superapp-PU");

    public static void main(String[] args) {
        insertStudents(); //tạo bảng, chèn data qua OOP, CODE FIRST
        getAllStudents();  //select * from style OOP, CODE FIRST
    }

    //SPRING DATA, SPRING JPA

    //INSERT/TẠO MỚI SV...
    public static void insertStudents() {
//        EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.giaolang.superapp-PU"); //gửi thông số cấu hình Server, nhà thầu JPA: Hibernate, nhà thầu JDBC cho JPA class lo để tạo kết nối tới CSDL cụ thể SQL Server
        EntityManager em = emf.createEntityManager();
        //tạo ra 1 object dùng để quản lí các entity class ~ map ngang sang table. Class Student chịu sự quản lí của em/EntityManager
        //em/EntityManager sẽ lo CRUD trên 1 table nào đó!
        //qua mấy hàm huyền thoại: persit() find() merge() remove()
        //TOÀN CHƠI OBJECT, ĐẰNG SAU LÀ TABLE BỊ ẢNH HƯỞNG - TỰ SINH SQL NGẦM, VÀ NÓ CHO MÌNH THẤY CÂU SQL NÀY LUÔN KHI MÌNH CHẤM CÁC HÀM Ở TRÊN .persit() .find() .merge() .remove()
        //chuẩn bị data Student - object nhen - OOP nhen
        Student an = new Student("SE10", "AN NGUYỄN", 2004, 8.6);
        Student binh = new Student("SE2", "BÌNH LÊ", 2004, 8.7);
        Student cuong = new Student("SE3", "CƯỜNG VÕ", 2004, 8.8);

        //gọi sếp EntityManage giúp CRUD
        em.getTransaction().begin(); //BẮT BUỘC PHẢI CÓ TRANSACTION KHI CÓ SỰ THAY ĐỔI TRONG DB
        em.persist(an);      //CREATE TABLE DIỄN RA NGẦM
        em.persist(binh);    //GỌI LÀ CODE FIRST, CODE RA TABLE
        em.persist(cuong);   //                   CODE RA DATA
                             //INSERT INTO STUDENT VALUES
        em.getTransaction().commit();  //HOẶC CẢ 3 INSERT THÀNH CÔNG, HOẶC CHƯA BẠN NÀO ĐC INSERT
        //SELECT KO CẦN, VÌ KO THAY ĐỔI TRẠNG THÁI TABLE 
        em.close();  //sa thải ông sếp vì đã xong
        //emf.close(); //ngắt kết nối csdl vì đã xong
    }

    //SELECT * ĐỂ LẤY HẾT DATA...
    public static void getAllStudents() {

        EntityManager em = emf.createEntityManager();
        List<Student> result = em.createQuery("FROM Student", Student.class).getResultList();  //HẬU TRƯỜNG LÀ SELECT * FROM STUDENT SQL TRUYỀN THỐNG - SẼ IN XEM NẾU KHAI BÁO CẤU HÌNH TRONG FILE .XML

        //QUERY NÀY CÚ PHÁP GẦN GIỐNG SQL, NHƯNG THEO STYLE OOP, CÓ OBJECT VÀ DẤU CHẤM, GỌI LÀ JPQL, HQL

        System.out.println("The list of students (3 records)");
        for (Student x : result) {
            System.out.println(x); //gọi thầm tên em toString() của Student
        }
        //dùng biểu thức Lambda để in cx đc

        em.close();
        emf.close();
    }
}