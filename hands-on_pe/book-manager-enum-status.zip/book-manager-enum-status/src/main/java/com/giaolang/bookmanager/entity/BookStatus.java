package com.giaolang.bookmanager.entity;

public enum BookStatus {
    ACTIVE, INACTIVE, COMING_SOON
}
//ngầm hiểu ACTIVE là public static final
//BookStatus.ACTIVE