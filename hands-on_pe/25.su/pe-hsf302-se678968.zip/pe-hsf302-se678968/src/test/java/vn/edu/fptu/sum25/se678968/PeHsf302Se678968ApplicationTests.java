package vn.edu.fptu.sum25.se678968;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeHsf302Se678968ApplicationTests {

    @Test
    void contextLoads() {
    }

}
