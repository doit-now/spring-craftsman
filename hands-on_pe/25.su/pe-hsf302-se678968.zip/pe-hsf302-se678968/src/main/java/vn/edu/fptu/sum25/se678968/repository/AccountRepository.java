package vn.edu.fptu.sum25.se678968.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import vn.edu.fptu.sum25.se678968.entity.Account;

public interface AccountRepository extends JpaRepository<Account, Long> {

    public Account findByEmail(String email);
}
