package vn.edu.fptu.sum25.se678968.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import vn.edu.fptu.sum25.se678968.entity.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
}
