package vn.edu.fptu.sum25.se678968.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.edu.fptu.sum25.se678968.entity.Book;

import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long> {

    public List<Book> searchAllByNameContainingIgnoreCaseOrAuthorNameContainingIgnoreCase(String name, String authorName);

    public List<Book> getAllByOrderByCreatedAtDesc();
}
