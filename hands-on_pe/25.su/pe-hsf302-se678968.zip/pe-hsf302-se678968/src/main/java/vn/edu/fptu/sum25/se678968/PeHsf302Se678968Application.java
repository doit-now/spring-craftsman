package vn.edu.fptu.sum25.se678968;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeHsf302Se678968Application {

    public static void main(String[] args) {
        SpringApplication.run(PeHsf302Se678968Application.class, args);
    }

}
