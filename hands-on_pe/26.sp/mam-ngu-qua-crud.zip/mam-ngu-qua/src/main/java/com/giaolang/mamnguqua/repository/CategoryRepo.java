package com.giaolang.mamnguqua.repository;

import com.giaolang.mamnguqua.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepo extends JpaRepository<Category, Long> {
}
