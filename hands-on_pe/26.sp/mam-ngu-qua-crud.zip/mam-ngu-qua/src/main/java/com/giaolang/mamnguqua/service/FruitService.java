package com.giaolang.mamnguqua.service;

import com.giaolang.mamnguqua.entity.Fruit;

import java.util.List;

public interface FruitService {

    //chứa các hàm CRUD table Fruit.
    //repo.save(fruitX nào đó thì: nếu key cuả fruitX chưa tồn tại => insert
    //                             nếu key đã tồn tại ri => update)

    //tách 2 hàm create() và update() riêng ở Service, vẫn gọi chung repo.save()
    //nhưng trong create() ta chèn thêm lệnh kiểm tra key trùng nếu muốn

    public List<Fruit> getAllFruits();
    public Fruit getOneFruit(Long id);
    public Fruit createFruit(Fruit fruit);
    public Fruit updateById(Fruit fruit);
    public void deleteById(Long id);


}
