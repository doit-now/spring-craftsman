package com.giaolang.mamnguqua.repository;

import com.giaolang.mamnguqua.entity.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepo extends JpaRepository<UserAccount, Long> {


    UserAccount findByEmailContainingIgnoreCaseAndPassword(String email, String password);
    //interface này có sẵn 2 loại hàm mà JPA sẽ generate giúp ta
    //hàm đc generate sẵn để dùng, thường là hàm CRUD dựa trên key, biểu tượng chữ M màu đỏ
    //hàm độ theo nhu cầu, miễn ta đặt tên đúng cú pháp, có gợi ý cách đặt tên
    //                                                     biểu tượng lá xanh
    //hàm lá xanh, ta chỉ tốn cộng duy nhất: GÕ TÊN HÀM Ở ĐÂY

}
