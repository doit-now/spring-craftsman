package com.giaolang.mamnguqua.service;

import com.giaolang.mamnguqua.entity.UserAccount;

public interface UserService {

    //có 2 cách báo lỗi login
    //báo cụ thể sai cái gì: "sai email" (chưa có account) hay "sai pass"
    //báo chung chung: "sai email hoặc pass"
    public UserAccount login(String email, String password);

}
