package com.giaolang.mamnguqua.service.impl;

import com.giaolang.mamnguqua.entity.Category;
import com.giaolang.mamnguqua.repository.CategoryRepo;
import com.giaolang.mamnguqua.service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepo cateRepo; //tiêm qua constructor; nhưng
    //ko thèm làm constructor tường minh; ko @Autowire

    @Override
    public List<Category> getAllCategories() {
        return  cateRepo.findAll();
    }
}
