package com.giaolang.mamnguqua.controller;

import com.giaolang.mamnguqua.entity.Fruit;
import com.giaolang.mamnguqua.service.CategoryService;
import com.giaolang.mamnguqua.service.FruitService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/fruits")   //cứ gõ /fruits là đến class này!!!
@RequiredArgsConstructor
public class FruitController {

    private final FruitService fruitService;
    private final CategoryService categoryService; //giúp lo danh sách xổ chọn Cate

    @GetMapping //chặn việc gõ /fruits trực tiếp mà ko qua login
    public String getAll(Model box, HttpSession session) {

        //check login. Kiểm tra xem hộp Session có loggedInAccount hay ko
        if (session.getAttribute("loggedInAccount") == null) {
            //chưa login, chưa có loggedInAccount trong Session
            return "redirect:/auth/login"; //chuyển hướng về trang login
        }

        //              List<Fruits> fruitList = fruitService.getAllFruits()
        box.addAttribute("fruitList", fruitService.getAllFruits());

        return "fruits"; //trả về tên trang
    }

    @GetMapping("/delete/{id}")
    public String deleteById(@PathVariable Long id, HttpSession session) {

        //check login. Kiểm tra xem hộp Session có loggedInAccount hay ko
        if (session.getAttribute("loggedInAccount") == null) {
            //chưa login, chưa có loggedInAccount trong Session
            return "redirect:/auth/login"; //chuyển hướng về trang login
        }

        //chỉ đc xoá khi đã login và khi đã có id của trái cây cần xoá
        fruitService.deleteById(id);
        return "redirect:/fruits";
    }

    @GetMapping("/add") //gửi về trang fruit-form 1 object rỗng
    public String addOne(Model box, HttpSession session) {

        //check login. Kiểm tra xem hộp Session có loggedInAccount hay ko
        if (session.getAttribute("loggedInAccount") == null) {
            //chưa login, chưa có loggedInAccount trong Session
            return "redirect:/auth/login"; //chuyển hướng về trang login
        }

        box.addAttribute("xObj", new Fruit());

        //new cx phải gửi thêm danh sách category để chọn, vì trái cây phải có category
        box.addAttribute("cates", categoryService.getAllCategories());
        return  "fruit-form";
    }

    //2 HÀM XÀI CHUNG MÀN HÌNH, CHUNG TRANG, PHẢI TRẢ VỀ CÙNG 1 BOX CÙNG TÊN
    //BÊN TRANG 1 CODE, CÙNG TÊN OBJECT, XÀI 2 VIỆC NEW VÀ EDIT !!!!!!!!!!!!!!!!!!

    @GetMapping("/edit/{id}") //nhận id gửi lên, mình gửi ngược lại cho trang
    //fruit-form cái object đc query từ DB có id trùng với id gửi lên
    //new-mode ta cx phải gửi cùng 1 object như bên edit, vì xài chung 1 trang
    //object này sẽ là rỗng, ko có id, để trang biết là đang ở chế độ tạo mới, còn nếu có id thì đang ở chế độ edit; hoặc dùng 1 biến flag để phân biệt edit hay new mode!!!
    public String editById(@PathVariable Long id, Model box, HttpSession session) {

        //check login. Kiểm tra xem hộp Session có loggedInAccount hay ko
        if (session.getAttribute("loggedInAccount") == null) {
            //chưa login, chưa có loggedInAccount trong Session
            return "redirect:/auth/login"; //chuyển hướng về trang login
        }

        //check login. Kiểm tra xem hộp Session có loggedInAccount hay ko
        if (session.getAttribute("loggedInAccount") == null) {
            //chưa login, chưa có loggedInAccount trong Session
            return "redirect:/auth/login"; //chuyển hướng về trang login
        }

        Fruit fruit = fruitService.getOneFruit(id);
        box.addAttribute("xObj", fruit);

        //edit phải gửi thêm danh sách category để chọn, vì trái cây phải có category
        box.addAttribute("cates", categoryService.getAllCategories());

        return  "fruit-form";
    }

    @PostMapping("/save") //nhận dữ liệu gửi lên từ form, rồi lưu vào DB
    public String save(@Valid @ModelAttribute("xObj") Fruit fruit, BindingResult bindingResult, Model box, HttpSession session) {

        //check login. Kiểm tra xem hộp Session có loggedInAccount hay ko
        if (session.getAttribute("loggedInAccount") == null) {
            //chưa login, chưa có loggedInAccount trong Session
            return "redirect:/auth/login"; //chuyển hướng về trang login
        }

        //nếu có lỗi validate, thì trả về lại trang form, ko trở lại login, kèm theo lỗi
        if (bindingResult.hasErrors()) {
            //ta phải gửi lại danh sách category để chọn, vì trái cây phải có category, nếu ko sẽ lỗi NullPointerException
            box.addAttribute("xObj", fruit);
            //phải gửi lại danh sách category để chọn, vì trái cây phải có category
            box.addAttribute("cates", categoryService.getAllCategories());
            return "fruit-form";
        }

        fruitService.createFruit(fruit);
        return "redirect:/fruits";
    } //thằng repo chỉ có 1 hàm có sẵn là .save(Fruit obj)
    //nếu obj ko có id, thì là tạo mới
    //nếu obj có id, thì là update


}
