package com.giaolang.mamnguqua.config;

import com.giaolang.mamnguqua.entity.Category;
import com.giaolang.mamnguqua.entity.Fruit;
import com.giaolang.mamnguqua.entity.UserAccount;
import com.giaolang.mamnguqua.repository.CategoryRepo;
import com.giaolang.mamnguqua.repository.FruitRepo;
import com.giaolang.mamnguqua.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

//@RestController, @Controller, @Component, @Service, @Repository, @Configuration, @Bean
@Component //tự đc new bởi IoC container
public class DataInitializer implements CommandLineRunner {

    //tiêm 3 thằng Repo ứng 3 table
    @Autowired
    private UserRepo userRepo;

    @Autowired
    private CategoryRepo cateRepo;

    @Autowired
    private FruitRepo fruitRepo;

    @Override
    public void run(String... args) throws Exception {
        //nơi ta insert into table... chèn tạo data cho table
        //tạo data cho UserAccount, Category, Fruit
        //gọi Repo tương ứng giúp save các object đc new (new mới dùng Builder

        //UserAccount ad = new UserAccount(...); new truyền thống
        UserAccount ad = UserAccount.builder()
                .email("ad@a.com")
                .fullName("Hoàng Ngọc Trinh")
                .password("a")
                .role("ADMIN")
                .build();

        UserAccount st = UserAccount.builder()
                .email("st@a.com")
                .fullName("Hoà Minzy")
                .password("s")
                .role("STAFF")
                .build();
        userRepo.save(ad);
        userRepo.save(st);

        //---------------------- CHÈN 3 CATE
        //Category cat1 = new Category(); cũ rồi, chơi Builder
        Category cat1 = Category.builder()
                .name("Trái cây tươi")
                .build();
        Category cat2 = Category.builder()
                .name("Trái cây sấy khô")
                .build();
        Category cat3 = Category.builder()
                .name("Trái cây chế biến sẵn")
                .build();

//        cateRepo.save(cat1);
//        cateRepo.save(cat2);
//        cateRepo.save(cat3);

        List<Category>  cates = List.of(cat1, cat2, cat3);
        cateRepo.saveAll(cates);

        //--------- 5 trái cây
        Fruit f1c1 = Fruit.builder()
                                .name("Mãng cầu")
                                .description("Trái mãng cầu là...")
                                .price(50000)
                                .cate(cat1)
                                .build();
        Fruit f2c1 = Fruit.builder()
                .name("Sung")
                .description("Trái sung là...")
                .price(60000)
                .cate(cat1)
                .build();
        Fruit f1c2 = Fruit.builder()
                .name("Dừa")
                .description("Trái dừa là...")
                .price(70000)
                .cate(cat2)
                .build();
        Fruit f2c2 = Fruit.builder()
                .name("Đu đủ")
                .description("Trái đu đủ là...")
                .price(80000)
                .cate(cat2)
                .build();
        Fruit f1c3 = Fruit.builder()
                .name("Xoài")
                .description("Trái xoài là...")
                .price(90000)
                .cate(cat3)
                .build();
        List<Fruit> fs = List.of(f1c1, f2c1, f1c2, f2c2, f1c3);
        fruitRepo.saveAll(fs);

    }
}
