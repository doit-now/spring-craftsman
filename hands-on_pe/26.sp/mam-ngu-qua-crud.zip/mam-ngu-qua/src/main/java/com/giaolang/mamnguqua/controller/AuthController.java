package com.giaolang.mamnguqua.controller;

import com.giaolang.mamnguqua.entity.UserAccount;
import com.giaolang.mamnguqua.service.UserService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    //tiêm chích
    private final UserService userService;

    @GetMapping({"/", "/login"})
    public String getLogin() {
        return "login";
    }

    @PostMapping
    public String doLogin(@RequestParam String email,
                          @RequestParam String pass,
                          RedirectAttributes redirect,
                          HttpSession session) {
        UserAccount acc = userService.login(email, pass);
        if (acc == null) {
            redirect.addFlashAttribute("errorMsg", "Invalid email or password");
            return "redirect:/auth/login";
        }
        //login ngon lành
        //cất info vào hộp lâu dài, vào hộp Session, ứng với từng người login
        //Cookie còn nhớ ko
        session.setAttribute("loggedInAccount", acc);
        return "redirect:/fruits";
    }

    @GetMapping("/logout")
    public String doLogout(HttpSession session) {
        //session.removeAttribute("loggedInAccount");
        session.invalidate();
        return "redirect:/auth/login";  //nhấn logout thì phải trở lại login
    }

}
