package com.giaolang.mamnguqua.service.impl;

import com.giaolang.mamnguqua.entity.UserAccount;
import com.giaolang.mamnguqua.repository.UserRepo;
import com.giaolang.mamnguqua.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;


@RequiredArgsConstructor
@Service
public class UserServiceImpl implements UserService {

    private final UserRepo userRepo;

    @Override
    public UserAccount login(String email, String password) {

        return userRepo.findByEmailContainingIgnoreCaseAndPassword(email, password);

    }
}
