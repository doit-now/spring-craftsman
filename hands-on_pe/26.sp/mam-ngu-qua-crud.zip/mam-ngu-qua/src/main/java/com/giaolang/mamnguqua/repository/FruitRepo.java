package com.giaolang.mamnguqua.repository;

import com.giaolang.mamnguqua.entity.Fruit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FruitRepo extends JpaRepository<Fruit, Long> {
}
