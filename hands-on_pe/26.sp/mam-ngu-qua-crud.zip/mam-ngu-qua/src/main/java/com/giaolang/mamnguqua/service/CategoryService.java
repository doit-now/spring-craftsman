package com.giaolang.mamnguqua.service;

import com.giaolang.mamnguqua.entity.Category;

import java.util.List;

public interface CategoryService {

    public List<Category> getAllCategories();
}
