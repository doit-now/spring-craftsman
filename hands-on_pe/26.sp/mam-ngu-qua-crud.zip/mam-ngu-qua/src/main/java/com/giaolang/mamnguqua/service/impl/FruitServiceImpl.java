package com.giaolang.mamnguqua.service.impl;

import com.giaolang.mamnguqua.entity.Fruit;
import com.giaolang.mamnguqua.repository.FruitRepo;
import com.giaolang.mamnguqua.service.FruitService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class FruitServiceImpl implements FruitService {

    private final FruitRepo fruitRepo; //chích qua constructor ngầm

    @Override
    public List<Fruit> getAllFruits() {
        return fruitRepo.findAll();
    }

    @Override
    public Fruit getOneFruit(Long id) {
        return fruitRepo.findById(id).orElseThrow();
        //         trả về 1 box [fruit obj hoặc null]
        //                                           .orElseThrow()
        //                                           getFruit đấy, hoặc ném ngoại lệ
        //                                           nếu tìm ko thấy Fruit
    }

    @Override
    public Fruit createFruit(Fruit fruit) {

        //TODO: check key trùng rồi mới save xuống table
        return fruitRepo.save(fruit);
    }

    @Override
    public Fruit updateById(Fruit fruit) {
        //TOD0: CHECK KEY KO TỒN TẠI
        return fruitRepo.save(fruit);
    }

    @Override
    public void deleteById(Long id) {
        fruitRepo.deleteById(id);
    }
}
