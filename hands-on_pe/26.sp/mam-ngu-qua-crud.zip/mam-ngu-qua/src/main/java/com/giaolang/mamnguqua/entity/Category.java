package com.giaolang.mamnguqua.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, columnDefinition = "nvarchar(50)")
    @Size(min = 5, max = 50, message = "The name must be from 5 to 50 characters length")
    @NotBlank(message = "Category name is required!")
    private String name;

    @OneToMany(mappedBy = "cate")
    private List<Fruit> fruitList = new ArrayList<>();


}
