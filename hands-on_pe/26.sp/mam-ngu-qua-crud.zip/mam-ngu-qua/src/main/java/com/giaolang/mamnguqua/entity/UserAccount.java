package com.giaolang.mamnguqua.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "UserAccount")
@Data               //có get set tự động
@NoArgsConstructor
@AllArgsConstructor
@Builder            //dựa trên 1 design pattern, giúp ta new object nhưng
                    //ko cần dùng constructor full tham số
                    //new qua kiểu set()  . . . . . chấm liên tục
                    //gọi hàm set() liên tục qua các dấu chấm
                    //muốn truyền bao nhiêu field thì chấm bấy nhiêu -> linh hoạt
public class UserAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, columnDefinition = "varchar(100)")
    @Email(message = "Invalid email | Email không hợp lệ")
    @NotBlank(message = "Email is required!")
    private String email;

    @Column(nullable = false, columnDefinition = "nvarchar(50)")
    @Size(min = 5, max = 50, message = "The name must be from 5 to 50 characters length")
    @NotBlank(message = "FullName is required!")
    private String fullName;

    @Column(nullable = false, columnDefinition = "varchar(30)")
    @Size(min = 1, max = 30, message = "The name must be from 8 to 30 characters length")
    @NotBlank(message = "Password is required!")
    private String password;

    @Column(nullable = false, columnDefinition = "varchar(30)")
    @NotBlank(message = "Role is required!")
    private String role;  //Admin, Staff, Member

}
