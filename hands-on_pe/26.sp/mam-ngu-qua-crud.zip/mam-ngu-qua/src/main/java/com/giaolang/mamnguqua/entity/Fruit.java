package com.giaolang.mamnguqua.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Fruit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, columnDefinition = "nvarchar(50)")
    @Size(min = 2, max = 50, message = "The name must be from 2 to 50 characters length")
    @NotBlank(message = "Fruit name is required!")
    private String name;

    @Column(nullable = false, columnDefinition = "nvarchar(100)")
    @Size(min = 5, max = 100, message = "The name must be from 5 to 100 characters length")
    @NotBlank(message = "Fruit desc is required!")
    private String description;

    @Column(nullable = false)
    @Min(value = 5000, message = "The minimum price is 5000đ")
    @Max(value = 200000, message = "The maximum price is 200000đ")
    private double price;

    //em phía N trỏ sang phía 1 Category

    @ManyToOne
    @JoinColumn(name = "cate_id")
    private Category cate;


}