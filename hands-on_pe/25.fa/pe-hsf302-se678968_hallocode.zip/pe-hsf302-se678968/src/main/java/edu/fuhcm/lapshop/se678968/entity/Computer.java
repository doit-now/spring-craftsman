package edu.fuhcm.lapshop.se678968.entity;

public class Computer {
}
