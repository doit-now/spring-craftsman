package edu.fuhcm.lapshop.se678968.entity;


import jakarta.persistence.*;

@Entity
@Table(name = "Users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long id;

    @Column(name = "email", length = 100, columnDefinition = "nvarchar(100)", nullable = false)
    private String email;
    //String là varchar(), muốn nvarchar() cho tiếng Việt phải độ cột

    @Column(name = "password", length = 50, nullable = false)
    private String password;  //String là varchar(), muốn nvarchar() cho tiếng Việt phải độ cột

    @Column(name = "role", length = 20, nullable = false)
    private String role;

}

