package edu.fuhcm.lapshop.se678968.service;

import edu.fuhcm.lapshop.se678968.entity.Manufacturer;

public interface ManufacturerService {

    public void createManufacturer(Manufacturer obj);
}
