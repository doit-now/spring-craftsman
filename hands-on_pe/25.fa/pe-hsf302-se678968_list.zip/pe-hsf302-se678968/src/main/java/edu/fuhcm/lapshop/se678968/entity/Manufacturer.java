package edu.fuhcm.lapshop.se678968.entity;


import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Manufacturers")
@NoArgsConstructor
@Data
public class Manufacturer {   //HÃNG, NHÀ SX  1  ------------|<- N VỚI COMPUTER

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "manufacturer_id")
    private Long id;

    @Column(name = "manufacturer_name", columnDefinition = "nvarchar(100)", nullable = false, unique = true)
    private String name;

    @Column(name = "country", columnDefinition = "nvarchar(100)", nullable = false)
    private String country;

    public Manufacturer(String name, String country) {
        this.name = name;
        this.country = country;
    }
}
