package edu.fuhcm.lapshop.se678968.controller;

import edu.fuhcm.lapshop.se678968.service.ComputerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/laptops")  //base url, nhân tử chung
                                //các hàm ở dưới nối tiếp url riêng của nó
public class LaptopController {

    @Autowired  //tiêm vào
    private ComputerService computerService;

    @GetMapping()
    public String list(Model model) {
        //gửi 1 thùng sang trang laptops, chứa nguyên list select * from Computers
        model.addAttribute("laps", computerService.getAllComputers());
        // ram của trang List<Computer> laps = computerService.getAllComputers()
        //bên trang laptops.html xài biến laps, dùng for each thảy vào từng <tr> của tag <table>
        return "laptops";
    }

}

//   /laptops  -> show all
//   /laptops/edit/1   /2    /3
//   /laptops/delete/1   /2   /3
//   /laptops/create
//   /laptops/save      nhấn nút [Save] trên form nhập xài chung cho cả
//                                     edit và create
//   /