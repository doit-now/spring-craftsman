package edu.fuhcm.lapshop.se678968.repository;

import edu.fuhcm.lapshop.se678968.entity.Manufacturer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ManufacturerRepo extends JpaRepository<Manufacturer, Long> {
}
