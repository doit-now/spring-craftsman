package edu.fuhcm.lapshop.se678968.service.impl;

import edu.fuhcm.lapshop.se678968.entity.Computer;
import edu.fuhcm.lapshop.se678968.repository.ComputerRepo;
import edu.fuhcm.lapshop.se678968.service.ComputerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service  //@Component
public class ComputerServiceImpl implements ComputerService {

    @Autowired
    private ComputerRepo repo;

    @Override
    public void createComputer(Computer obj) {
        repo.save(obj);
    }

    @Override
    public List<Computer> getAllComputers() {
        return repo.findAll(); //hàm tự sinh có sẵn, biểu tượng chữ M
    }
}
