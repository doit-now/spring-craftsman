package edu.fuhcm.lapshop.se678968.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Users")
@NoArgsConstructor
//@AllArgsConstructor VÌ KEY TỰ TĂNG KO DÙNG OPTION NÀY,
//VÌ NÓ SẼ GENERATE RA CONSTRUCTOR FULL THAM SỐ, MÀ CLASS NÀY CỘT KEY KO ĐC ĐƯA VALUE VÀO
//TA CHỦ ĐỘNG LÀM 1 CONSTRUCTOR - 1 THAM SỐ KEY BẰNG TAY, PHẢI CHUỘT | GENERATE | CONSTRUCTOR, BỎ BỚT KEY
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long id;

    @Column(name = "email", length = 100, columnDefinition = "nvarchar(100)", nullable = false, unique = true)
    private String email;
    //String là varchar(), muốn nvarchar() cho tiếng Việt phải độ cột

    @Column(name = "password", length = 50, nullable = false)
    private String password;  //String là varchar(), muốn nvarchar() cho tiếng Việt phải độ cột

    @Column(name = "role", length = 20, nullable = false)
    private String role;

    public User(String email, String password, String role) {
        this.email = email;
        this.password = password;
        this.role = role;
    }
}

