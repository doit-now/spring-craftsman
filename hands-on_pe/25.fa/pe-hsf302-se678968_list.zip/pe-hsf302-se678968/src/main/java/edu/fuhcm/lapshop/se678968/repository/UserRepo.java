package edu.fuhcm.lapshop.se678968.repository;

import edu.fuhcm.lapshop.se678968.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepo extends JpaRepository<User, Long> {

    public User findByEmail(String email);

    public User findByEmailAndPassword(String email, String password);
    //derived query method: hàm tự sinh ra câu query tương ứng miễn đặt tên hàm theo quy tắc đặt tên hàm quy định bởi Spring Data
    //đưa câu where cột trên tên hàm

}
