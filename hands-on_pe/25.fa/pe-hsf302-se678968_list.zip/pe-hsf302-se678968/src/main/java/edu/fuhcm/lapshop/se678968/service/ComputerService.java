package edu.fuhcm.lapshop.se678968.service;

import edu.fuhcm.lapshop.se678968.entity.Computer;

import java.util.List;

public interface ComputerService {

    public void createComputer(Computer obj);

    public List<Computer> getAllComputers();
}
