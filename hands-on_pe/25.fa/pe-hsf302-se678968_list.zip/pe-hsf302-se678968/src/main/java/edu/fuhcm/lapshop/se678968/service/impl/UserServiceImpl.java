package edu.fuhcm.lapshop.se678968.service.impl;

import edu.fuhcm.lapshop.se678968.entity.User;
import edu.fuhcm.lapshop.se678968.repository.UserRepo;
import edu.fuhcm.lapshop.se678968.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    //MANTRA: CONTROLLER -- SERVICE -- REPO --- JPA/HIBERNATE --- JDBC --- TABLE THẬT
    //                       !!!
    //DI DEPENDENCY INJECTION, TIÊM VÀO THẰNG REPO
    @Autowired
    private UserRepo repo; //ko new vì chích vào, tiêm vào bởi Ioc Container

    @Override
    public void createUser(User obj) {
        //hàm tự sinh ơi của repo ơi
        repo.save(obj);
    }

    @Override
    public User authenticate(String email) {

        return repo.findByEmail(email);  //hoặc thấy 1 email, thấy 1 row, 1 User trả về
                                        //hoặc null, vì gõ email sai
    }

    @Override
    public User authenticate(String email, String password) {
        return repo.findByEmailAndPassword(email, password);  //y chang ý nghĩa như hàm trên
    }
}
