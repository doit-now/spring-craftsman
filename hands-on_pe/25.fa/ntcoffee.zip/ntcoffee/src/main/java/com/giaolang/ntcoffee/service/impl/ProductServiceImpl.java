package com.giaolang.ntcoffee.service.impl;

import com.giaolang.ntcoffee.entity.Product;
import com.giaolang.ntcoffee.repository.ProductRepo;
import com.giaolang.ntcoffee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepo repo;

    @Override
    public List<Product> getAllProducts() {
        return repo.findAll();
    }

    @Override
    public void createProduct(Product product) {
        repo.save(product);
    }

    @Override
    public void updateProduct(Product product) {
        repo.save(product);
    }

    @Override
    public void deleteProduct(Product product) {
        repo.delete(product);
    }
}
