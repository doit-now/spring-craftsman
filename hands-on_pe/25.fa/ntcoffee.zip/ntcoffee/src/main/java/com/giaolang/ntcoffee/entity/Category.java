package com.giaolang.ntcoffee.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "Category")
@NoArgsConstructor
@Data
public class Category {

    //1 | Bia rượu | Ko say ko về...
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "Id")
    private Long id;

    @Column(name = "Name", nullable = false, columnDefinition = "nvarchar(40)")
    private String name;

    @Column(name = "Description", nullable = false, columnDefinition = "nvarchar(80)")
    private String description;

    public Category(String name, String description) {
        this.name = name;
        this.description = description;
    }
}
