package com.giaolang.ntcoffee.service;

import com.giaolang.ntcoffee.entity.Account;
import com.giaolang.ntcoffee.entity.Category;

import java.util.List;

public interface CategoryService {

    //HÀM TẠO MỚI CATEGORY DÙNG TRONG CODE FIRST

    //HÀM LOAD TẤT CẢ CATEGORY DÙNG CHO TREO ĐẦU DÊ, LẤY THỊT HEO

    //KO CÓ NHU CẦU XOÁ, SỬA CATE, BÀI KHÁC, BÀI PE KO CẦN

    public void createCategory(Category cate);

    public List<Category> getAllCategories();

}
