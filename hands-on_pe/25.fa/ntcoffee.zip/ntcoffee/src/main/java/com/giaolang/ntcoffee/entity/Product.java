package com.giaolang.ntcoffee.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Product")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Product {

    @Id
    @Column(name = "Id", columnDefinition = "char(10)")
    private String id;

    @Column(name = "Name", nullable = false, columnDefinition = "nvarchar(40)")
    private String name;

    @Column(name = "Quantity", nullable = false)
    private int quantity;

    @Column(name = "Price", nullable = false)
    private double price;

    //mapping N - 1, NHIỀU PRODUCT THUỘC VỀ 1 CATE (1 CATE CÓ NHIỀU PRODUCT)
    //MỖI PRODUCT PHẢI CÓ THÔNG TIN THAM CHIẾU VỀ CATE, CATE CHỨA LIST<PRODUCT>

    @ManyToOne
    @JoinColumn(name = "CateId")  //cột FK trong DB
    private Category cate;  //biến cate trỏ thẳng lên Category (id, name, desc) quan điểm OOP

}
