package edu.fuhcm.lapshop.se678968.service;

import edu.fuhcm.lapshop.se678968.entity.Computer;

import java.util.List;

public interface ComputerService {

    public void createComputer(Computer obj);

    public List<Computer> getAllComputers();

    public Computer getComputerById(long id);  //lấy ra 1 sản phẩm theo id, để phục vụ cho hàm Edit, Delete, Check trùng key (key ko tự tăng)
}
