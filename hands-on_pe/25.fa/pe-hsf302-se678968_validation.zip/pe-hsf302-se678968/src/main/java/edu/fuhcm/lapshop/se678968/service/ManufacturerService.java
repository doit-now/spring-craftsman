package edu.fuhcm.lapshop.se678968.service;

import edu.fuhcm.lapshop.se678968.entity.Manufacturer;

import java.util.List;

public interface ManufacturerService {

    public void createManufacturer(Manufacturer obj);

    public List<Manufacturer> getAllManufacturers();
    //hàm này phục vụ cho treo đầu dê lấy thịt heo
    //show danh sách xổ chọn các NCC/NSX khi tạo mới, hay edit 1 Laptop
    //1  Dell
    //2  Acer
    //3  Asus
    //4  Apple
}
