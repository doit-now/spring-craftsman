package edu.fuhcm.lapshop.se678968.service.impl;

import edu.fuhcm.lapshop.se678968.entity.Manufacturer;
import edu.fuhcm.lapshop.se678968.repository.ManufacturerRepo;
import edu.fuhcm.lapshop.se678968.service.ManufacturerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ManufacturerServiceImpl implements ManufacturerService {

    @Autowired
    private ManufacturerRepo repo;

    @Override
    public void createManufacturer(Manufacturer obj) {
        repo.save(obj);
    }

    @Override
    public List<Manufacturer> getAllManufacturers() {
        return repo.findAll();
    }
}
