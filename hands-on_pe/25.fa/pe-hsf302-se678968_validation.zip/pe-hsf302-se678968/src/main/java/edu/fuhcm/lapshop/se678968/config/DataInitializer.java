package edu.fuhcm.lapshop.se678968.config;

import edu.fuhcm.lapshop.se678968.entity.Computer;
import edu.fuhcm.lapshop.se678968.entity.Manufacturer;
import edu.fuhcm.lapshop.se678968.entity.User;
import edu.fuhcm.lapshop.se678968.service.ComputerService;
import edu.fuhcm.lapshop.se678968.service.ManufacturerService;
import edu.fuhcm.lapshop.se678968.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    //TIÊM VÀO 3 THẰNG SERVICE ĐÃ CÓ HÀM XUỐNG TABLE RỒI
    @Autowired
    private ComputerService computerService;

    @Autowired
    private UserService userService;

    @Autowired
    private ManufacturerService manufacturerService;
    //khai báo Cha interface nhưng lúc run thì new Con Impl

    @Override
    public void run(String... args) throws Exception {

        //TẠO MỚI DATA CHO TABLE USER ACCOUNT
        User u1 = new User("admin@laptopshop.com", "@1", "Admin");
        User u2 = new User("staff@laptopshop.com", "@2", "Staff");
        User u3 = new User("member@laptopshop.com", "@3", "Member");

        //TẠO MỚI DATA CHO TABLE MANUFACTURER NSX
        Manufacturer dell = new Manufacturer("Dell", "USA");
        Manufacturer lenovo = new Manufacturer("Lenovo", "China");
        Manufacturer hp = new Manufacturer("HP", "USA");

        //TẠO MÓI DATA CHO TABLE MÁY TÍNH COMPUTER
        Computer c1 = new Computer("XPS 13", "Ultrabook", 2023, 1299.99, dell);
        Computer c2 = new Computer("ThinkPad X1 Carbon", "Business Laptop",	2023,	1499.99, lenovo);
        Computer c3 = new Computer("Pavilion 15",	"Consumer Laptop",	2022,	699.99,	hp);
        Computer c4 = new Computer("Inspiron 14",	"Budget Laptop",	2023,	549.99, dell);

        //XUỐNG DATABASE THẬT!!!!!!! CẦN REPOSITORY VÀ SERVICE
        userService.createUser(u1);
        userService.createUser(u2);
        userService.createUser(u3);

        manufacturerService.createManufacturer(dell);
        manufacturerService.createManufacturer(lenovo);
        manufacturerService.createManufacturer(hp);

        computerService.createComputer(c1);
        computerService.createComputer(c2);
        computerService.createComputer(c3);
        computerService.createComputer(c4);


    }
}





