package edu.fuhcm.lapshop.se678968.controller;

import edu.fuhcm.lapshop.se678968.entity.Computer;
import edu.fuhcm.lapshop.se678968.entity.Manufacturer;
import edu.fuhcm.lapshop.se678968.service.ComputerService;
import edu.fuhcm.lapshop.se678968.service.ManufacturerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/laptops")  //base url, nhân tử chung
                                //các hàm ở dưới nối tiếp url riêng của nó
public class LaptopController {

    @Autowired  //tiêm Computer Service để show list Laptops trong table <table>
    private ComputerService computerService;

    @Autowired //tiêm thêm Manu để gửi xuống màn hình detail list of NSX, NCC
               //phục vụ treo đầu dê (Name NSX) lấy thịt heo (ID NSX - lưu vào FK)
    private ManufacturerService manuService;

    @GetMapping()
    public String list(Model model) {
        //gửi 1 thùng sang trang laptops, chứa nguyên list select * from Computers
        model.addAttribute("laps", computerService.getAllComputers());
        // ram của trang List<Computer> laps = computerService.getAllComputers()
        //bên trang laptops.html xài biến laps, dùng for each thảy vào từng <tr> của tag <table>
        return "laptops";
    }

    //@GetMapping({"/laptops/edit/1", "/laptops/edit/2"})  //phục vụ cho url edit
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, Model model) {
        //ta có đc id của Laptop muốn edit rồi, gửi nó sang màn hình detail cho user edit
        //1. Hộp để gửi Laptop có id = 1, 2, 3....
        //2. Gọi trang detail, product-form
        //3. Trang product-form phải mở hộp, để lấy Laptop đc gửi để show
        //   * Có 2 kĩ thuật show info bên product-form (gồm cả treo đầu dê lấy thịt heo - combobox, dropdown)
        //   - binding lẻ từng field, từng ô nhập: th:value="${biến-hộp.tên-cột}"
        //                   @RequestParam   @RequestParam...
        //   - bingding object với mọi field, mọi ô nhập:  th:field="*{tên-cột}"
        //                   @ModelAttribute("objX") Computer x
        model.addAttribute("objX", computerService.getComputerById(id));

        model.addAttribute("manus", manuService.getAllManufacturers());
        //dành cho treo đầu dê!!!

        return "laptop-form";
    }

    @PostMapping("/save")  //bắt toàn bộ data từ dưới details gửi lên, có 2 cách bắt
    //@RequestParam("year") int year
    //...
    //@ModelAttribute("objX") Computer x
    public String save(@Valid @ModelAttribute("objX") Computer x,
                       BindingResult bindingResult, Model model) {
        //check validation trước cái đã, nếu có lỗi, dội ngược lại màn hình details Edit / Create
        if (bindingResult.hasErrors()) {
            //gửi lại objX bị error, kèm manus để show lại treo đầu dê...
            model.addAttribute("objX", x);
            model.addAttribute("manus", manuService.getAllManufacturers());
            return "laptop-form";
        }

        //gọi hàm save của bên Laptop Service, Service đi gọi Repo... -> hàm save() là hàm có sẵn bên repo rồi!!!
        //ta còn phải phân biệt giữa Create | và Update, save tạo mới hay save edit
        computerService.createComputer(x);  //làm đỡ chạy trước

        //xong rồi thì về màn hình list sản phẩm xem đã cập nhật chưa!!!
        return "redirect:/laptops";

    }

}

//   /laptops  -> show all
//   /laptops/edit/1   /2    /3
//   /laptops/delete/1   /2   /3
//   /laptops/create
//   /laptops/save      nhấn nút [Save] trên form nhập xài chung cho cả
//                                     edit và create
//   /