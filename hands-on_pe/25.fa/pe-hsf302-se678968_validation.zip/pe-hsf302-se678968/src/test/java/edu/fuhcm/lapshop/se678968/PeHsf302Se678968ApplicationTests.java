package edu.fuhcm.lapshop.se678968;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeHsf302Se678968ApplicationTests {

    @Test
    void contextLoads() {
    }

}
