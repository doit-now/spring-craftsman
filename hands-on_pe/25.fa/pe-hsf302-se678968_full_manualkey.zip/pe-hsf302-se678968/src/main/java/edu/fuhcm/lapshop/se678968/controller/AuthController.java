package edu.fuhcm.lapshop.se678968.controller;

import edu.fuhcm.lapshop.se678968.entity.User;
import edu.fuhcm.lapshop.se678968.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

//MỌI HÀNH ĐỘNG CỦA USER Ở PHÍA TRÌNH DUYỆT MUỐN SERVER THẤY ĐC, BIẾT ĐC, VÀ XỬ LÝ GIÚP THÌ HÀNH ĐỘNG NÀY PHẢI ĐI KÈM 1 URL
//URL NÀY PHẢI ÁNH XẠ - MAP VÀO 1 HÀM TRÊN CONTROLLER
//USER --- GỬI URL (GET, POST) --- LÊN CONTROLLER --- URL ĐC MAP / ĐI SONG HÀNH VỚI 1 HÀM / METHOD

//GET: DATA GỬI LÊN SERVER THÌ ĐI KÈM SAU URL (ĐỊA CHỈ GHI TRÊN PHONG BÌ)
//     NỘI DUNG BỨC THƯ (DATA) NẰM NGOÀI PHONG BÌ (Ở CẠNH URL - ĐỊA CHỈ)

//POST: DATA GỬI LÊN SERVER NẰM TRONG 1 PHONG BÌ (BODY) ĐI KÈM CÙNG URL (ĐỊA CHỈ GHI TRÊN PHONG BÌ)
//    NỘI DUNG BỨC THƯ (DATA) NẰM TRONG PHONG BÌ (ĐỊA CHỈ URL GHI BÊN NGOÀI PHONG BÌ)

//DATA ĐC GỬI LÊN SERVER (GET, POST) BẮT BUỘC PHẢI KHAI BÁO TRONG 1 TAG <form> Ở CLIENT

@Controller
public class AuthController {

    //khai báo biến UserService để authenticate(email, pass)
    //chích tiêm injection
    @Autowired
    private UserService service; //ko new mà chờ tiêm vào!!!
                                //khai báo interface để có loose coupling sau này

    //CẦN 1 HÀM ĐỂ HỨNG /XỬ LÝ / HANDLE HÀNH ĐỘNG GÕ URL ĐỂ VÀO TRANG LOGIN
    @GetMapping({"/", "/login", "/ngoctrinh"})
    public String login() {
        return "login";
    }

    //CẦN 1 HÀM ĐỂ HỨNG /XỬ LÝ / HANDLE HÀNH ĐỘNG NHẤN NÚT LOGIN
    @PostMapping("/auth")   //2 cách nhận data từ client/browser gửi lên:
                               //* @RequestParam("email") String email -> ô nhập email ở trình duyệt
                               //gửi value vào biến email trong code
                               //Cách này dở: form có nhiều ô nhập, thì hàm có nhiều biến tương ứng
                               //* Object binding, @ModelAttribute() User user
                               //Cả đám ô nhập dưới trình duyệt nay tụ họp chung trong biến user
                               //Cách này giảm thiểu tham số của hàm xử lí, nhận object luôn
                               //nhưng code bên html thymeleaf cần chỉnh thêm 1 chút trong các
                               //ô nhập  th:field *, thay vì th:value $
    public String authenticate(@RequestParam("email") String email,
                               @RequestParam("password") String pass,
                               RedirectAttributes box,
                               HttpSession sessionBox) {

        //có email, pass thì phải đi gọi Service giúp > Repo giúp > Spring Data (JPA/Hibernate)
        //                                                        > JDBC > SQL Server - Table

        //return "laptops";  //login thành công phải sang trang laptops, bị resubmission, do
                           //url vẫn là /auth

        User acc = service.authenticate(email, pass);  //có quyền gọi hàm email, password
        //User acc = service.authenticate(email);

        if (acc == null) {  //sai do email hoặc pass hoặc cả 2
            //gửi câu chửi về lại màn hình login
            box.addFlashAttribute("error", "Invalid email or password");
            return "redirect:/login";
        }
        //login thành công với email và pass
        //PHẢI CHECK XEM ACCOUNT CÓ ROLE == 1 (ADMIN) == 2 (MANAGER) THÌ  MỜI VÀO
        //CÒN ROLE == 3 (MEMBER), ĐI CHỖ KHÁC
        if (acc.getRole().equalsIgnoreCase("member")) {
            box.addFlashAttribute("error", "You have no permission to access this app");
            return "redirect:/login";
        }

        // cất trữ lâu dài thông tin login (account) để: in chào ở các màn hình phía sau
        //                                               check đã authen chưa khi chơi liều gõ url mấy trang phía sau, chửi nếu chưa login
        //SESSION MÃI ĐỈNH

        // , mời vào laptops.html
        sessionBox.setAttribute("loggedInUser", acc);
        return "redirect:/laptops";   //redirect để có url đúng
    }

    //CẦN THÊM 1 HÀM ĐỂ LOGOUT, USER CLICKS VVA2OLINK LOGOUT, TA XOÁ CÁI HỘP SESSION
    @GetMapping("/logout")
    public String logout(HttpSession sessionBox) {
        sessionBox.invalidate();
        return "redirect:/login";  //login mói tinh!!!
    }

}

//MANTRA:
//CONTROLLER / GUI --- SERVICE --- REPO --- JPA/HIBERNATE --- JDBC --- SQL SERVER - TABLE
//       !!!                                ---------------------------------------------
//    LAYER            LAYER      LAYER
//       3-LAYER ARCHITECTURE  (KO GHI 3 LAYERS)

//TODO: LÀM THÊM CHO PHẦN AUTHEN
//0: THÔNG BÁO CHI TIẾT HƠN: SAI EMAIL, SAI PASS, DÙNG HÀM CHỪA SẴN authenticate(email)

//1. NẾU BỊ LỖI LOGIN DO SAI EMAIL, PASS, THÌ THỘNG BÁO LỖI NHƯ ĐANG LÀM VÀ ĐỒNG THỜI SHOW LẠI ĐC CÁI EMAIL VÀ PASS ĐÃ GÕ! HIỆN NAY ĐANG TRỐNG TRƠN DO ĐANG LOAD LẠI TRANG LOGIN MỚI
//HINT: THÙNG BOX MODEL HOẶC REDIRECT-ATTRIBUTE MỚI CHỈ GỬI LẠI TRANG LOGIN MESSAGE LỖI, NÊN GỬI KÈM TRỞ LẠI CẶA85PEMAIL/PASS LÀ XONG!!!

//2. COUNT ĐẾM SỐ LẦN LOGIN BỊ SAI, 5 LẦN THÌ BLOCK/LOCK CÁI ACCOUTN LẠI - THÊM CỘT STATUS TRONG TABLE ACCOUNT
//  KHI GÕ EMAIL NÀY CHECK THÊM STATUS -> NẾU STATUS == INACTIVE -> CHỬI Ở MÀN HÌNH LOGIN CÂU CHỬI MỚI: ACCOUNT ĐANG BỊ KHOÁ, VUI LÒNG LIÊN HỆ ADMIN
