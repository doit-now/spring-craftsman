package edu.fuhcm.lapshop.se678968.service;

import edu.fuhcm.lapshop.se678968.entity.User;

public interface UserService {

    //CHỨA HÀM KO CÓ CODE, ĐỂ CRUD TABLE USER
    public void saveUser(User obj);

    //sẽ có 1 class tên là UserServiceImpl sẽ có code

    //HÀM LOGIN VỚI EMAIL VÀ PASS            -> THÔNG BÁO CHUNG CHUNG
    //HÀM LOGIN CHỈ VỚI EMAIL, PASS TÍNH SAU -> ĐỂ THÔNG BÁO CHI TIẾT HƠN
    public User authenticate(String email);
    public User authenticate(String email, String password);
    //over - load
}
