package edu.fuhcm.lapshop.se678968.service.impl;

import edu.fuhcm.lapshop.se678968.entity.Computer;
import edu.fuhcm.lapshop.se678968.repository.ComputerRepo;
import edu.fuhcm.lapshop.se678968.service.ComputerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service  //@Component
public class ComputerServiceImpl implements ComputerService {

    @Autowired
    private ComputerRepo repo;

    @Override
    public void saveComputer(Computer obj) {

        repo.save(obj); //hàm tự sinh
    }
    //hàm save() của Spring Data/JPA/Hibernate đóng 2 vai:
    //insert into Computer
    //update Computer set cột-x = value-nào đó... where id = ???
    //check coi key có tồn tại chưa, nếu chưa thì là insert, còn ngược lại là update


    @Override
    public List<Computer> getAllComputers() {
        return repo.findAll(); //hàm tự sinh có sẵn, biểu tượng chữ M
    }

    @Override
    public Computer getComputerById(long id) {
        return repo.findById(id).orElse(null);
    }  //có thể trả null hoặc 1 object Laptop match id

    @Override
    public void deleteComputer(long id) {
        repo.deleteById(id);
    }

    @Override
    public void deleteComputer(Computer obj) {
        repo.delete(obj);
    }
    //orElse và class Optional để giúp viết hàm trả về object
       //hoặc trả null mà ko cần viết if else
}
