package edu.fuhcm.lapshop.se678968.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "computers")
@NoArgsConstructor
@Data
public class Computer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "computer_id")
    private Long id;  //cột tự tăng dùng Long

    @Column(name = "computer_model", nullable = false, columnDefinition = "nvarchar(100)")
    //phần trên là của table
    @NotBlank(message = "The model is required!") //validation của code, khi new Computer
    @Size(min = 5, max = 50, message = "The model is 5...50 characters length!")
    private String model;

    @Column(name = "production_year", nullable = false)
    @Min(value = 1990, message = "Production year is in the range of 1990...2025")
    @Max(value = 2025, message = "Production year is in the range of 1990...2025")
    private int productionYear;

    @NotBlank(message = "The type is required!")
    @Column(name = "type", nullable = false, columnDefinition = "nvarchar(50)")
    private String type;

    @Min(value = 100, message = "Minimum price is 100")
    @Column(name = "price", nullable = false)
    private double price;

    //manufacturer_id FK  móc sang/ tham chiếu sang, trỏ sang table Manufacturer
    //ở cột manufacturer_id (PK)

    @ManyToOne
    @JoinColumn(name = "manufacturer_id")  //CỘT FK THEO GÓC NHÌN DB
    private Manufacturer manu;    //OOP: TUI 1 COMPUTER ĐANG ĐỨNG Ở ĐÂY

    //Constructor tự làm, gán luôn 1 manu cho máy tính đc new
    //new Computer(....., manuApple);

    public Computer(String model, String type, int productionYear, double price, Manufacturer manu) {
        this.model = model;
        this.productionYear = productionYear;
        this.type = type;
        this.price = price;
        this.manu = manu;
    }


//    public Manufacturer getManu() {
//        return manu;
//    }
//
//    public void setManu(Manufacturer manu) {
//        this.manu = manu;
//    }

    //THUỘC VỀ 1 NSX MANUFACTURER CỤ THỂ NÀO ĐÓ
                                  //TẠM GỌI LÀ manu
    //KO KHAI BÁO BIẾN KHOA NGOẠI KIỂU: private Long manufacturer_id

}



