package edu.fuhcm.lapshop.se678968.service;

import edu.fuhcm.lapshop.se678968.entity.User;

public interface UserService {

    //CHỨA HÀM KO CÓ CODE, ĐỂ CRUD TABLE USER
    public void createUser(User obj);

    //sẽ có 1 class tên là UserServiceImpl sẽ có code
}
