package edu.fuhcm.lapshop.se678968.service;

import edu.fuhcm.lapshop.se678968.entity.Computer;

public interface ComputerService {

    public void createComputer(Computer obj);
}
