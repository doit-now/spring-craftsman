package com.giaolang.ntcoffee.controller;


import com.giaolang.ntcoffee.entity.Product;
import com.giaolang.ntcoffee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/products") //base url
public class ProductController {

    //cần chơi DB, gọi Service lo cho
    @Autowired
    private ProductService productService; //service gọi repo...

    //hàm trả về full trang products, với table, crud button/link
    @GetMapping
    public String list(Model model) {
        //gửi kèm hộp danh sách sản phẩm để showlist

        List<Product> bag = productService.getAllProducts();
        model.addAttribute("prods", bag);

        //model.addAttribute("prods", productService.getAllProducts());
        return "products";
    }
}
