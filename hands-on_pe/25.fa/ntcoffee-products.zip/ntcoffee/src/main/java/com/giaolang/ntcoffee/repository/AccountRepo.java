package com.giaolang.ntcoffee.repository;

import com.giaolang.ntcoffee.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepo extends JpaRepository<Account,Long> {
    //JpaRepository là "class" đặc biệt có sẵn trong Spring nó có 1 loạt các hàm
    //chuẩn để CRUD 1 table bất kì, vì table nào cx sẽ có CRUD (insert into, select, update from, delete from)

}
