package com.giaolang.ntcoffee.config;

import com.giaolang.ntcoffee.entity.Account;
import com.giaolang.ntcoffee.entity.Category;
import com.giaolang.ntcoffee.entity.Product;
import com.giaolang.ntcoffee.service.AccountSerivce;
import com.giaolang.ntcoffee.service.CategoryService;
import com.giaolang.ntcoffee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component //class này implement, có code cho interface Runner, thằng này khi SpringBoot, Tomcat khởi động, run luôn cái hàm của class này, 1 hàm

public class DataInitializer implements CommandLineRunner {

    //CHÍCH TIÊM 3 ĐỨA SERVICE
    @Autowired
    private AccountSerivce accountSerivce;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private ProductService productService;

    @Override
    public void run(String... args) throws Exception {
        //TA CHUẨN BỊ INSERT DATA XUỐNG TABLE!!!!!!!!!!!!!
        //CODE FIRST
        //ACCOUNT
        Account ac1 = new Account("Administrator nè", "ad@gmail.com", "ad", 1);

        Account ac2 = new Account("Staff nè", "st@gmail.com", "st", 2);

        Account ac3 = new Account("Member nè", "mb@gmail.com", "mb", 3);

        accountSerivce.createAccount(ac1);
        accountSerivce.createAccount(ac2);
        accountSerivce.createAccount(ac3);

        Category cate1 = new Category("Bia rượu", "Không say không về...");
        Category cate2 = new Category("Cafe - Nước ngọt", "Say cafe hay say Ngọc Trinh...");
        Category cate3 = new Category("Bánh kẹo", "Ngọt ngào như Ngọc Trinh...");

        categoryService.createCategory(cate1);
        categoryService.createCategory(cate2);
        categoryService.createCategory(cate3);

        Product p1c1 = new Product("BR1", "Heineken", 24, 20_000, cate1);
        Product p2c1 = new Product("BR2", "333", 24, 18_000, cate1);
        Product p3c1 = new Product("BR3", "Saporo", 24, 30_000, cate1);

        Product p1c2 = new Product("CF1", "Cà phê Ngọc Trinh", 100, 25_000, cate2);
        Product p2c2 = new Product("CF2", "Lipovitan", 100, 12_000, cate2);
        Product p3c2 = new Product("CF3", "Bò cụng", 100, 15_000, cate2);

        Product p1c3 = new Product("BK1", "Bánh trung thu Kinh Đô", 100, 200_000, cate3);
        productService.createProduct(p1c1);
        productService.createProduct(p2c1);
        productService.createProduct(p3c1);
        productService.createProduct(p1c2);
        productService.createProduct(p2c2);
        productService.createProduct(p3c2);
        productService.createProduct(p1c3);

    }
}
