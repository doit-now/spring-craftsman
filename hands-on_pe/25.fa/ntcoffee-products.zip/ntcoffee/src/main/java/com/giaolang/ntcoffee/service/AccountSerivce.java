package com.giaolang.ntcoffee.service;

import com.giaolang.ntcoffee.entity.Account;

public interface AccountSerivce {

    //GUI --- CONTROLLER --- SERVICE --- REPO --- JPA/HIBERNATE --- JDBC --- TABLE
    public Account authenticate(String email, String pass);
    //TÌM THẤY CẶP EMAIL VÀ PASS THÌ RETURN ACCOUNT CÓ ROLE BÊN TRONG ĐỂ TA IF PHÂN QUYỀN
    //KO TÌM THẤY CĂP EMAIL/PASS THÌ RETURN NULL, LOGIN KO THÀNH CÔNG

    //HÀM INSERT DATA, TẠO MỚI 1 ACCOUNT. DÙNG TRONG VIỆC TỰ ĐỘNG TẠO DATA SẴN TRONG TABLE TỪ CODE - CODE FIRST
    public void createAccount(Account account);

}
