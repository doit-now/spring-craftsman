package com.giaolang.ntcoffee.service.impl;

import com.giaolang.ntcoffee.entity.Account;
import com.giaolang.ntcoffee.repository.AccountRepo;
import com.giaolang.ntcoffee.service.AccountSerivce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service //khi runtime, SpringBoot, IoC Container ơi, new giúp tôi để controller nó xài - BEAN
public class AccountServiceImpl implements AccountSerivce {

    //tiêm thằng Repo vào gíup
    //3 cách tiêm: field, constructor, setter
    @Autowired
    private AccountRepo repo;  //ko new, mà chờ chích vào

    @Override
    public Account authenticate(String email, String pass) {
        return null;
    }

    @Override
    public void createAccount(Account account) {
        repo.save(account);  //hàm save() có sẵn luôn trong Repo
    }
}
