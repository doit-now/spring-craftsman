package com.giaolang.ntcoffee.service;

import com.giaolang.ntcoffee.entity.Product;

import java.util.List;

public interface ProductService {

    //CLASS NÀY, ĐỦ FULL HÀM CRUD TABLE PRODUCT

    public List<Product> getAllProducts();

    public void createProduct(Product product);

    public void updateProduct(Product product);

    public void deleteProduct(Product product);

}