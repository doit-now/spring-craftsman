package com.giaolang.ntcoffee.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Account")
@NoArgsConstructor
@Data  //ko làm AllArgs vì key này tự tăng
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "Id")
    private Long id;

    @Column(name = "FullName", nullable = false, columnDefinition = "nvarchar(40)")
    private String fullName;

    @Column(name = "Email", nullable = false, length = 100)
    private String email;

    @Column(name = "Password", nullable = false, length = 30)
    private String password;

    @Column(name = "Role", nullable = false)
    private int role; //role: Admin 1, Staff 2, Member 3

    //KEY TỰ TĂNG THÌ KO ĐC LÀM CONSTRUCTOR CÓ FULL THAM SỐ.
    //TA CHẾ 1 CONSTRUCTOR HỤT THAM SỐ KEY

    public Account(String fullName, String email, String password, int role) {
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.role = role;
    }
}
