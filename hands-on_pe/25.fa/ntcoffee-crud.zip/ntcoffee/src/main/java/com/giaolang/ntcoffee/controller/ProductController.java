package com.giaolang.ntcoffee.controller;


import com.giaolang.ntcoffee.entity.Category;
import com.giaolang.ntcoffee.entity.Product;
import com.giaolang.ntcoffee.service.CategoryService;
import com.giaolang.ntcoffee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/products") //base url
public class ProductController {

    //cần chơi DB, gọi Service lo cho
    @Autowired
    private ProductService productService; //service gọi repo...

    @Autowired  //tiêm thêm cate service để select * from Category để xổ chọn
    private CategoryService categoryService;

    //hàm trả về full trang products, với table, crud button/link
    @GetMapping
    public String list(Model model) {
        //gửi kèm hộp danh sách sản phẩm để showlist

        List<Product> bag = productService.getAllProducts();
        model.addAttribute("prods", bag);

        //model.addAttribute("prods", productService.getAllProducts());
        return "products";
    }

    @GetMapping("/new")
    public String create(Model model) {

        //chắc chắn phải gửi kèm objX trống trơn để lát hồi còn save ngược trở lại, y chang thằng edit mode, nhưng khác edit gửi objX có data
        model.addAttribute("objX", new Product());
        model.addAttribute("formMode", "NEW");

        //PHẢI GỬI THÊM DANH SÁCH CATEGORY ĐỂ XỔ CHỌN, VẬY CẦN KHAI BÁO CATESERVICE
        List<Category> cates =  categoryService.getAllCategories();
        model.addAttribute("cates", cates);

        return "product-form";
    }

    @GetMapping("/edit/{id}")  //@PathVariable để trích ra đc cái id gửi lên
    //                       cắt ra đc id gửi lên thì sẽ edit đc 1 dòng cụ thể
    public String edit(@PathVariable("id") String id, Model model) {

        Product edited = productService.getProductById(id);  //dùng id lôi ra obj
        model.addAttribute("objX", edited);
        //gửi thêm flag, cờ, chỉ mode màn hình detail:
        model.addAttribute("formMode", "EDIT");

        //PHẢI GỬI THÊM DANH SÁCH CATEGORY ĐỂ XỔ CHỌN, VẬY CẦN KHAI BÁO CATESERVICE
        List<Category> cates =  categoryService.getAllCategories();
        model.addAttribute("cates", cates);

        return "product-form";  //chuyển hướng sang trang edit, gửi kèm objX
    }

    @PostMapping("/save")  //dành cho nút save, hàm post nhận toàn bộ các field ở
    //form edit gửi lên: có 2 cách nhận: nhận lẻ từng field @RequestParam
    //                                   nhận nguyên cục @ModelAttribute - object binding
    //                                   GỬI XUỐNG OBJECTE GÌ, NHẬN LÊN OBJECT ĐÓ
//    public String save(@RequestParam("id") String id,
//                       @RequestParam("name") String name,
//                       @RequestParam("price") double price, Model model) {
//
//    }
    public String save(@ModelAttribute Product obj, Model model, @RequestParam("form-mode")  String formMode) {

        //lấy đc chữ EDIT hoặc chữ NEW đã gửi xuống và nay submit trở lại
        //gọi service giúp save
        if  (formMode.equals("EDIT")) {
            productService.updateProduct(obj);  //obj đc binding từ form đem lên
        }
        else if (formMode.equals("NEW")) {
            productService.createProduct(obj);
        }

        return "redirect:/products";  //chuyển hướng về trang products để cập nhật edit mới
    }

    @GetMapping("/delete/{id}")  //@PathVariable để trích ra đc cái id gửi lên
    //                       cắt ra đc id gửi lên thì sẽ xoá đc 1 dòng cụ thể
    public String delele(@PathVariable("id") String id) {
        //id cần xoá đang nằm trong biến String id
        //ta cần gọi Service để giúp | gọi tiếp Repo | ORM Hibernate | JDBC | Table thật
        //                            ---------------------------------------------------
        //           Service là Controller sẽ xài
        Product deleted = productService.getProductById(id);  //dùng id lôi ra obj
        productService.deleteProduct(deleted); //xoá obj vừa tìm thấy

        return "redirect:/products";  //gọi lại hàm list ở trên qua url mới /products
    }

}
