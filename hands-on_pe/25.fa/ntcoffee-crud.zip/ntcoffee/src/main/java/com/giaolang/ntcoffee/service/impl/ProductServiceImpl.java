package com.giaolang.ntcoffee.service.impl;

import com.giaolang.ntcoffee.entity.Product;
import com.giaolang.ntcoffee.repository.ProductRepo;
import com.giaolang.ntcoffee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepo repo;

    @Override
    public List<Product> getAllProducts() {
        return repo.findAll();  //hàm tự sinh
    }

    @Override
    public void createProduct(Product product) {
        repo.save(product);  //hàm tự sinh
    }

    @Override
    public void updateProduct(Product product) {
        repo.save(product);  //hàm tự sinh
    }

    @Override
    public void deleteProduct(Product product) {
        repo.delete(product);   //hàm tự sinh
    }

    @Override
    public Product getProductById(String id) {
        return repo.findById(id).get();  //hàm tự sinh
    }  //thằng repo thuộc class/interface ProductRepo của mình
      //mà ProductRepo lại thuộc team JpaRepository<Product,String>
      //                              thằng này thuộc thư viện chuẩn
      //                              SpringData, nên nó tự sinh hàm cho mình
      //                              để CRUD 1 table nào đó
}
