package com.giaolang.ntcoffee.service.impl;


import com.giaolang.ntcoffee.entity.Category;
import com.giaolang.ntcoffee.repository.CategoryRepo;
import com.giaolang.ntcoffee.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired  //đừng quên class phải là bean thì mới tiêm vào đc
    private CategoryRepo repo; //ko new, tiêm vào

    @Override
    public void createCategory(Category cate) {
        repo.save(cate);  //hàm tự sinh của CateRepo
    }

    @Override
    public List<Category> getAllCategories() {
        return  repo.findAll();  //hàm tự sinh luôn từ repo
    }
}
