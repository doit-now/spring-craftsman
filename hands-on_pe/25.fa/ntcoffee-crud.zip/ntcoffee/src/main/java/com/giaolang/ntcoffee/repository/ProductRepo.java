package com.giaolang.ntcoffee.repository;

import com.giaolang.ntcoffee.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepo extends JpaRepository<Product,String> {
}
