package com.giaolang.dieudao.service;

import com.giaolang.dieudao.entity.Category;

import java.util.List;

public interface CategoryService {

    //CRUD CỦA TABLE CATEGORY NHƯNG CHỈ TÊN HÀM CHƯA CÓ CODE
    //LÁT HỒI CODE Ở BÊN IMPL/
    //BÊN IMPL/ CODE CHO SERVICE THÌ PHẢI GỌI REPO
    //MANTRA: GUI - CONTROLLER - SERVICE (IMPL) - REPO - SPRING-DATA/JPA/HIBERNATE - JDBC - TABLE

    //HÀM TRẢ VỀ ALL CATES ĐỂ LÁT HỒI ĐẨY VÀO Model box đẩy sang trang tạo mới trái cây, edit trái cây vì user muốn chọn trái cây thuộc category nào

    public List<Category> getAllCates(); //KO CÓ CODE, THÌ TA PHẢI IMPL

    //CREATE, UPDATE, DELETE, SEARCH, NHƯNG PE KO CẦN VÌ KO ĐỦ THỜI GIAN
    //NHƯNG SWP391 THÌ CẦN

    //NHƯNG BÊN FRUIT-SERVICE THÌ PHẢI CẦN FULL CRUD VÌ LÀ TABLE TRUNG TÂM CỦA APP
    //THÊM XOÁ SỬA TÌM KIẾM TRÁI CÂY!!!

}
