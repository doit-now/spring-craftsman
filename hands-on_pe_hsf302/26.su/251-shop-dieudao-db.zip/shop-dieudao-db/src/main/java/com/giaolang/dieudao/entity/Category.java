package com.giaolang.dieudao.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
//nếu muốn tên table tự độ riêng, ta dùng thêm @Table(name = "tên-table-riêng")
//mặc định lấy tên class làm tên table
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; //key tự tăng thì Long, hoặc UUID - hexa siêu dài

    //@Column(unique = true, length = 50) //SQL chuẩn sẽ ra varchar(50) unique
    @Column(unique = true, columnDefinition = "nvarchar(50)", nullable = false)
    private String name;

    @Column(columnDefinition = "nvarchar(200)", nullable = false)
    private String description;

    //KHI DÙNG CONSTRUCTOR TỰ LÀM, NHỚ CHECK XEM TABLE CÓ KEY TỰ TĂNG HAY KO THÌ KHI GENERATE XOÁ CỘT KEY TỰ TĂNG RA KHỎI CONSTRUCTOR
}
