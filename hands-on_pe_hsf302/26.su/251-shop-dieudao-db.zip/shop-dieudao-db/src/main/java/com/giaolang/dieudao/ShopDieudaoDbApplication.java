package com.giaolang.dieudao;

import com.giaolang.dieudao.entity.Category;
import com.giaolang.dieudao.repository.CategoryRepository;
import com.giaolang.dieudao.service.CategoryService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.util.List;

@SpringBootApplication
public class ShopDieudaoDbApplication {

    public static void main(String[] args) {
        ApplicationContext ctx = SpringApplication.run(ShopDieudaoDbApplication.class, args);

        //lệnh trên là tạo vùng RAM để chứa các bean (obj đc new tự động)
        //mình chỉ việc getBean() để dùng object, hoặc trong code sẽ dùng DI - Dependency Injection qua @Autowire học rồi

        CategoryRepository repo = (CategoryRepository) ctx.getBean("categoryRepository");
        //tạo object rồi save, tạo object new truyền thống hoặc Builder
        Category c1 = Category.builder()
                .name("Trái cây VietGAP")
                .description("Trái cây VN đc sản xuất trên quy trình...")
                .build();

        Category c2 = Category.builder()
                .name("Trái cây nhập khẩu")
                .description("Trái cây nhập khẩu có tem kiểm định...")
                .build();

        repo.save(c1);
        repo.save(c2);
        //lấy tất cả và show ra sau khi insert xong
//        List<Category> cates = repo.findAll();
//        System.out.println("The list of cates");
//        for (Category x : cates) {
//            System.out.println(x);
//        }

        CategoryService service = (CategoryService) ctx.getBean("categoryService");
        List<Category> cates = service.getAllCates();
        System.out.println("The list of cates");
        for (Category x : cates) {
            System.out.println(x);
        }


    }


}
