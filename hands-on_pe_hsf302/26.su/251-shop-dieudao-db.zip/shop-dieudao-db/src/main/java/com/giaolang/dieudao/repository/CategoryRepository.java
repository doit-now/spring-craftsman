package com.giaolang.dieudao.repository;

import com.giaolang.dieudao.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface CategoryRepository extends JpaRepository<Category,Long> {
}
//SPRING DATA SẼ TỰ LO CÁC HÀM CRUD CƠ BẢN CHO BẠN, BẠN CHỈ KHAI BÁO INTERFACE NÀY, LÚC RUNTIME, SPRING SẼ TỰ LÀM HÀM CRUD TRÊN TABLE CATEGORY CHO BẠN, NÓ BIẾT KEY LÀ LONG DO MÌNH KHAI BÁO RỒI

//mình chỉ việc đóng gói các hàm crud ở đây thành crud bên Service layer
//3-LAYER ARCHITECTURE


