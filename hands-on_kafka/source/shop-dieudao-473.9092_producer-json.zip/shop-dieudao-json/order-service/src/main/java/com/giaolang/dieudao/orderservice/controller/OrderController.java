package com.giaolang.dieudao.orderservice.controller;

import com.giaolang.dieudao.common.dto.OrderCreatedEvent;
import com.giaolang.dieudao.orderservice.dto.CreateOrderRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/v10/orders")
@RequiredArgsConstructor
public class OrderController {


    private final KafkaTemplate<String, OrderCreatedEvent> kafkaTemplate;

    @PostMapping //thành công trả status 201 và mã đơn hàng đc generate tự động, tự tăng
    public ResponseEntity<String> createOrder(@RequestBody CreateOrderRequest request){
        //nhờ Service - Repo - JPA - JDBC - table thật, save table Order, OrderDetail, và nhận về mã đơn hàng tự tăng'
        String orderId = UUID.randomUUID().toString(); //giả bộ xuống table và lấy đc key tự tăng

        //chuẩn bị message đưa lên kafka
        OrderCreatedEvent msg = new OrderCreatedEvent();
        msg.setOrderId(orderId);
        msg.setUserId(request.getUserId()); //lấy user trong request từ React
        msg.setAmount(request.getAmount());
        //gửi thông tin lên Kafka: mã đơn, mã k/h lấy từ request React, amount
        kafkaTemplate.send("ngoctrinh_mess", msg);  //topic và message
        //return mã đơn hàng ngay - BẤT ĐỒNG BỘ
        return ResponseEntity.status(HttpStatus.CREATED).body(orderId); //trả về id
    }
}
