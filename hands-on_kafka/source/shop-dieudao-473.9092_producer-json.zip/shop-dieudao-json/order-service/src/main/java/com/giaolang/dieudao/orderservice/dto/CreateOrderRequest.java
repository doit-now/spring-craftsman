package com.giaolang.dieudao.orderservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

// orderservice.dto.CreateOrderRequest
public class CreateOrderRequest {

    // FE gửi lên BE thông tin đơn hàng cần tạo
    // là 1 con JSON gồm {userId, amount, ...}

    private String userId;  // user nào mua hàng
    private double amount;  // tổng giá trị đơn hàng
    // ...                  // các thông tin khác về đơn hàng cần tạo
}

