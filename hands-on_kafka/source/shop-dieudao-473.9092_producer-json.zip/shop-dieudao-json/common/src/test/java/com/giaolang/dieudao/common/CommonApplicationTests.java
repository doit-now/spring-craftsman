package com.giaolang.dieudao.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonApplicationTests {

    @Test
    void contextLoads() {
    }

}
