package com.giaolang.dieudao.common.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
// common.dto.OrderCreatedEvent
public class OrderCreatedEvent {

    // Khi đơn hàng được tạo mới thành công, Order-Service sẽ báo tin ngay
    // lên Kafka server 1 con JSON: {đơn-id-tự-tăng, user-id, tổng-tiền, ...}
    // để User-Service và các Service khác nghe, biết, và xử lý bất đồng bộ,
    // các Service cứ từ từ lấy con JSON này mà làm...

    private String orderId;   // order-id vừa tạo thành công
    private String userId;    // user nào đã mua hàng
    private double amount;    // tổng trị giá đơn hàng
}
    //khi đơn hàng đc tạo mới thành công, ta báo ngay cho bên
    //User-Service rằng đơn hàng có mã số order-id, thuộc user-id với tổng tiền là amount, thảy lên bảng tin Kafka ở hòm thư ngoctrinh_mess
    //Bên User-Service cùng xài chung class này để lấy thông tin ra từ Kafka


