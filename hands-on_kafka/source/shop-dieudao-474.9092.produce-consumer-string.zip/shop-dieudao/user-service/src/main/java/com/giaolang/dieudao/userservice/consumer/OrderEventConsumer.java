package com.giaolang.dieudao.userservice.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class OrderEventConsumer {

    //code để đọc tin từ kênh, từ hộp thư, từ topic -> ngoctrinh_message
    //cơ chế lắng nghe tin từ bảng tin Kafka - Listener
    //khai báo Kafka server ở đâu: thông qua cổng Docker 9092:9092
    //khai báo cách đọc tin đc gửi, giải mã tin gửi - decode, Deserializer
    //bên gửi mã hoá thông tin gửi trên đường truyền, encode, Serializer
    @KafkaListener(topics = "ngoctrinh_mess", groupId = "user-group")
    public void handleOrderCreatedEvent(String message) {
        //                      chuẩn là phải gửi 1 DTO, event DTO
        //tui đọc đc từ kênh hộp thư ngoctrinh_mess 1 cái chuỗi bên Order-Service gửi lên
        //TODO: CỘNG ĐIỂM CHO KHÁCH HÀNG THÂN THIẾT TUỲ VÀO SỐ TIỀN TRONG ĐƠN HÀNG KHÁCH ĐÃ MUA ĐC GỬI LÊN KAFKA, TÍCH ĐIỂM
        System.out.println("TÍCH ĐIỂM THÀNH CÔNG..."); //code công thức tích điểm
        System.out.println("DEBUG: MESSAGE FROM ORDER SERVICE SENT VIA KAFKA" + message);
    }
}
