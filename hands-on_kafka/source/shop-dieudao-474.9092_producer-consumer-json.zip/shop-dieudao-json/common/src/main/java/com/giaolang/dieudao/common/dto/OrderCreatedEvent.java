package com.giaolang.dieudao.common.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder //giúp new object style . . . .build()
public class OrderCreatedEvent {
    // class trung gian chứa message gửi qua lại giữa các Service
    // object tạo từ class này sẽ đẩy lên 1 topic/kênh nào đó của Kafka
    // khi 1 order đc tạo mới, info cơ bản của order đc đẩy lên Kafka để
    // service khác căn theo thông tin này gài business rule tương ứng
    // ví dụ: đơn hàng order-100 của anh A có tổng tiền là 1 triệu
    //                               -> tích điểm cho anh í theo tổng tiền
    private String orderId;
    private String userId;
    private double amount;
}
