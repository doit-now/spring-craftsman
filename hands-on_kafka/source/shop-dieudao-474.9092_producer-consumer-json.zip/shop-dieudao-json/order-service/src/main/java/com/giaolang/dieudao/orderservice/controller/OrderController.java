package com.giaolang.dieudao.orderservice.controller;

import com.giaolang.dieudao.common.dto.OrderCreatedEvent;
import com.giaolang.dieudao.orderservice.dto.CreateOrderRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
public class OrderController {

    @Autowired
    private KafkaTemplate<String, OrderCreatedEvent> sender;

    // hàm post, nhận json CreateOrderRequest từ FE gửi lên
    @PostMapping("dieudao/fruits")
    public ResponseEntity<String> createOrder(@RequestBody CreateOrderRequest request){

        // 1. giả bộ generate 1 mã đơn hàng ngẫu nhiên từ table, từ DB, từ OrderService
        // 2. tạo mới message chuẩn bị gửi lên Kafka - triệu hồn thằng ku common OrderCreatedEvent
        // 3. Kafka, tớ đẩy message OrderCreatedEvent
        // 4. asyns, trả liền 201 CREATE thành công, ko chờ bên kia xử lý message, cộng điểm thành viên từ từ mà làm
        String orderId = UUID.randomUUID().toString(); //mã hexa dài

        //OrderCreatedEvent message = new OrderCreatedEvent(...); //new truyền thống qua constructor và setter()
        OrderCreatedEvent message = OrderCreatedEvent.builder()
                .userId(request.getUserId())
                .amount(request.getAmount())
                .orderId(orderId)
                .build();

        //gửi object event lên kênh ngoctrinh_mess bên server Kafka
        sender.send("ngoctrinh_mess", message);

        return ResponseEntity.status(HttpStatus.CREATED).body("Mã đơn hàng tạo thành công: " + orderId); //trả về mã đơn
    }
}
