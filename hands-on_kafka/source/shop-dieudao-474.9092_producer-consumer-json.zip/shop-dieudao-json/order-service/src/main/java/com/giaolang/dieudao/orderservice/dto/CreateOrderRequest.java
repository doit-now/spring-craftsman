package com.giaolang.dieudao.orderservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class CreateOrderRequest {

    private String userId;
    private double amount;
    // ... chi tiết đơn hàng ...
    // mã đơn hàng sẽ do Controller và Service lo sau khi request này từ FE -> JSON-> BE -> Controller -> object xử lý
}
