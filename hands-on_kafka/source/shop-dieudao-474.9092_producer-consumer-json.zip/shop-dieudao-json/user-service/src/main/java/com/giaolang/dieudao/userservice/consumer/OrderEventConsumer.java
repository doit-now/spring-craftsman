package com.giaolang.dieudao.userservice.consumer;

import com.giaolang.dieudao.common.dto.OrderCreatedEvent;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class OrderEventConsumer {

    // groupId mang ý nghĩa: nhiều instance, nhiều server cùng nhào vào
    // kênh ngoctrinh_mess để đọc message và để tích điểm cho k/h
    // tránh việc đọc lại tin đã xử lý, cho các instance vào cùng 1 nhóm độc giả
    // thì Kafka tự biết chia số lượng tin đều cho các instance, ko giẫm chân nhau
    // khi xử lí tích điểm
    // lát hồi khai báo thêm bên file application.yaml .properties
    @KafkaListener(topics = "ngoctrinh_mess", groupId = "user-group")
    public void handleOrderCreatedEvent(OrderCreatedEvent msg) {
        // TODO: rã msg để lấy msg.userId, lấy msg.amount và cộng điểm tích luỹ
        // cho thành viên tương ứng - lưu DB

        //đẩy Kafka báo user đã tích thêm bao nhiêu điểm để bên React FE noti khách đã tích điểm

        //debug: in thử xem message nhận từ bên Order-Service
        System.out.println("LOG: message receives from Order-Service: " + msg);
        // lát hồi sẽ thấy ra toString() của OrderCreatedEvent: order-id, user-id, amount, trong đó order-id là chuỗi hexa dài thật dài
    }

}
