package com.giaolang.dieudao.orderservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v6/orders") //base url
public class OrderService {

    @Autowired  //DI dependency injection
    private KafkaTemplate<String, String> msgSender;

    @PostMapping//chuẩn nhận vào DTO, trả về 201
    public void createOrder(@RequestBody String order) {

        //TODO: CREATE ORDER QUA REPOSITORY

        //EXTRA - BUSINESS RULES:
        //- gửi tin nhắn báo cho bên User-Service cập nhật điểm thành viên theo tổng tiền đơn hàng
        //- gửi noti cho bên Noti-Service liên quan đến SMS, GHN, GHTK...
        //- ...
        //có độ trễ, ko lẽ mình - createOrder ngồi chờ - SYNC

        //KO CHỜ, GỬI NOTI VÀ RETURN LUÔN, ASYNC
        //GỌI KAFKA GỬI TIN, RETURN LUÔN,
        //TIÊM KAFKA VÀO, GỬI TỔNG TIỀN LÊN TOPIC "order-created"
        msgSender.send("order-created", order);
        //                    topic         info gửi: chuỗi, JSON...

        //return 201
        System.out.println("DEBUG: CREATE ORDER & SEND MESSAGE SUCCESSFULLY!!!: " + order);
        //LOG: THẤY ĐC MESSAGE NÀY NGHĨA LÀ BÊN KIA (CONSUME MESSAGE BÊN NÀY GỬI) LÀM LÚC NÀO MÌNH KO CẦN BIẾT
    }
}
