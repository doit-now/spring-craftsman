package com.giaolang.orderservice.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v10/orders")  //base url
public class OrderController {

    //KHAI BÁO BIẾN DÙNG THƯ VIỆN KAFKA
    @Autowired //new giùm và tiêm vào. Object dùng gửi tin nhắn
    private KafkaTemplate<String,String> kafkaTemplate;

    //order tạo thành công gửi tổng tiền cho bên user-service để + điểm thành viên
    @PostMapping
    public void createOrder(@RequestBody String order){
        //nhận vào JSON chứa thông tin đơn hàng, save DB

        //extra báo tin cho User Service biết đơn tổng bao tiền - gửi vào hộp thư Kafka tên là created-order -> topic
        //ko chờ thằng kia + điểm mới thoát hàm, dừng luôn đc
        kafkaTemplate.send("ngoctrinh_mess", order);

        System.out.println("DEBUG: THE 'CREATE ORDER' IS DONE!");
    }
}
