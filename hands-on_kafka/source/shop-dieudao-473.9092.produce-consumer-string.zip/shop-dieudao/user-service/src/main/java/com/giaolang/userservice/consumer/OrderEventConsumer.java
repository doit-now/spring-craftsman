package com.giaolang.userservice.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class OrderEventConsumer {

    @KafkaListener(topics = "ngoctrinh_mess", groupId = "user-group")
    public void handleOrderCreated(String message) {

        System.out.println("DEBUG: ORDER SERVICE HAS SENT MESSAGE: " + message);

        //TODO: ĐỌC THÔNG TIN DTO GỬI SANG TỪ ORDER-SERVICE
        //LÀM PHÉP CỘNG ĐIỂM THÀNH VIÊN TỪ MESSAGE GỬI SANG

    }
}
