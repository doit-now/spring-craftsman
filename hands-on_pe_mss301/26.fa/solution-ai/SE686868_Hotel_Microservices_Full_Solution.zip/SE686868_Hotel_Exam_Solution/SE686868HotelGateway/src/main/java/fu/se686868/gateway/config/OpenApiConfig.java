package fu.se686868.gateway.config;

import org.springframework.context.annotation.*;
import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.*;
/** Gateway Swagger có 3 definitions: Gateway, Room (proxy), Reservation (proxy). */
@Configuration
public class OpenApiConfig {
 @Bean OpenAPI gatewayApi(){return new OpenAPI().info(new Info().title("SE686868 Hotel Gateway API").version("1.0"));}
}