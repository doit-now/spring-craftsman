package fu.se686868.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/** ĐIỂM KHỞI ĐỘNG: chạy độc lập từng service, JDK 25. */
@SpringBootApplication

public class HotelGatewayApplication { public static void main(String[] args) { SpringApplication.run(HotelGatewayApplication.class,args); } }