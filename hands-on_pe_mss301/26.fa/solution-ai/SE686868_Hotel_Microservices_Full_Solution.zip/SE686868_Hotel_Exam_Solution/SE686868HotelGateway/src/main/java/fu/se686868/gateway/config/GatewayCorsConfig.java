package fu.se686868.gateway.config;

import org.springframework.context.annotation.*;
import org.springframework.web.cors.*;
import org.springframework.web.cors.reactive.*;
/** CORS đơn giản: một CorsWebFilter tại Gateway, không cấu hình lặp tại services.
 * Chỉ dùng wildcard cho bài thi; production cần danh sách origin cụ thể.
 */
@Configuration
public class GatewayCorsConfig {
 @Bean CorsWebFilter corsWebFilter(){
  CorsConfiguration cors=new CorsConfiguration();
  cors.addAllowedOriginPattern("*");cors.addAllowedMethod("*");cors.addAllowedHeader("*");
  cors.setAllowCredentials(false);
  UrlBasedCorsConfigurationSource source=new UrlBasedCorsConfigurationSource();
  source.registerCorsConfiguration("/**",cors);
  return new CorsWebFilter(source);
 }
}