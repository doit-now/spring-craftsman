package fu.se686868.gateway.config;

import org.springframework.context.annotation.*;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;
/** Đề có Spring Security nhưng KHÔNG quy định đăng nhập: permitAll để Swagger/Test API chạy.
 * Khi đưa vào production phải thêm authentication/authorization, không dùng cấu hình này.
 */
@Configuration
public class GatewaySecurityConfig {
 @Bean SecurityWebFilterChain filterChain(ServerHttpSecurity http){
  return http.csrf(ServerHttpSecurity.CsrfSpec::disable)
   .authorizeExchange(exchanges->exchanges.anyExchange().permitAll()).build();
 }
}