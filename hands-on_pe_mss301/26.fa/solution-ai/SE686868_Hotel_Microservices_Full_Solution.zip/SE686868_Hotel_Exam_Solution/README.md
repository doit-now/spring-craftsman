# SE686868 - Hotel Microservices - Hướng dẫn nhanh

**JDK 25 | Spring Boot 4.1.2 | Spring Cloud 2025.1.4 | SQL Server 2016+**

## 3 projects (mở POM cha trong IntelliJ)
- `SE686868RoomService` - 8081 - Spring MVC/JPA - swagger: http://localhost:8081/swagger-ui.html
- `SE686868ReservationService` - 8082 - Spring MVC/JPA/OpenFeign - swagger: http://localhost:8082/swagger-ui.html
- `SE686868HotelGateway` - 8080 - Spring Cloud Gateway **WebFlux** - swagger tổng hợp: http://localhost:8080/swagger-ui.html

## Chạy
1. Cài JDK 25; chọn Project SDK=25; Maven dùng JDK 25.
2. Tạo database và bảng bằng `database/01_schema.sql`, rồi chọn chạy `02_seed.sql` nếu DB trống.
3. Đổi `DB_PASSWORD` phù hợp với SQL Server. Ví dụ PowerShell: `$env:DB_PASSWORD="your-password"`.
4. Tại thư mục root: `mvn clean test` (kiểm tra unit tests), sau đó `mvn clean package`.
5. Chạy từng application theo thứ tự: Room -> Reservation -> Gateway (IntelliJ Run).
   Hoặc mở 3 terminal (Windows):
   `mvn -pl SE686868RoomService spring-boot:run`
   `mvn -pl SE686868ReservationService spring-boot:run`
   `mvn -pl SE686868HotelGateway spring-boot:run`
6. Test theo cổng Gateway 8080, hoặc dùng Swagger của từng service.

## Ví dụ POST
`POST http://localhost:8080/api/rooms`
```json
{"roomNumber":"D-401","roomType":"DOUBLE","pricePerNight":900000,"capacity":2,"floor":4}
```
`POST http://localhost:8080/api/reservations`
```json
{"guestName":"Nguyen Van A","guestEmail":"a@example.com","guestPhone":"0901234567","checkInDate":"15/12/2026","checkOutDate":"18/12/2026","numberOfGuests":2,"roomId":1}
```
> Room 1 phải AVAILABLE; ngày 15-18/12 tính **3 đêm**. Không tin `totalAmount` trong request.

## Ghi chú
- `PUT` cập nhật từng trường theo đề; về REST thông thường đây là semantic của PATCH.
- `DELETE` cả 2 dịch vụ thực hiện thay đổi status, không xóa row.
- Cả hai service chia sẻ cùng database **do đề yêu cầu foreign key**, không phải mô hình database-per-service chuẩn.
- Port, Swagger UI và chi tiết business rule xem `GHI_CHU_ON_TAP.md` nằm **bên ngoài source code**.
- Không đưa mật khẩu thật vào Git. Gateway Security `permitAll` chỉ để ôn thi.
