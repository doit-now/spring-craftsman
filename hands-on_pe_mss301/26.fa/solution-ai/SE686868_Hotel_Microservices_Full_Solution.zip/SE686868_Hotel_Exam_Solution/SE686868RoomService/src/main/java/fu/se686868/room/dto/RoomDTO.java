package fu.se686868.room.dto;

import fu.se686868.room.entity.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
/** Create: bắt buộc trường; Update: cho phép null để giữ nguyên dữ liệu (partial update theo đề). */
public record RoomDTO(Long roomId,
 @Size(max=20) String roomNumber,
 RoomType roomType,
 @DecimalMin("0.01") BigDecimal pricePerNight,
 @Min(1) @Max(10) Integer capacity,
 @Min(1) Integer floor,
 RoomStatus status) { }
