package fu.se686868.room.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import fu.se686868.room.entity.Room;
public interface RoomRepository extends JpaRepository<Room,Long> {
 boolean existsByRoomNumberIgnoreCase(String roomNumber);
 @org.springframework.data.jpa.repository.Query("select r from Room r where (:type is null or r.roomType = :type) and (:status is null or r.status = :status)")
 org.springframework.data.domain.Page<Room> search(@org.springframework.data.repository.query.Param("type") fu.se686868.room.entity.RoomType type, @org.springframework.data.repository.query.Param("status") fu.se686868.room.entity.RoomStatus status, org.springframework.data.domain.Pageable pageable);
 boolean existsByRoomNumberIgnoreCaseAndRoomIdNot(String roomNumber,Long roomId);
}