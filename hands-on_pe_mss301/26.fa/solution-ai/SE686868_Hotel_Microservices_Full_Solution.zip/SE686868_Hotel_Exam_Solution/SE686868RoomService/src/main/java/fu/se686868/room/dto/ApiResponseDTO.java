package fu.se686868.room.dto;

import java.time.Instant;
import java.time.format.DateTimeFormatter;
/** Hợp đồng JSON chung: status (mã nghiệp vụ), data, timestamp ISO-8601, message. */
public record ApiResponseDTO<T>(int status, T data, String timestamp, String message) {
 public static <T> ApiResponseDTO<T> ok(T data) {return new ApiResponseDTO<>(1,data,DateTimeFormatter.ISO_INSTANT.format(Instant.now()),"Successful");}
 public static ApiResponseDTO<Void> error(int status, String message) {return new ApiResponseDTO<>(status,null,DateTimeFormatter.ISO_INSTANT.format(Instant.now()),message);}
}