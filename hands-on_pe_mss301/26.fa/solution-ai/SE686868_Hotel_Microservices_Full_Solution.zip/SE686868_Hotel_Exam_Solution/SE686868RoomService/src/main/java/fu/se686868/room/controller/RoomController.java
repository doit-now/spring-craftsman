package fu.se686868.room.controller;

import fu.se686868.room.dto.*;
import fu.se686868.room.entity.*;
import fu.se686868.room.service.RoomService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
/** REST /api/rooms. GHI NHỚ: Controller không truy cập Repository trực tiếp. */
@RestController @RequestMapping("/api/rooms")
public class RoomController {
 private final RoomService service;
 public RoomController(RoomService service){this.service=service;}
 @PostMapping public ResponseEntity<?> create(@Valid @RequestBody RoomDTO d){return ResponseEntity.status(201).body(ApiResponseDTO.ok(service.create(d)));}
 @PutMapping("/{roomId}") public ApiResponseDTO<?> update(@PathVariable long roomId,@Valid @RequestBody RoomDTO d){return ApiResponseDTO.ok(service.update(roomId,d));}
 @GetMapping("/{roomId}") public ApiResponseDTO<?> get(@PathVariable long roomId){return ApiResponseDTO.ok(service.get(roomId));}
 @DeleteMapping("/{roomId}") public ApiResponseDTO<?> maintenance(@PathVariable long roomId){service.maintenance(roomId);return ApiResponseDTO.ok(null);}
 @GetMapping public ApiResponseDTO<?> list(@RequestParam(defaultValue="0") int page,@RequestParam(defaultValue="10") int size,@RequestParam(required=false) RoomType roomType,@RequestParam(required=false) RoomStatus status){return ApiResponseDTO.ok(service.list(page,size,roomType,status));}
}