package fu.se686868.room.common;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import jakarta.validation.ConstraintViolationException;
import fu.se686868.room.dto.ApiResponseDTO;
/** GHI NHỚ: lỗi validation theo đề HTTP 406/status=2 (khác thông lệ REST thường là 400). */
@RestControllerAdvice
public class GlobalExceptionHandler {
 @ExceptionHandler(BusinessException.class)
 public ResponseEntity<?> business(BusinessException e){return ResponseEntity.status(e.http()).body(ApiResponseDTO.error(e.status(),e.getMessage()));}
 @ExceptionHandler({MethodArgumentNotValidException.class,ConstraintViolationException.class,MethodArgumentTypeMismatchException.class,org.springframework.http.converter.HttpMessageNotReadableException.class,org.springframework.web.bind.MissingServletRequestParameterException.class,IllegalArgumentException.class})
 public ResponseEntity<?> validation(Exception e){return ResponseEntity.status(406).body(ApiResponseDTO.error(2,"Invalid input: "+e.getMessage()));}
 @ExceptionHandler(Exception.class)
 public ResponseEntity<?> unexpected(Exception e){
  // Không tiết lộ stack trace, SQL, mật khẩu cho client; log ở phía server.
  org.slf4j.LoggerFactory.getLogger(getClass()).error("Unexpected error",e);
  return ResponseEntity.status(500).body(ApiResponseDTO.error(0,"Internal server error"));
 }
}