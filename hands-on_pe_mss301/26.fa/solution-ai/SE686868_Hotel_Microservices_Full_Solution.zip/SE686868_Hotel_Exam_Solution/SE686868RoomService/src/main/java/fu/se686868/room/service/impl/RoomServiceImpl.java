package fu.se686868.room.service.impl;

import fu.se686868.room.common.BusinessException;
import fu.se686868.room.dto.*;
import fu.se686868.room.entity.*;
import fu.se686868.room.repository.RoomRepository;
import fu.se686868.room.service.RoomService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.http.HttpStatus;
import org.springframework.data.domain.*;
import java.math.BigDecimal;
import java.util.*;
/** BUSINESS RULE: số phòng là duy nhất; price > 0; capacity 1..10; floor >=1;
 * DELETE là SOFT DELETE -> MAINTENANCE, không xóa dòng DB.
 */
@Service @Transactional
public class RoomServiceImpl implements RoomService {
 private final RoomRepository repo;
 public RoomServiceImpl(RoomRepository repo){this.repo=repo;}
 private Room find(long id){return repo.findById(id).orElseThrow(()->new BusinessException(HttpStatus.NOT_FOUND,4,"Room not found"));}
 private RoomDTO dto(Room r){return new RoomDTO(r.roomId,r.roomNumber,r.roomType,r.pricePerNight,r.capacity,r.floor,r.status);}
 private void check(Room r){
  if(r.roomNumber==null||r.roomNumber.isBlank()||r.roomNumber.length()>20||r.roomType==null||r.pricePerNight==null||r.pricePerNight.compareTo(BigDecimal.ZERO)<=0||r.capacity==null||r.capacity<1||r.capacity>10||r.floor==null||r.floor<1||r.status==null)
   throw new BusinessException(HttpStatus.NOT_ACCEPTABLE,2,"Invalid room fields (number, type, price, capacity, floor, status)");
 }
 @Override public RoomDTO create(RoomDTO d){
  Room r=new Room();apply(r,d);r.status=RoomStatus.AVAILABLE; // BR: default khi tạo.
  check(r); duplicate(r.roomNumber,null);
  return dto(repo.saveAndFlush(r));
 }
 @Override public RoomDTO update(long id,RoomDTO d){
  Room r=find(id); apply(r,d);check(r);duplicate(r.roomNumber,id);
  return dto(repo.saveAndFlush(r));
 }
 private void apply(Room r,RoomDTO d){
  if(d.roomNumber()!=null)r.roomNumber=d.roomNumber();if(d.roomType()!=null)r.roomType=d.roomType();
  if(d.pricePerNight()!=null)r.pricePerNight=d.pricePerNight();if(d.capacity()!=null)r.capacity=d.capacity();
  if(d.floor()!=null)r.floor=d.floor();if(d.status()!=null)r.status=d.status();
 }
 private void duplicate(String number,Long current){
  boolean exists=current==null?repo.existsByRoomNumberIgnoreCase(number):repo.existsByRoomNumberIgnoreCaseAndRoomIdNot(number,current);
  if(exists) throw new BusinessException(HttpStatus.IM_USED,3,"Duplicate room number"); // 226 là HTTP theo đề, không phải REST thông lệ.
 }
 @Override @Transactional(readOnly=true) public RoomDTO get(long id){return dto(find(id));}
 @Override public void maintenance(long id){
  Room r=find(id);r.status=RoomStatus.MAINTENANCE; // BR: phòng bảo trì KHÔNG nhận đặt mới.
  repo.save(r);
 }
 @Override @Transactional(readOnly=true) public PageDTO<RoomDTO> list(int page,int size,RoomType type,RoomStatus status){
  if(page<0||size<1||size>100)throw new BusinessException(HttpStatus.NOT_ACCEPTABLE,2,"page>=0, size=1..100");
  // Bài thi ít dữ liệu: lọc qua JPA Specification thay vì lọc List sau phân trang.
  // Dùng query JPQL có optional filter và pageable.
  Page<Room> result=repo.findAll(PageRequest.of(page,size));
  if(type==null&&status==null)return PageDTO.from(result.map(this::dto));
  // Với filter phải filter TẠI DB trước khi phân trang (đã định nghĩa query repository ở dưới).
  return PageDTO.from(repo.search(type,status,PageRequest.of(page,size)).map(this::dto));
 }
}