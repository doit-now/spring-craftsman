package fu.se686868.room.service;

import fu.se686868.room.dto.*;
import fu.se686868.room.entity.*;
import org.springframework.data.domain.Page;
public interface RoomService {
 RoomDTO create(RoomDTO input);
 RoomDTO update(long id,RoomDTO input);
 RoomDTO get(long id);
 void maintenance(long id);
 PageDTO<RoomDTO> list(int page,int size,RoomType type,RoomStatus status);
}