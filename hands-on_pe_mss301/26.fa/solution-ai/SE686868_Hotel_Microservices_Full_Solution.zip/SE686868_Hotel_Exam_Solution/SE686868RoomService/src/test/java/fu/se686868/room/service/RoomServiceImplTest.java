package fu.se686868.room.service;
import fu.se686868.room.dto.RoomDTO;
import fu.se686868.room.entity.*;
import fu.se686868.room.repository.RoomRepository;
import fu.se686868.room.service.impl.RoomServiceImpl;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.springframework.web.server.ResponseStatusException;
class RoomServiceImplTest {
 @Test void createDefaultsToAvailableAndStoresRoom() {
  RoomRepository repo=mock(RoomRepository.class);
  when(repo.saveAndFlush(any(Room.class))).thenAnswer(inv->{Room r=inv.getArgument(0);r.roomId=1L;return r;});
  RoomDTO created=new RoomServiceImpl(repo).create(new RoomDTO(null,"R-101",RoomType.DOUBLE,new BigDecimal("800000"),2,1,RoomStatus.MAINTENANCE));
  assertEquals(RoomStatus.AVAILABLE,created.status()); // BR: client không được quyết định default status.
  verify(repo).saveAndFlush(any(Room.class));
 }
}