-- SQL SERVER 2016+. Chạy 1 lần trên database MSS301_2026_PE.
-- Script người dùng cung cấp bị đứt ở cuối FK; bản này đã sửa và đặt rooms trước reservations.
IF DB_ID(N'MSS301_2026_PE') IS NULL CREATE DATABASE MSS301_2026_PE;
GO
USE MSS301_2026_PE;
GO
IF OBJECT_ID(N'dbo.rooms',N'U') IS NULL
CREATE TABLE dbo.rooms (
 room_id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Rooms PRIMARY KEY,
 room_number nvarchar(20) NOT NULL CONSTRAINT UQ_Rooms_Number UNIQUE,
 room_type nvarchar(10) NOT NULL CONSTRAINT CK_Rooms_Type CHECK(room_type IN ('SINGLE','DOUBLE','SUITE','DELUXE')),
 price_per_night decimal(18,2) NOT NULL CONSTRAINT CK_Rooms_Price CHECK(price_per_night>0),
 capacity int NOT NULL CONSTRAINT CK_Rooms_Capacity CHECK(capacity BETWEEN 1 AND 10),
 floor int NOT NULL CONSTRAINT CK_Rooms_Floor CHECK(floor>=1),
 status nvarchar(15) NOT NULL CONSTRAINT CK_Rooms_Status CHECK(status IN ('AVAILABLE','OCCUPIED','MAINTENANCE'))
);
GO
IF OBJECT_ID(N'dbo.reservations',N'U') IS NULL
CREATE TABLE dbo.reservations (
 reservation_id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Reservations PRIMARY KEY,
 guest_name nvarchar(100) NOT NULL,
 guest_email nvarchar(100) NOT NULL,
 guest_phone nvarchar(20) NOT NULL,
 check_in_date date NOT NULL,
 check_out_date date NOT NULL,
 number_of_guests int NOT NULL,
 total_amount decimal(18,2) NOT NULL,
 status nvarchar(15) NOT NULL,
 room_id int NOT NULL,
 CONSTRAINT CK_Reservations_Dates CHECK(check_out_date>check_in_date),
 CONSTRAINT CK_Reservations_Guests CHECK(number_of_guests>=1),
 CONSTRAINT CK_Reservations_Amount CHECK(total_amount>=0),
 CONSTRAINT CK_Reservations_Status CHECK(status IN ('CONFIRMED','CHECKED_IN','CHECKED_OUT','CANCELLED')),
 CONSTRAINT FK_Reservations_Room FOREIGN KEY(room_id) REFERENCES dbo.rooms(room_id)
);
GO
