USE MSS301_2026_PE;
GO
-- Seed thủ công, chỉ dùng trên DB mới: 4 loại phòng, room_id phát sinh tự động.
INSERT INTO dbo.rooms(room_number,room_type,price_per_night,capacity,floor,status) VALUES
(N'A-101','SINGLE',400000,1,1,'AVAILABLE'),
(N'A-102','DOUBLE',850000,2,1,'AVAILABLE'),
(N'B-201','SUITE',1500000,4,2,'AVAILABLE'),
(N'C-301','DELUXE',2200000,6,3,'AVAILABLE');
GO
