package fu.se686868.reservation.service;
import fu.se686868.reservation.dto.*;
import fu.se686868.reservation.entity.*;
import fu.se686868.reservation.repository.ReservationRepository;
import fu.se686868.reservation.config.RoomClient;
import fu.se686868.reservation.service.impl.ReservationServiceImpl;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import java.util.Date;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
class ReservationServiceImplTest {
 private Date date(String s) throws Exception {SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy");f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));return f.parse(s);}
 @Test void serverCalculatesThreeNightsAndSetsConfirmed() throws Exception {
  ReservationRepository repo=mock(ReservationRepository.class);
  RoomClient rooms=mock(RoomClient.class);
  when(rooms.findRoom(1L)).thenReturn(ApiResponseDTO.ok(new RoomDTO(1L,"A-101","DOUBLE",new BigDecimal("850000"),2,1,"AVAILABLE")));
  when(repo.saveAndFlush(any(Reservation.class))).thenAnswer(inv->{Reservation r=inv.getArgument(0);r.reservationId=7L;return r;});
  ReservationDTO in=new ReservationDTO(null,"Guest","guest@example.com","0123456789",date("15/12/2026"),date("18/12/2026"),2,BigDecimal.ONE,ReservationStatus.CANCELLED,1L);
  ReservationDTO output=new ReservationServiceImpl(repo,rooms).create(in);
  assertEquals(new BigDecimal("2550000.00"),output.totalAmount()); // BR: bỏ qua totalAmount client gửi.
  assertEquals(ReservationStatus.CONFIRMED,output.status());
 }
}