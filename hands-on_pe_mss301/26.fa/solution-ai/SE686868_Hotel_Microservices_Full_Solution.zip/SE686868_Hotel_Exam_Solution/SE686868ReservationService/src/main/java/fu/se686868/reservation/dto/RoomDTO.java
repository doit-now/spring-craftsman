package fu.se686868.reservation.dto;

import java.math.BigDecimal;
/** DTO của ROOM SERVICE dùng cho Feign. Không import Entity hoặc Repository xuyên service. */
public record RoomDTO(Long roomId,String roomNumber,String roomType,BigDecimal pricePerNight,Integer capacity,Integer floor,String status) {}