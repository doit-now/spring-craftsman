package fu.se686868.reservation.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import fu.se686868.reservation.entity.ReservationStatus;
import jakarta.validation.constraints.*;
import java.util.*;
import java.math.BigDecimal;
/** java.util.Date và định dạng dd/MM/yyyy ĐÚNG đề. Date-only, không phải timestamp ISO-8601. */
public record ReservationDTO(Long reservationId,
 @Size(max=100) String guestName,
 @Email @Size(max=100) String guestEmail,
 @Size(max=20) String guestPhone,
 @JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd/MM/yyyy",timezone="UTC") Date checkInDate,
 @JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd/MM/yyyy",timezone="UTC") Date checkOutDate,
 @Min(1) @Max(10) Integer numberOfGuests,
 BigDecimal totalAmount,
 ReservationStatus status,
 Long roomId) { }