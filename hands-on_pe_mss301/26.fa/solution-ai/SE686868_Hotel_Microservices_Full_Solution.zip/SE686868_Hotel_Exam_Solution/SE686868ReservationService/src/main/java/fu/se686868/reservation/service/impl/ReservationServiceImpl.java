package fu.se686868.reservation.service.impl;

import fu.se686868.reservation.common.BusinessException;
import fu.se686868.reservation.config.RoomClient;
import fu.se686868.reservation.dto.*;
import fu.se686868.reservation.entity.*;
import fu.se686868.reservation.repository.ReservationRepository;
import fu.se686868.reservation.service.ReservationService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.http.HttpStatus;
import org.springframework.data.domain.*;
import feign.FeignException;
import java.util.*;
import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;
import java.time.*;
/** NƠI CÀI BUSINESS RULE:
 * 1. Room tồn tại và AVAILABLE; 2. guests <= capacity; 3. checkOut > checkIn;
 * 4. tổng tiền do SERVER tính (không tin totalAmount client); 5. chặn trùng lịch đặt.
 * CẢNH BÁO: kiểm tra trùng lịch bằng SELECT chưa chống race condition đa instance.
 */
@Service @Transactional
public class ReservationServiceImpl implements ReservationService {
 private final ReservationRepository repo;private final RoomClient rooms;
 public ReservationServiceImpl(ReservationRepository repo,RoomClient rooms){this.repo=repo;this.rooms=rooms;}
 private Reservation find(long id){return repo.findById(id).orElseThrow(()->new BusinessException(HttpStatus.NOT_FOUND,4,"Reservation not found"));}
 private RoomDTO room(Long id){
  if(id==null||id<1)throw new BusinessException(HttpStatus.NOT_ACCEPTABLE,2,"roomId is required");
  try {
   ApiResponseDTO<RoomDTO> response=rooms.findRoom(id);
   if(response==null||response.data()==null)throw new BusinessException(HttpStatus.NOT_FOUND,4,"Room not found");
   return response.data();
  }catch(FeignException.NotFound e){throw new BusinessException(HttpStatus.NOT_FOUND,4,"Room not found");}
   catch(FeignException e){throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR,0,"Room service unavailable: "+e.status());}
 }
 private ReservationDTO dto(Reservation r){return new ReservationDTO(r.reservationId,r.guestName,r.guestEmail,r.guestPhone,r.checkInDate,r.checkOutDate,r.numberOfGuests,r.totalAmount,r.status,r.roomId);}
 private ReservationDetailDTO detail(Reservation r){return new ReservationDetailDTO(r.reservationId,r.guestName,r.guestEmail,r.guestPhone,r.checkInDate,r.checkOutDate,r.numberOfGuests,r.totalAmount,r.status,room(r.roomId));}
 private void assign(Reservation r,ReservationDTO d){
  if(d.guestName()!=null)r.guestName=d.guestName();if(d.guestEmail()!=null)r.guestEmail=d.guestEmail();
  if(d.guestPhone()!=null)r.guestPhone=d.guestPhone();if(d.checkInDate()!=null)r.checkInDate=d.checkInDate();
  if(d.checkOutDate()!=null)r.checkOutDate=d.checkOutDate();if(d.numberOfGuests()!=null)r.numberOfGuests=d.numberOfGuests();
  if(d.roomId()!=null)r.roomId=d.roomId();if(d.status()!=null)r.status=d.status();
  // BR: BỎ QUA d.totalAmount(); giá do máy chủ tính theo room.pricePerNight.
 }
 private void validateAndPrice(Reservation r,Long self){
  if(r.guestName==null||r.guestName.isBlank()||r.guestName.length()>100||r.guestEmail==null||(!r.guestEmail.contains("@")||!r.guestEmail.substring(r.guestEmail.indexOf('@')+1).contains("."))||r.guestEmail.length()>100||r.guestPhone==null||r.guestPhone.isBlank()||r.guestPhone.length()>20||r.checkInDate==null||r.checkOutDate==null||r.numberOfGuests==null||r.numberOfGuests<1||r.numberOfGuests>10)
   throw new BusinessException(HttpStatus.NOT_ACCEPTABLE,2,"Invalid guest/dates/guest count");
  LocalDate in=Instant.ofEpochMilli(r.checkInDate.getTime()).atZone(ZoneOffset.UTC).toLocalDate();
  LocalDate out=Instant.ofEpochMilli(r.checkOutDate.getTime()).atZone(ZoneOffset.UTC).toLocalDate();
  long nights=ChronoUnit.DAYS.between(in,out);
  if(nights<=0)throw new BusinessException(HttpStatus.NOT_ACCEPTABLE,2,"checkOutDate must be after checkInDate");
  RoomDTO rm=room(r.roomId);
  if(!"AVAILABLE".equals(rm.status()))throw new BusinessException(HttpStatus.BAD_REQUEST,5,"Room is not AVAILABLE");
  if(r.numberOfGuests>rm.capacity())throw new BusinessException(HttpStatus.NOT_ACCEPTABLE,2,"Guests exceed room capacity");
  if(rm.pricePerNight()==null||rm.pricePerNight().signum()<=0)throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR,0,"Invalid room price");
  // BR mở rộng: bỏ các đặt phòng CANCELLED/CHECKED_OUT khi kiểm tra trùng lịch.
  if(repo.overlaps(r.roomId,List.of(ReservationStatus.CONFIRMED,ReservationStatus.CHECKED_IN),r.checkInDate,r.checkOutDate,self)>0)
   throw new BusinessException(HttpStatus.BAD_REQUEST,5,"Room already reserved for these dates");
  r.totalAmount=rm.pricePerNight().multiply(BigDecimal.valueOf(nights)).setScale(2);
 }
 @Override public ReservationDTO create(ReservationDTO d){
  Reservation r=new Reservation();assign(r,d);r.status=ReservationStatus.CONFIRMED; // BR: trạng thái mặc định.
  validateAndPrice(r,null);return dto(repo.saveAndFlush(r));
 }
 @Override public ReservationDTO update(long id,ReservationDTO d){
  Reservation r=find(id);
  // BR đề xuất: CANCELLED và CHECKED_OUT là trạng thái kết thúc, không sửa nữa.
  if(r.status==ReservationStatus.CANCELLED||r.status==ReservationStatus.CHECKED_OUT)
   throw new BusinessException(HttpStatus.BAD_REQUEST,5,"Finalized reservation cannot be modified");
  assign(r,d);
  if(r.status==ReservationStatus.CONFIRMED||r.status==ReservationStatus.CHECKED_IN)validateAndPrice(r,id);
  return dto(repo.saveAndFlush(r));
 }
 @Override @Transactional(readOnly=true) public ReservationDetailDTO get(long id){return detail(find(id));}
 @Override public void cancel(long id){
  Reservation r=find(id);r.status=ReservationStatus.CANCELLED; // BR: DELETE mềm, không xóa DB.
  repo.save(r);
 }
 @Override @Transactional(readOnly=true) public PageDTO<ReservationDetailDTO> list(int page,int size,String name,ReservationStatus status){
  if(page<0||size<1||size>100)throw new BusinessException(HttpStatus.NOT_ACCEPTABLE,2,"page>=0, size=1..100");
  return PageDTO.from(repo.search(name==null||name.isBlank()?null:name,status,PageRequest.of(page,size)).map(this::detail));
 }
}