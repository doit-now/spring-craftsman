package fu.se686868.reservation.controller;

import fu.se686868.reservation.dto.*;
import fu.se686868.reservation.entity.ReservationStatus;
import fu.se686868.reservation.service.ReservationService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
/** REST API đúng 5 endpoints đề thi; DELETE = CANCELLED, KHÔNG delete SQL. */
@RestController @RequestMapping("/api/reservations")
public class ReservationController {
 private final ReservationService service;
 public ReservationController(ReservationService service){this.service=service;}
 @PostMapping public ResponseEntity<?> create(@Valid @RequestBody ReservationDTO d){return ResponseEntity.status(201).body(ApiResponseDTO.ok(service.create(d)));}
 @PutMapping("/{reservationId}") public ApiResponseDTO<?> update(@PathVariable long reservationId,@Valid @RequestBody ReservationDTO d){return ApiResponseDTO.ok(service.update(reservationId,d));}
 @GetMapping("/{reservationId}") public ApiResponseDTO<?> get(@PathVariable long reservationId){return ApiResponseDTO.ok(service.get(reservationId));}
 @DeleteMapping("/{reservationId}") public ApiResponseDTO<?> cancel(@PathVariable long reservationId){service.cancel(reservationId);return ApiResponseDTO.ok(null);}
 @GetMapping public ApiResponseDTO<?> list(@RequestParam(defaultValue="0") int page,@RequestParam(defaultValue="10") int size,@RequestParam(required=false) String guestName,@RequestParam(required=false) ReservationStatus status){return ApiResponseDTO.ok(service.list(page,size,guestName,status));}
}