package fu.se686868.reservation.config;

import org.springframework.context.annotation.*;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
@Configuration
public class OpenApiConfig {
 @Bean OpenAPI openApi() {return new OpenAPI().info(new Info().title("SE686868 Reservation Service API").version("1.0"));}
}