package fu.se686868.reservation.repository;

import fu.se686868.reservation.entity.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.data.domain.*;
import java.util.Date;
public interface ReservationRepository extends JpaRepository<Reservation,Long> {
 // BR: hai khoảng [in,out) giao nhau khi existing.in < new.out AND existing.out > new.in.
 @Query("select count(r) from Reservation r where r.roomId=:roomId and r.status in :statuses and r.checkInDate < :checkOut and r.checkOutDate > :checkIn and (:exclude is null or r.reservationId <> :exclude)")
 long overlaps(@Param("roomId") Long roomId,@Param("statuses") java.util.Collection<ReservationStatus> statuses,@Param("checkIn") Date in,@Param("checkOut") Date out,@Param("exclude") Long exclude);
 @Query("select r from Reservation r where (:name is null or lower(r.guestName) like lower(concat('%',:name,'%'))) and (:status is null or r.status=:status)")
 Page<Reservation> search(@Param("name") String name,@Param("status") ReservationStatus status,Pageable pageable);
}