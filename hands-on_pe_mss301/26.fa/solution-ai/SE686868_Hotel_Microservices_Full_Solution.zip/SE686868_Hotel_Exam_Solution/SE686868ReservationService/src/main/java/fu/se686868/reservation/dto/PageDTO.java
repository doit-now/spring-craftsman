package fu.se686868.reservation.dto;

import java.util.List;
/** R03: page đánh số từ 0. content chứa DTO, không trả trực tiếp Entity JPA. */
public record PageDTO<T>(int size, int page, int totalPages, long totalElements, boolean first, boolean last, List<T> content) {
 public static <T> PageDTO<T> from(org.springframework.data.domain.Page<T> page) {
  return new PageDTO<>(page.getSize(),page.getNumber(),page.getTotalPages(),page.getTotalElements(),page.isFirst(),page.isLast(),page.getContent());
 }
}