package fu.se686868.reservation.dto;

import java.util.Date;
import java.math.BigDecimal;
import com.fasterxml.jackson.annotation.JsonFormat;
import fu.se686868.reservation.entity.ReservationStatus;
/** GET detail và GET list trả room:RoomDTO (khác với create/update chỉ dùng roomId). */
public record ReservationDetailDTO(Long reservationId,String guestName,String guestEmail,String guestPhone,
 @JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd/MM/yyyy",timezone="UTC") Date checkInDate,
 @JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd/MM/yyyy",timezone="UTC") Date checkOutDate,
 Integer numberOfGuests,BigDecimal totalAmount,ReservationStatus status,RoomDTO room) {}