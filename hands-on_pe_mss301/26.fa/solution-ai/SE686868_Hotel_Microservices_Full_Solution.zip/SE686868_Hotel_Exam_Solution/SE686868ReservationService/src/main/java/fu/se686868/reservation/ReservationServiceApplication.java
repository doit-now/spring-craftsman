package fu.se686868.reservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
/** ĐIỂM KHỞI ĐỘNG: chạy độc lập từng service, JDK 25. */
@SpringBootApplication
@EnableFeignClients
public class ReservationServiceApplication { public static void main(String[] args) { SpringApplication.run(ReservationServiceApplication.class,args); } }