package fu.se686868.room;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Se686868RoomServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
