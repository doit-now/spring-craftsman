package fu.se686868.room.service.impl;

import fu.se686868.room.common.BusinessException;
import fu.se686868.room.dto.*;
import fu.se686868.room.entity.*;
import fu.se686868.room.repository.RoomRepository;
import fu.se686868.room.service.RoomService;

import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * BUSINESS RULE: số phòng là duy nhất; price > 0; capacity 1..10; floor >= 1; DELETE là SOFT DELETE -> MAINTENANCE, không xóa dòng DB.
 */

@Service
@Transactional
public class RoomServiceImpl implements RoomService {
    private final RoomRepository repo;

    public RoomServiceImpl(RoomRepository repo) {

        this.repo = repo;
    }

    //===============================================================================
    //HÀM CHÍNH - CREATE - API CREATE - BỊ GỌI BỞI CONTROLLER
    //===============================================================================
    //Nhận DTO -> chuyển thành Entity. Tạo mới room mặc định status AVAILABLE - TODO: Enum
    @Override
    public RoomDTO create(RoomDTO dto) {
        Room r = new Room();
        toEntity(r, dto);           //chuyển DTO thành Entity
        checkFieldValidation(r);                    //có thể ném ngoại lệ BusinessException nhà mình
        checkDuplicateRoomNumber(r.getRoomNumber(), null);
        r.setStatus("AVAILABLE"); //business rule theo đề: default AVAILABLE khi tạo
        return toDto(repo.saveAndFlush(r)); //SAVE THÀNH CÔNG THÌ TRẢ LẠI CLIENT 1 DTO ĐƯỢC CONVERT TỪ ENTITY VỪA INSERT
    }

    //===============================================================================
    //HÀM CHÍNH - UPDATE - API UPDATE - BỊ GỌI BỞI CONTROLLER
    //===============================================================================
    //Nhận DTO -> chuyển thành Entity.
    @Override
    public RoomDTO update(int id, RoomDTO dto) {
        Room r = find(id);              //tìm coi có dòng để update hay ko
        toEntity(r, dto);               //NẾU CÓ, THÌ OVER-WRITE, ĐÈ DATA MUỐN UPDATE TỪ DTO VÀO ENTITY
        checkFieldValidation(r);        //FIELD NÀO CỦA DTO BỎ TRỐNG THÌ COI NHƯ GIỮ NGUYÊN KO CẬP NHẬT
        checkDuplicateRoomNumber(r.getRoomNumber(), id);  //coi xem dòng cần update có update
        return toDto(repo.saveAndFlush(r));               //trùng roomNumber, ko tính chính mình
    }

    //===============================================================================
    //HÀM CHÍNH - DELETE ONE - API DELETE ONE - BỊ GỌI BỞI CONTROLLER
    //===============================================================================
    //KO TRẢ VỀ GÌ CẢ, XOÁ LÀ XOÁ THÔI
    //XOÁ LÀ XOÁ MỀM, LÀ CẬP NHẬT STATUS SANG MAINTENANCE
    //- XOÁ MỀM 1 ROOM, phải tìm xem roomId có tồn tại hay không, nếu có lấy ra record/object Room tương ứng để sẵn sàng XOÁ MỀM, TỨC LÀ UPDATE STATUS
    @Override
    public void delete(int id) {

        Room r = find(id);              //tìm dòng nếu thấy thì mới update room-status - xoá mềm
        r.setStatus("MAINTENANCE");
        //BUSINESS RULE THEO ĐỀ: Room ở trạng thái bảo trì KHÔNG nhận đặt booking mới ở bên Reservation service.
        repo.save(r);
    }

    //===============================================================================
    //HÀM CHÍNH - GET ONE - API GET ONE - BỊ GỌI BỞI CONTROLLER
    //===============================================================================
    //Trả về DTO khi thấy dòng/row từ table
    @Override
    @Transactional(readOnly = true)
    public RoomDTO get(int id) {

        return toDto(find(id));   //có thể ko tìm thấy, thì đã ném ngoại lệ hàng độ
    }

    //===============================================================================
    //HÀM CHÍNH - GET ALL - API GET ALL - BỊ GỌI BỞI CONTROLLER
    //===============================================================================
    //Trả về PageDTO khi có nhiều dòng thoả điều kiện filter: roomType, roomStatus
    @Override
    @Transactional(readOnly = true)
    public PageDTO list(int page, int size, String type, String status) {
        // 1. Kiểm tra tham số phân trang
        if (page < 0 || size < 1 || size > 100) {
            throw new BusinessException(
                    HttpStatus.BAD_REQUEST, 2, "page>=0, size=1..100");
        }

        // 2. Chuẩn hóa tham số lọc: null hoặc rỗng thì không lọc
        type = (type == null || type.isBlank()) ? null : type.trim();
        status = (status == null || status.isBlank()) ? null : status.trim();

        // 3. Kiểm tra loại phòng hợp lệ (chỉ kiểm tra khi có filter)
        if (type != null &&
                !List.of("SINGLE", "DOUBLE", "SUITE", "DELUXE").contains(type)) {
            throw new BusinessException(
                    HttpStatus.NOT_ACCEPTABLE, 2, "Invalid room type. It must be: SINGLE, DOUBLE, SUITE, DELUXE");
        }

        // 4. Kiểm tra trạng thái phòng hợp lệ
        if (status != null &&
                !List.of("AVAILABLE", "OCCUPIED", "MAINTENANCE").contains(status)) {
            throw new BusinessException(
                    HttpStatus.NOT_ACCEPTABLE, 2, "Invalid room status. It must be: AVAILABLE, OCCUPIED, MAINTENANCE");
        }

        // 5. Tạo Pageable và truy vấn có phân trang, lọc tùy chọn
        Pageable pageable = PageRequest.of(page, size);
        Page<Room> result = repo.search(type, status, pageable);

        // 6. map() chuyển từng Room thành RoomDTO, giữ nguyên thông tin phân trang
        Page<RoomDTO> dtoPage = result.map(room -> toDto(room));

        // 7. Chuyển Page<RoomDTO> thành PageDTO của ứng dụng
        return PageDTO.toPageDTO(dtoPage);
    }


    //===============================================================================
    //HÀM HELPER - GỌI NỘI BỘ TRONG CLASS NÀY
    //===============================================================================

    //HÀM HELPER, DÙNG CHO 3 TÍNH NĂNG:
    //-> UPDATE: CÓ TỒN TẠI THÌ MỚI UPDATE
    //-> DELETE: CÓ TỒN TẠI THÌ MỚI XOÁ
    //-> GET-ONE: CÓ TỒN TẠI THÌ TRẢ VỀ
    //  Nếu tìm ko thấy ROW ứng với given id, thì ném BussinessException httpCode 404, apiStatus mã 4
    private Room find(int id) {

        return repo.findById(id)
                .orElseThrow(
                        () -> new BusinessException(HttpStatus.NOT_FOUND, 4, "Room not found"));
    }

    //HÀM HELPER, DÙNG CHO TÍNH NĂNG: CREATE, UPDATE
    //CẦN CHECK VALIDATION CỦA ROOM-DTO GỬI LÊN SERVER CÓ ỔN KO
    //    Nếu KO ỔN, thì ném BussinessException httpCode 406, apiStatus mã 2
    private void checkFieldValidation(Room r) {
        if (r.getRoomNumber() == null
                || r.getRoomNumber().isBlank()
                || r.getRoomNumber().length() > 20
                || r.getRoomType() == null
                || r.getPricePerNight() == null
                || r.getPricePerNight().compareTo(BigDecimal.ZERO) <= 0
                || r.getCapacity() == null
                || r.getCapacity() < 1
                || r.getCapacity() > 10
                || r.getFloor() == null
                || r.getFloor() < 1
                || r.getStatus() == null
                || !List.of("SINGLE", "DOUBLE", "SUITE", "DELUXE").contains(r.getRoomType())
                || !List.of("AVAILABLE", "OCCUPIED", "MAINTENANCE").contains(r.getStatus())

        )          //CÓ CẦN CHECK THÊM roomStatus == MAINTENANCE, AVAI...?
                   //CÓ CẦN CHECK THÊM roomType == SINGLE, DELUXE...?

            throw new BusinessException(
                    HttpStatus.NOT_ACCEPTABLE,
                    2,
                    "Invalid room fields: number, type (SINGLE, DOUBLE, SUITE, DELUXE), price, capacity, floor, status (AVAILABLE, OCCUPIED, MAINTENANCE)");
    }

    //HÀM HELPER, DÙNG CHO TÍNH NĂNG:
    //- CHECK TRÙNG ROOMNUMBER KHI TẠO MỚI 1 ROOM
    //- CHECK TRÙNG ROOMNUMBER KHI CHỈNH SỬA 1 ROOM, KO TÍNH TRÙNG CHÍNH ROOM ĐANG SỬA
    //HOẠT ĐỘNG:
    //- CHECK LOGIC DỮ LIỆU - KIỂM TRA ROOM-NUMBER CỦA ROW HIỆN HÀNH CÓ TRÙNG VỚI CÁC ROOM-NUMBER KHÁC HAY KO
    //- Nếu TRÙNG, thì ném BussinessException 226, apiStatus mã 3
    private void checkDuplicateRoomNumber(String number, Integer current) {

        boolean exists;

        if (current == null) //tình huống tạo mới room, quét toàn bộ các room tìm trùng room-number
            exists = repo.existsByRoomNumberIgnoreCase(number);
        else                 //tình huống edit room, quét toàn bộ các room ngoại trừ room đang update
            exists = repo.existsByRoomNumberIgnoreCaseAndIdNot(number, current);

        if (exists)
            throw new BusinessException(
                    HttpStatus.IM_USED,
                    3,
                    "Duplicate room number"); // 226 là HTTP theo đề, không phải REST thông lệ.
    }

    //HÀM HELPER, DÙNG CHO TÍNH NĂNG: CREATE, UPDATE, GET, GET-ALL, ĐỀU PHẢI TRẢ VỀ DTO TỪ ENTITY
    //- Biến đổi 1 Room thành 1 RoomDTO
    private RoomDTO toDto(Room r) {
        return new RoomDTO(
                r.getId(), r.getRoomNumber(), r.getRoomType(), r.getPricePerNight(), r.getCapacity(), r.getFloor(), r.getStatus());
    }

    //HÀM HELPER, DÙNG CHO TÍNH NĂNG: CREATE, UPDATE ĐỀU PHẢI TRẢ RA ENTITY TỪ DTO
    //- Biến đổi 1 RoomDTO thành 1 Room
    private Room toEntity(Room r, RoomDTO d) {
        if (d.getRoomNumber() != null) {
            r.setRoomNumber(d.getRoomNumber());
        }
        if (d.getRoomType() != null) {
            r.setRoomType(d.getRoomType());
        }
        if (d.getPricePerNight() != null) {
            r.setPricePerNight(d.getPricePerNight());
        }
        if (d.getCapacity() != null) {
            r.setCapacity(d.getCapacity());
        }
        if (d.getFloor() != null) {
            r.setFloor(d.getFloor());
        }
        if (d.getStatus() != null) {
            r.setStatus(d.getStatus());
        }
        return r;
    }
}
