package fu.se686868.room.common;

import org.springframework.http.HttpStatus;

/** Tách HTTP code khỏi business status của ApiResponseDTO.
 * Ánh xạ HTTP code sang business status
 * 200 -> 1 : GET                    (return .data = DTO)                  : SUCCESSFULLY
 * 200 -> 1 : GET-ALL                (return .data = phân trang List<DTO>) : SUCCESSFULLY
 * 200 -> 1 : UPDATE                 (return .data = DTO)                  : SUCCESSFULLY
 * 200 -> 1 : DELETE                 (return .data = null~void)          : SUCCESSFULLY
 * 201 -> 1 : CREATE                 (return .data = DTO)                  : SUCCESSFULLY
 * 406 -> 2 : Data validation failed (return .data = null~void)          : EXCEPTION
 * 226 -> 3 : Data duplicated        (return .data = null~void)          : EXCEPTION
 * 404 -> 4 : Data not found         (return .data = null~void)          : EXCEPTION
 * 400 -> 5 : Resource unavailable   (return .data = null~void)          : EXCEPTION, room in MAINTENANCE
 * 500 -> 0 : Internal server error  (return .data = null~void)          : EXCEPTION
 * */

public class BusinessException extends RuntimeException {
    private final HttpStatus httpCode;
    private final int apiStatus;  //status của riêng API, business status

    //Bên Service layer, khi có lỗi logic nghiệp vụ xảy ra, sẽ chủ động ném ra ngoại lệ hàng độ BusinessException này với httpCode chuẩn và apiStatus độ ứng với bảng mã lỗi ở trên, và thêm message lỗi của riêng mình giải thích nguyên do lỗi. Message lỗi này ngay sau đó sẽ gửi cho class Cha Exception giữ giúp
    //(Nhớ rằng, class Cha Exception trong JDK sẽ giữ mọi thông tin về exception 1 khi nó xảy ra: stack trace, string mô tả lỗi...)
    //Bên phía class @RestControllerAdvice GlobalExceptionHandler sẽ lắng nghe mọi Exception xảy ra gồm Exception chuẩn của hệ thống, và lắng nghe cả Exception hàng độ BusinessException;
    //Và nếu có BusinessException này đc ném ra, nó sẽ return trả về cho client 1 ResponseEntity message có httpCode chuẩn, body chứa ApiResponseDto(apiStatus-đc trích ra, data null, timestamp hiện hành, message-lỗi-đc-trích-ra) với chi tiết được trích ra từ BusinessException đc ném ra!!!
    public BusinessException(HttpStatus httpCode, int apiStatus, String message) {
        super(message);
        this.httpCode = httpCode;
        this.apiStatus = apiStatus;
    }

    public HttpStatus getHttpCode() {
        return httpCode;
    }

    public int getApiStatus() {
        return apiStatus;
    }
}
