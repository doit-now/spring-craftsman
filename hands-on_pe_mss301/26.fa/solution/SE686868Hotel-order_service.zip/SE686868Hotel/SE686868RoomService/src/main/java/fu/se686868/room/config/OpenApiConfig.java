package fu.se686868.room.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    //Độ lại port server phục vụ gọi Swagger và API từ cổng chung Gateway 8080
    //Từ đây, có 2 cách vào Swagger và gọi API: dùng port của chính service 8081
    //                                  dùng port của gateway 8080
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .servers(List.of(
                        new Server().url("http://localhost:8080")
                ))
                .info(new Info().title("SE686868 Room Service API"));
    }
}
