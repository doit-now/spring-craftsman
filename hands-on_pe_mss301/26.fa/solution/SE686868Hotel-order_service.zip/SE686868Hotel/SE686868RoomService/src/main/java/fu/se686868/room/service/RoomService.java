package fu.se686868.room.service;

import fu.se686868.room.dto.*;

public interface RoomService {

    RoomDTO create(RoomDTO input);

    RoomDTO update(int id, RoomDTO input);

    RoomDTO get(int id);

    //ỨNG VỚI TÍNH NĂNG XOÁ, XOÁ MỀM, ĐỔI ROOM STATUS = MAINTENANCE; KO CHO BÊN RESERVATION BOOK PHÒNG CÓ STATUS NÀY
    void delete(int id);

    //TODO: DÙNG ENUM cho RoomType và RoomStatus, nhưng save table vẫn là String
    //PageDTO list(int page, int size, RoomType type, RoomStatus status);

    //LƯU Ý bên trong PageDTO, các field theo đề có thứ tự bị đảo vị trí, từ size -> page, ngược với Page chuẩn của Spring Data
    PageDTO list(int page, int size, String type, String status);
}
