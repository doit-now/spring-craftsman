package fu.se686868.room.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

/** Tách HTTP code khỏi business status của ApiResponseDTO.
 * Ánh xạ HTTP code sang business status
 * 200 -> 1 : GET                    (return .data = DTO)                  : SUCCESSFULLY
 * 200 -> 1 : GET-ALL                (return .data = phân trang List<DTO>) : SUCCESSFULLY
 * 200 -> 1 : UPDATE                 (return .data = DTO)                  : SUCCESSFULLY
 * 200 -> 1 : DELETE                 (return .data = null~void)          : SUCCESSFULLY
 * 201 -> 1 : CREATE                 (return .data = DTO)                  : SUCCESSFULLY
 * 406 -> 2 : Data validation failed (return .data = null~void)          : EXCEPTION
 * 226 -> 3 : Data duplicated        (return .data = null~void)          : EXCEPTION
 * 404 -> 4 : Data not found         (return .data = null~void)          : EXCEPTION
 * 400 -> 5 : Resource unavailable   (return .data = null~void)          : EXCEPTION, room in MAINTENANCE
 * 500 -> 0 : Internal server error  (return .data = null~void)          : EXCEPTION
 * */

/** Các API trả về HttpResponse message (dù thành công hay thất bại-exception)
 *  THÌ TRONG BODY TRẢ VỀ ĐỀU CHỨA 1 JSON ApiResponseDTO CÓ CHUNG ĐỊNH DẠNG:
 * ApiResponseDTO {}
 *  .status (mã nghiệp vụ)
 *         0 (server error), 1 (ok), 2 (validation), 3 (duplicated), 4 (not found), 5 (not available)
 *  .data (có thể null nếu là API xoá)
 *  .timestamp ISO-8601
 *  .message: chứa thông báo API bị lỗi, hoặc thông báo API thành công
 * }
 * */
@JsonPropertyOrder({
        "status",
        "data",
        "timestamp",
        "message"
})
//Khai báo field CHÍNH XÁC theo đề!!!!!! VÀ TRẢ VỀ JSON THEO ĐÚNG THỨ TỰ FIELD TRONG ĐỀ
public class ApiResponseDTO {
    private int status;
    private Object data;
    private String timestamp;  //LƯU giờ hệ thống tại thời điểm object này đc tạo!!!
    private String message;

    public ApiResponseDTO() {}

    public ApiResponseDTO(int status, Object data, String message) {
        this.status = status;
        this.data = data;
        //TỰ GÁN giờ hệ thống nếu ko đc đưa vào từ constructor
        this.timestamp = Instant.now().truncatedTo(ChronoUnit.SECONDS).toString();
        this.message = message;
    }

    public ApiResponseDTO(int status, Object data, String timestamp, String message) {
        this.status = status;
        this.data = data;
        //LƯU giờ hệ thống đc đưa vào từ constructor
        this.timestamp = timestamp;
        this.message = message;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    //HÀM TIỆN ÍCH STATIC TẠO NHANH, NEW NHANH DTO NÀY KHI API THÀNH CÔNG
    //Có data trả về thì chắc chắn là API thành công, và khi đó
    //.apiStatus sẽ phải = 1 (ứng với http 200, 201), .message mặc định sẽ phải là Successful
    //.data là DTO dữ liệu, DTO Page cần response cho client
    public static ApiResponseDTO ok(Object data) {
        return new ApiResponseDTO(
                1,
                data,
                Instant.now().truncatedTo(ChronoUnit.SECONDS).toString(),
                "Successful");
    }

    //HÀM TIỆN ÍCH STATIC TẠO NHANH, NEW NHANH DTO NÀY KHI API THẤT BẠI, EXCEPTION
    //Exception xảy ra, thì chắc chắn apiStatus phải ăn theo loại lỗi ánh xạ từ HttpStatus chuẩn (xem bảng ánh xạ), và khi đó
    //.apiStatus sẽ phải = lỗi business logic, .message mặc định sẽ phải là message lỗi lưu trong Exception, và .data thì chắc chắn phải là null
    //Hàm này sẽ chơi với BusinessException và GlobalExceptionHandler
    public static ApiResponseDTO error(int status, String message) {
        return new ApiResponseDTO(
                status, null, Instant.now().truncatedTo(ChronoUnit.SECONDS).toString(), message);
    }
}
//Lấy đến mili giây, nano giây, dùng lệnh: DateTimeFormatter.ISO_INSTANT.format(Instant.now())
//Lấy đến giây, dùng lệnh: Instant.now().truncatedTo(ChronoUnit.SECONDS).toString()