package fu.se686868.room.dto;

import org.springframework.data.domain.Page;

/** Các API trả về HttpResponse message (dù thành công hay thất bại-exception)
 *  THÌ TRONG BODY TRẢ VỀ ĐỀU CHỨA 1 JSON ApiResponseDTO CÓ CHUNG ĐỊNH DẠNG:
 * ApiResponseDTO {}
 *  .status (mã nghiệp vụ)
 *         0 (server error), 1 (ok), 2 (validation), 3 (duplicated), 4 (not found), 5 (not available)
 *
 *  .data: CÓ THỂ LÀ null nếu là API xoá
 *         HOẶC CÓ THỂ LÀ RoomDTO,
 *         HOẶC CÓ THỂ LÀ PageDTO mà sâu trong PageDTO có .content lại chứa List<RoomDTO>
 *
 *  .timestamp ISO-8601
 *  .message: chứa thông báo API bị lỗi, hoặc thông báo API thành công
 * }
 * */

//CLASS NÀY DÀNH CHO API SEARCH/FILTER - GET-ALL trả về List<RoomDTO>
//còn GET-ONE THÌ TRẢ 1 OBJECT RoomDTO

//Khai báo field CHÍNH XÁC theo đề!!!!!!
public class PageDTO {
    private int size;
    private int page;
    private int totalPages;
    private long totalElements;
    private boolean first;
    private boolean last;
    private Object content;  //dành cho phân trang, API GET-ALL, lọc/search room theo roomType và roomStatus. Nó thực sự chứa List<RoomDTO>

    public PageDTO() {}

    public PageDTO(
            int size,
            int page,
            int totalPages,
            long totalElements,
            boolean first,
            boolean last,
            Object content) {
        this.size = size;
        this.page = page;
        this.totalPages = totalPages;
        this.totalElements = totalElements;
        this.first = first;
        this.last = last;
        this.content = content;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public long getTotalElements() {
        return totalElements;
    }

    public void setTotalElements(long totalElements) {
        this.totalElements = totalElements;
    }

    public boolean getFirst() {
        return first;
    }

    public void setFirst(boolean first) {
        this.first = first;
    }

    public boolean getLast() {
        return last;
    }

    public void setLast(boolean last) {
        this.last = last;
    }

    public Object getContent() {
        return content;
    }

    public void setContent(Object content) {
        this.content = content;
    }

    //HÀM TIỆN ÍCH static dùng để convert nhanh 1 đối tượng Page chuẩn của Spring Data thành PageDTO hàng độ nhà mình; ĐC GỌI BÊN Service-layer cho gọn code!!!, thay vì phải new bên Service-layer thì chuyển sang new bên static bên này!!!

    //Page hàng chuẩn          so sánh với               PageDTO nhà mình
    //-------------------------------------------------------------------
    //-> CÙNG CHỨA List<RoomDTO> và các thông số phân trang: list RoomDTO này thuộc trang mấy (page), mỗi trang có bao nhiêu dòng (size), tổng số trang, tổng số dòng toàn table, trang đầu?, trang cuối?...
    //-> KHÁC NHAU tên gọi các field, và thứ tự field, tên hàm get/set
    //   hàng chuẩn thì .page -> .size;                  hàng độ nhà mình thì .size -> .page
    //   hàng chuẩn thì .getNumber()                      hàng độ nhà mình thì .getPage()
    //   ...

    public static PageDTO toPageDTO(Page<?> page) {
        return new PageDTO(
                page.getSize(),
                page.getNumber(),
                page.getTotalPages(),
                page.getTotalElements(),
                page.isFirst(),
                page.isLast(),
                page.getContent());
    }
}
