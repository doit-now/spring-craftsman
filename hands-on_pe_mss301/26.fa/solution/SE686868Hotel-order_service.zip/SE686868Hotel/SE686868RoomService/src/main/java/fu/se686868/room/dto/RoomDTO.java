package fu.se686868.room.dto;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;

/** Các API trả về HttpResponse message (dù thành công hay thất bại-exception)
 *  THÌ TRONG BODY TRẢ VỀ ĐỀU CHỨA 1 JSON ApiResponseDTO CÓ CHUNG ĐỊNH DẠNG:
 * ApiResponseDTO {}
 *  .status (mã nghiệp vụ)
 *         0 (server error), 1 (ok), 2 (validation), 3 (duplicated), 4 (not found), 5 (not available)
 *
 *  .data: CÓ THỂ LÀ null nếu là API xoá
 *         HOẶC CÓ THỂ LÀ RoomDTO,
 *         HOẶC CÓ THỂ LÀ PageDTO mà sâu trong PageDTO có .content lại chứa List<RoomDTO>
 *
 *  .timestamp ISO-8601
 *  .message: chứa thông báo API bị lỗi, hoặc thông báo API thành công
 * }
 * */

/**
 * Các API CREATE, UPDATE CẦN NHẬN RoomDTO JSON để CREATE, UPDATE (partial)
 * Create: các field phải khác null, để tạo mới 1 Room có full info - THEO ĐỀ
 * Update: cho phép field null để ám chỉ field này giữ nguyên giá trị, ko update
 *         field nào có giá trị thì sẽ bị update ghi đè
 */

//CLASS NÀY DÙNG CHUNG CHO CẢ: -> CREATE/UPDATE: GỬI JSON TỪ CLIENT LÊN SERVER ĐỂ TẠO MỚI, CHỈNH SỬA
//                             -> CREATE/UPDATE: TRẢ VỀ CHO CLIENT KHI TẠO MỚI, UPDATE THÀNH CÔNG
//                                TỨC LÀ ĐÓNG 2 VAI: REQUEST DTO, RESPONSE DTO
//                             -> GET, GET-ALL: TRẢ VỀ CHO CLIENT 1 RECORD DTO, HOẶC LIST<DTO>
//                                                                              KHI PHÂN TRANG
public class RoomDTO {

    private Integer roomId;   //database khai báo Integer, đề thi là Long, sửa theo database cho an toàn

    @Size(max = 20)
    private String roomNumber;

    private String roomType;  //TODO: thay bằng Enum RoomType

    @DecimalMin("0.01")
    private BigDecimal pricePerNight;

    @Min(1)
    @Max(10)
    private Integer capacity;

    @Min(1)
    private Integer floor;

    private String status;  //TODO: thay bằng Enum RoomStatus

    public RoomDTO() {}

    public RoomDTO(
            Integer roomId,
            String roomNumber,
            String roomType,
            BigDecimal pricePerNight,
            Integer capacity,
            Integer floor,
            String status) {
        this.roomId = roomId;
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.pricePerNight = pricePerNight;
        this.capacity = capacity;
        this.floor = floor;
        this.status = status;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public BigDecimal getPricePerNight() {
        return pricePerNight;
    }

    public void setPricePerNight(BigDecimal pricePerNight) {
        this.pricePerNight = pricePerNight;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public Integer getFloor() {
        return floor;
    }

    public void setFloor(Integer floor) {
        this.floor = floor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
