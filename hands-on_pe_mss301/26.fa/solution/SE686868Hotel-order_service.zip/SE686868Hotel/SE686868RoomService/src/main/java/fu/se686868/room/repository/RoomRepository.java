package fu.se686868.room.repository;

import fu.se686868.room.entity.Room;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RoomRepository extends JpaRepository<Room, Integer> {

    //HÀM TRẢ VỀ Page<Room> phân trang chuẩn của Spring Data
    //TRONG SERVICE-LAYER sẽ phải convert thành PageDTO của nhà mình
    //Dấu """ là raw-string giữ nguyên định dạng chuỗi có xuống hàng, style WYSIWYG cho dễ đọc
    //Câu JPQL nhận tham số, nếu tham số null thì coi như ko có WHERE, khác null thì WHERE
    @Query(
            """
            SELECT r FROM Room r
            WHERE (:type IS NULL OR r.roomType = :type)
              AND (:status IS NULL OR r.status = :status)
            """)
    Page<Room> search(
            @Param("type") String type, @Param("status") String status, Pageable pageable);

    //HÀM DÙNG CHO CREATE, tìm xem JSON RoomDTO TẠO MỚI GỬI LÊN API CREATE có bị trùng RoomNumber với tất cả record đang có hay ko
    boolean existsByRoomNumberIgnoreCase(String roomNumber);

    //HÀM DÙNG CHO UPDATE 1 DÒNG/RECORD CÓ SẴN, tìm xem JSON RoomDTO UPDATE GỬI LÊN API UPDATE có bị trùng RoomNumber với tất cả record đang có hay ko NGOẠI TRỪ CHÍNH DÒNG ĐANG CẦN CẬP NHẬT, KO KIỂM TRA TRÙNG VỚI CHÍNH MÌNH :), XẢY RA TRONG TÌNH HUỐNG UPDATE CÁC FIELD VÀ GIỮ NGUYÊN GIÁ TRỊ FIELD RoomNumber!!!!
    boolean existsByRoomNumberIgnoreCaseAndIdNot(String roomNumber, Integer roomId);
}
