package fu.se686868.room.controller;

import fu.se686868.room.dto.*;
import fu.se686868.room.service.RoomService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

/** Tách HTTP code khỏi business status của ApiResponseDTO.
 * Ánh xạ HTTP code sang business status
 * 200 -> 1 : GET                    (return .data = DTO)                  : SUCCESSFULLY
 * 200 -> 1 : GET-ALL                (return .data = phân trang List<DTO>) : SUCCESSFULLY
 * 200 -> 1 : UPDATE                 (return .data = DTO)                  : SUCCESSFULLY
 * 200 -> 1 : DELETE                 (return .data = null~void)          : SUCCESSFULLY
 * 201 -> 1 : CREATE                 (return .data = DTO)                  : SUCCESSFULLY
 * 406 -> 2 : Data validation failed (return .data = null~void)          : EXCEPTION
 * 226 -> 3 : Data duplicated        (return .data = null~void)          : EXCEPTION
 * 404 -> 4 : Data not found         (return .data = null~void)          : EXCEPTION
 * 400 -> 5 : Resource unavailable   (return .data = null~void)          : EXCEPTION, room in MAINTENANCE
 * 500 -> 0 : Internal server error  (return .data = null~void)          : EXCEPTION
 * */

@RestController
@RequestMapping("/api/rooms")
@CrossOrigin(originPatterns = {"http://localhost:[*]", "http://127.0.0.1:[*]"})
//Cấu hình nhanh CORS. Đúng chuẩn nên tạo bean riêng với nhiều option CORS chi tiết hơn
public class RoomController {

    private final RoomService service;

    public RoomController(RoomService service) {
        this.service = service;
    }

    //CREATE: Nếu binding từ JSON do client gửi lên ổn, và insert xuống DB ổn thì trả về ReponseEntity 201, trong đó body chứa
    //      new ApiResponseDTO(với apiStatus field 1 theo bảng ánh xạ httpCode ở trên,
    //                         và data field chứa entity/row room vừa tạo mới thành công)
    //ta có thể new ApiResponseDTO() dùng hàm ApiResponseDTO.ok() static do mình viết sẵn
    //để rút gọn cú pháp new gốc 4 field new ApiResponseDTO(status, data, timestamp, message)
    //Nếu CREATE ko ổn, thì sẽ văng vào các tình huống BusinessException/GlobalExceptionHandler ở̉ bên xử lý ngoại lệ; và client khi đó nhận về body chứa ApiResponseDTO chứa mã lỗi, message lỗi, data null
    @PostMapping
    public ResponseEntity<?> create(@Valid @RequestBody RoomDTO dto) {
        return ResponseEntity.status(201).body(ApiResponseDTO.ok(service.create(dto)));
    }

    //UPDATE: partial (một phần thông tin) của 1 room, nhận RoomDTO từ client, có thể bị văng lỗi vào bên GlobalExceptionHandler
    //ĐẶC BIỆT có thể bị lỗi trùng room-code/room-number với các room khác
    //Khi check trùng room-code nhớ chỉ check trùng với row/record khác và PHẢI NÉ check ko trùng với chính mình (existsByRoomNumberIgnoreCaseAndIdNot())
    //Nếu thành công, trả về httpCode 200, body là ApiResponseDTO chứa data là RoomDTO vừa đc update, và apiStatus 1
    @PutMapping("/{roomId}")
    public ResponseEntity<?> update(@PathVariable int roomId, @Valid @RequestBody RoomDTO dto) {
        return ResponseEntity.status(200).body(ApiResponseDTO.ok(service.update(roomId, dto)));
    }

    //GET ONE: xem, lấy thông tin chi tiết 1 phòng, trả về httpCode 200, body là ApiResponseDTO chứa data là RoomDTO cần lấy, apiStatus 1 (lấy data thành công)
    @GetMapping("/{roomId}")
    public ResponseEntity<?> get(@PathVariable int roomId) {
        return ResponseEntity.status(200).body(ApiResponseDTO.ok(service.get(roomId)));
    }

    //GET ALL: xem, lọc thông tin CÁC PHÒNG theo roomType, roomStatus
    //trả về httpCode 200, body là ApiResponseDTO chứa data là phân trang<RoomDTO>, apiStatus 1 (lấy list data thành công)
    //localhost:8081/api/rooms/page=0&size=10&roomType=DELUXE&roomStatus=AVAILABLE
    //TODO: nhận vào enum cho roomType và roomStatus
    @GetMapping
    public ResponseEntity<?> list(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size, @RequestParam(required = false) String roomType, @RequestParam(required = false) String status) {

        return ResponseEntity.status(200).body(ApiResponseDTO.ok(service.list(page, size, roomType, status)));
    }

    //DELETE ONE: xoá 1 dòng theo id, trả về httpCode 200, body là ApiResponseDTO chứa apiStatus 1,  data null (xoá thành công)
    @DeleteMapping("/{roomId}")
    public ResponseEntity<?> maintenance(@PathVariable int roomId) {
        service.delete(roomId);
        return ResponseEntity.status(200).body(ApiResponseDTO.ok(null));
    }
}