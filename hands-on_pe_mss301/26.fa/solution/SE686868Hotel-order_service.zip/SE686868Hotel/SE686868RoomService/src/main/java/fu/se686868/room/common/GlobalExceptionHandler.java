package fu.se686868.room.common;

import fu.se686868.room.dto.ApiResponseDTO;

import jakarta.validation.ConstraintViolationException;

import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

/** Tách HTTP code khỏi business status của ApiResponseDTO.
 * Ánh xạ HTTP code sang business status
 * 200 -> 1 : GET                    (return .data = DTO)                  : SUCCESSFULLY
 * 200 -> 1 : GET-ALL                (return .data = phân trang List<DTO>) : SUCCESSFULLY
 * 200 -> 1 : UPDATE                 (return .data = DTO)                  : SUCCESSFULLY
 * 200 -> 1 : DELETE                 (return .data = null~void)          : SUCCESSFULLY
 * 201 -> 1 : CREATE                 (return .data = DTO)                  : SUCCESSFULLY
 * 406 -> 2 : Data validation failed (return .data = null~void)          : EXCEPTION
 * 226 -> 3 : Data duplicated        (return .data = null~void)          : EXCEPTION
 * 404 -> 4 : Data not found         (return .data = null~void)          : EXCEPTION
 * 400 -> 5 : Resource unavailable   (return .data = null~void)          : EXCEPTION, room in MAINTENANCE
 * 500 -> 0 : Internal server error  (return .data = null~void)          : EXCEPTION
 * */

//CLASS NÀY LÀ NHÀ THẦU, LẮNG NGHE TẤT CẢ CÁC EXCEPTION ĐƯỢC NÉM RA, BAO GỒM EXCEPTION CHUẨN VÀ EXCEPTION HÀNG ĐỘ CỦA MÌNH - BusinessException (Exception liên quan logic nghiệp vụ bị vi phạm)
//Exception hàng độ của mình BusinessException có chứa httpCode chuẩn, chứa business status do mình định nghĩa, và message lỗi ứng với logic nghiệp vụ bị vi phạm
//Class này LẮNG NGHE, VÀ XỬ LÝ, CHỦ YẾU LÀ TRẢ VỀ 1 ResponseEntity message cho client ĐỂ DIỄN GIẢI NHỮNG LỖI ĐÃ XẢY RA, GỒM các thông tin được trích xuất từ BusinessException đã đc Service layer ném ra, HOẶC GỒM các thông tin trích xuất từ Exception chuẩn của hệ thống!!!
//ResponseEntity chứa body, trong body chính là ApiResponseDTO với mã lỗi của nghiệp vụ, ngày giờ, message lỗi. Data thì mang giá trị null vì không có dữ liệu đc xử lý và đc trả về!!!!!!
@RestControllerAdvice
public class GlobalExceptionHandler {

    //Service layer ném ra ngoại lệ liên quan xử lý business logic thì data của ApiResponseDTO sẽ null, tức là KO CÓ DATA TRẢ VỀ!!!
    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<?> handleBusinessException(BusinessException e) {
        return ResponseEntity.status(e.getHttpCode())
                .body(new ApiResponseDTO(e.getApiStatus(), null, e.getMessage()));

    //Để tạo body new ApiResponseDTO() có thể dùng hàm tiện ích static do ta code thêm
    //ApiResponseDTO.error(mã lỗi business status, message lỗi, ko cần đưa ngày giờ do bên hàm error sẽ tự lo lấy giờ hệ thống khi new, và data cx sẽ là null)

//Dùng lệnh này cho gọn code mà cùng đạt kết quả tương đương
//        return ResponseEntity.status(e.getHttpCode())
//                .body(ApiResponseDTO.error(e.getApiStatus(), e.getMessage()));
    }

    //Các ngoại lệ chuẩn của JDK/Spring xảy ra liên quan đến tính hợp lệ của dữ liệu đưa lên Controller, có thể xảy ra khi binding
    //HttpCode chuẩn là 406, đổi ngang sang business status là apiStatus = 2
    @ExceptionHandler({
        MethodArgumentNotValidException.class,
        ConstraintViolationException.class,
        MethodArgumentTypeMismatchException.class,
        HttpMessageNotReadableException.class,
        MissingServletRequestParameterException.class,
        IllegalArgumentException.class
    })
    public ResponseEntity<?> handleValidation(Exception e) {
        return ResponseEntity.status(406)  //HttpStatus.NOT_ACCEPTABLE
                .body(ApiResponseDTO.error(2, "Invalid input: " + e.getMessage()));
    }

    //Các ngoại lệ còn lại, liên quan chính nội tại của Server
    //HttpCode chuẩn là 500, đổi ngang sang business status là apiStatus = 0
    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleUnexpected(Exception e) {
        // Không tiết lộ stack trace, SQL, mật khẩu cho client; log ở phía server.
        LoggerFactory.getLogger(getClass()).error("Unexpected error", e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ApiResponseDTO.error(0, "Internal server error"));
    }
}
