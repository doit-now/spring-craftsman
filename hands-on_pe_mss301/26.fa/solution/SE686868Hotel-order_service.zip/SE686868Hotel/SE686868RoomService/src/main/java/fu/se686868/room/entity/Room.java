package fu.se686868.room.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import org.hibernate.annotations.Nationalized;

import java.math.BigDecimal;

@Data
@Entity
@Table(name = "rooms")
//Class được generate ngược từ table qua tool Create Entity Attributes from DB
public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "room_id", nullable = false)
    private Integer id;

    @Size(max = 20)
    @NotNull
    @Nationalized
    @Column(name = "room_number", nullable = false, length = 20)
    private String roomNumber;

    @Size(max = 10)
    @NotNull
    @Nationalized
    @Column(name = "room_type", nullable = false, length = 10)
    private String roomType;
    //TODO: Lưu chuỗi hard-code: SINGLE, DOUBLE, SUITE, DELUXE
    //TODO: hoặc thay bằng RoomType enum

    @NotNull
    @Column(name = "price_per_night", nullable = false, precision = 18, scale = 2)
    private BigDecimal pricePerNight;

    @NotNull
    @Column(name = "capacity", nullable = false)
    private Integer capacity;

    @NotNull
    @Column(name = "floor", nullable = false)
    private Integer floor;

    @Size(max = 15)
    @NotNull
    @Nationalized
    @Column(name = "status", nullable = false, length = 15)
    private String status;
    //TODO: Lưu chuỗi hard-code: AVAILABLE, OCCUPIED, MAINTENANCE
    //TODO: hoặc thay bằng RoomStatus enum
}