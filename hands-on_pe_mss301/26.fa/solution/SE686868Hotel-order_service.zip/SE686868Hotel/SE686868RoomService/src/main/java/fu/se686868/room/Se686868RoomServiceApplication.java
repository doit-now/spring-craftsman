package fu.se686868.room;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Se686868RoomServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(Se686868RoomServiceApplication.class, args);
    }

}
