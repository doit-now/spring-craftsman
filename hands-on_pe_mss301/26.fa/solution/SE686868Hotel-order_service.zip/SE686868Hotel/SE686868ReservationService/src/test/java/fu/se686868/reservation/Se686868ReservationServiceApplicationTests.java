package fu.se686868.reservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Se686868ReservationServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
