package fu.se686868.reservation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Se686868ReservationServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(Se686868ReservationServiceApplication.class, args);
    }

}
