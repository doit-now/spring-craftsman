package fu.se686868.reservation.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/reservations")
@CrossOrigin(originPatterns = {"http://localhost:[*]", "http://127.0.0.1:[*]"})
public class ReservationController {

    @GetMapping("/test") //test 1 api trả về string và nó cần xh trong swagger
    public String test() {
        return "Welcome to Reservation API... Passed PE :)";
    }
}
