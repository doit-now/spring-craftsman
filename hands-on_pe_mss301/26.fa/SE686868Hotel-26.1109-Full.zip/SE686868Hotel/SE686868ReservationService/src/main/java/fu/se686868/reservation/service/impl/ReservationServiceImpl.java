package fu.se686868.reservation.service.impl;

import feign.FeignException;

import fu.se686868.reservation.common.BusinessException;
import fu.se686868.reservation.config.RoomClient;
import fu.se686868.reservation.dto.*;
import fu.se686868.reservation.entity.*;
import fu.se686868.reservation.repository.ReservationRepository;
import fu.se686868.reservation.service.ReservationService;

import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * BUSINESS RULE THEO ĐỀ (không tự mở rộng): BR-RS01: POST phải lấy Room qua OpenFeign, Room tồn tại
 * và AVAILABLE. BR-RS02: số khách >= 1 và <= capacity của Room; ngày checkout > checkin. BR-RS03:
 * totalAmount = room.pricePerNight * số đêm; không sử dụng giá client truyền. BR-RS04: POST mặc
 * định ReservationStatus.CONFIRMED. BR-RS05: DELETE chỉ đổi ReservationStatus.CANCELLED (không đổi
 * Room). LƯU Ý: ĐỀ KHÔNG yêu cầu kiểm tra booking trùng lịch, đổi Room thành OCCUPIED, hay cấm sửa
 * reservation theo trạng thái. Không tự thêm các điều kiện này.
 */
@Service
@Transactional
public class ReservationServiceImpl implements ReservationService {
    private final ReservationRepository repo;
    private final RoomClient rooms;

    public ReservationServiceImpl(ReservationRepository repo, RoomClient rooms) {
        this.repo = repo;
        this.rooms = rooms;
    }

    private Reservation find(long id) {
        return repo.findById(id)
                .orElseThrow(
                        () ->
                                new BusinessException(
                                        HttpStatus.NOT_FOUND, 4, "Reservation not found"));
    }

    private RoomDTO room(Long id) {
        if (id == null || id < 1)
            throw new BusinessException(HttpStatus.NOT_ACCEPTABLE, 2, "roomId is required");
        try {
            ApiResponseDTO response = rooms.findRoom(id);
            if (response == null || response.getData() == null)
                throw new BusinessException(HttpStatus.NOT_FOUND, 4, "Room not found");
            return toDto(response.getData());
        } catch (FeignException.NotFound e) {
            throw new BusinessException(HttpStatus.NOT_FOUND, 4, "Room not found");
        } catch (FeignException e) {
            throw new BusinessException(
                    HttpStatus.INTERNAL_SERVER_ERROR, 0, "Room service unavailable: " + e.status());
        }
    }

    private ReservationDTO toDto(Reservation r) {
        return new ReservationDTO(
                r.reservationId,
                r.guestName,
                r.guestEmail,
                r.guestPhone,
                r.checkInDate,
                r.checkOutDate,
                r.numberOfGuests,
                r.totalAmount,
                r.status,
                r.roomId);
    }

    private ReservationDetailDTO toDetailDto(Reservation r) {
        return new ReservationDetailDTO(
                r.reservationId,
                r.guestName,
                r.guestEmail,
                r.guestPhone,
                r.checkInDate,
                r.checkOutDate,
                r.numberOfGuests,
                r.totalAmount,
                r.status,
                room(r.roomId));
    }

    private Reservation toEntity(Reservation r, ReservationDTO d) {
        if (d.getGuestName() != null) {
            r.guestName = d.getGuestName();
        }
        if (d.getGuestEmail() != null) {
            r.guestEmail = d.getGuestEmail();
        }
        if (d.getGuestPhone() != null) {
            r.guestPhone = d.getGuestPhone();
        }
        if (d.getCheckInDate() != null) {
            r.checkInDate = d.getCheckInDate();
        }
        if (d.getCheckOutDate() != null) {
            r.checkOutDate = d.getCheckOutDate();
        }
        if (d.getNumberOfGuests() != null) {
            r.numberOfGuests = d.getNumberOfGuests();
        }
        if (d.getRoomId() != null) {
            r.roomId = d.getRoomId();
        }
        if (d.getStatus() != null) {
            r.status = d.getStatus();
        }
        // BR: BỎ QUA d.getTotalAmount(); giá do máy chủ tính theo room.pricePerNight.
        return r;
    }

    private void validateAndPrice(Reservation r, boolean requireAvailable) {
        if (r.guestName == null
                || r.guestName.isBlank()
                || r.guestName.length() > 100
                || r.guestEmail == null
                || (!r.guestEmail.contains("@")
                        || !r.guestEmail.substring(r.guestEmail.indexOf('@') + 1).contains("."))
                || r.guestEmail.length() > 100
                || r.guestPhone == null
                || r.guestPhone.isBlank()
                || r.guestPhone.length() > 20
                || r.checkInDate == null
                || r.checkOutDate == null
                || r.numberOfGuests == null
                || r.numberOfGuests < 1
                || r.numberOfGuests > 10)
            throw new BusinessException(
                    HttpStatus.NOT_ACCEPTABLE, 2, "Invalid guest/dates/guest count");
        LocalDate in =
                Instant.ofEpochMilli(r.checkInDate.getTime()).atZone(ZoneOffset.UTC).toLocalDate();
        LocalDate out =
                Instant.ofEpochMilli(r.checkOutDate.getTime()).atZone(ZoneOffset.UTC).toLocalDate();
        long nights = ChronoUnit.DAYS.between(in, out);
        if (nights <= 0)
            throw new BusinessException(
                    HttpStatus.NOT_ACCEPTABLE, 2, "checkOutDate must be after checkInDate");
        RoomDTO rm = room(r.roomId);
        // BR-RS01: kiểm tra AVAILABLE khi tạo mới (POST); đề không áp đặt cho mọi PUT.
        if (requireAvailable && !"AVAILABLE".equals(rm.getStatus()))
            throw new BusinessException(HttpStatus.BAD_REQUEST, 5, "Room is not AVAILABLE");
        if (r.numberOfGuests > rm.getCapacity())
            throw new BusinessException(
                    HttpStatus.NOT_ACCEPTABLE, 2, "Guests exceed room capacity");
        if (rm.getPricePerNight() == null || rm.getPricePerNight().signum() <= 0)
            throw new BusinessException(HttpStatus.INTERNAL_SERVER_ERROR, 0, "Invalid room price");
        // Theo đề KHÔNG kiểm tra ngày trùng với reservation khác.
        // BR-RS03: Server tính tiền; không sử dụng totalAmount do người dùng gửi.
        r.totalAmount = rm.getPricePerNight().multiply(BigDecimal.valueOf(nights)).setScale(2);
    }

    @Override
    public ReservationDTO create(ReservationDTO d) {
        Reservation r = new Reservation();
        toEntity(r, d);
        r.status = ReservationStatus.CONFIRMED; // BR: trạng thái mặc định.
        validateAndPrice(r, true);
        // Theo đề: booking thành công KHÔNG cập nhật Room.status; chỉ INSERT reservations.
        return toDto(repo.saveAndFlush(r));
    }

    @Override
    public ReservationDTO update(long id, ReservationDTO d) {
        Reservation r = find(id);
        // Theo đề: PUT sửa từng trường được truyền; không tự cấm sửa CANCELLED/CHECKED_OUT.
        toEntity(r, d);
        // Kiểm tra tính hợp lệ của dữ liệu sau cập nhật và tính lại tiền; không bắt buộc AVAILABLE
        // trên PUT.
        validateAndPrice(r, false);
        return toDto(repo.saveAndFlush(r));
    }

    @Override
    @Transactional(readOnly = true)
    public ReservationDetailDTO get(long id) {
        return toDetailDto(find(id));
    }

    @Override
    public void cancel(long id) {
        Reservation r = find(id);
        // BR-RS05: chỉ đổi status reservation, KHÔNG gọi RoomClient hoặc đổi Room.status.
        r.status = ReservationStatus.CANCELLED;
        repo.save(r);
    }

    @Override
    @Transactional(readOnly = true)
    public PageDTO list(int page, int size, String name, ReservationStatus status) {
        if (page < 0 || size < 1 || size > 100)
            throw new BusinessException(HttpStatus.NOT_ACCEPTABLE, 2, "page>=0, size=1..100");
        return PageDTO.from(
                repo.search(
                                name == null || name.isBlank() ? null : name,
                                status,
                                PageRequest.of(page, size))
                        .map(reservation -> toDetailDto(reservation)));
    }

    private RoomDTO toDto(Object data) {
        if (data instanceof RoomDTO roomDto) {
            return roomDto;
        }
        if (!(data instanceof Map<?, ?> values)) {
            throw new BusinessException(
                    HttpStatus.INTERNAL_SERVER_ERROR, 0, "Invalid room response");
        }
        RoomDTO roomDto = new RoomDTO();
        roomDto.setRoomId(
                values.get("roomId") == null ? null : ((Number) values.get("roomId")).longValue());
        roomDto.setRoomNumber((String) values.get("roomNumber"));
        roomDto.setRoomType((String) values.get("roomType"));
        roomDto.setPricePerNight(
                values.get("pricePerNight") == null
                        ? null
                        : new BigDecimal(values.get("pricePerNight").toString()));
        roomDto.setCapacity(
                values.get("capacity") == null
                        ? null
                        : ((Number) values.get("capacity")).intValue());
        roomDto.setFloor(
                values.get("floor") == null ? null : ((Number) values.get("floor")).intValue());
        roomDto.setStatus((String) values.get("status"));
        return roomDto;
    }
}
