package fu.se686868.reservation.repository;

import fu.se686868.reservation.entity.*;

import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {
    @Query(
            "select r from Reservation r where (:name is null or lower(r.guestName) like"
                    + " lower(concat('%',:name,'%'))) and (:status is null or r.status=:status)")
    Page<Reservation> search(
            @Param("name") String name,
            @Param("status") ReservationStatus status,
            Pageable pageable);
}
