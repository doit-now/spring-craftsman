package fu.se686868.reservation.dto;

import java.time.Instant;
import java.time.format.DateTimeFormatter;

/** Hợp đồng JSON chung: status (mã nghiệp vụ), data, timestamp ISO-8601, message. */
public class ApiResponseDTO {
    private int status;
    private Object data;
    private String timestamp;
    private String message;

    public ApiResponseDTO() {}

    public ApiResponseDTO(int status, Object data, String timestamp, String message) {
        this.status = status;
        this.data = data;
        this.timestamp = timestamp;
        this.message = message;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static ApiResponseDTO ok(Object data) {
        return new ApiResponseDTO(
                1, data, DateTimeFormatter.ISO_INSTANT.format(Instant.now()), "Successful");
    }

    public static ApiResponseDTO error(int status, String message) {
        return new ApiResponseDTO(
                status, null, DateTimeFormatter.ISO_INSTANT.format(Instant.now()), message);
    }
}
