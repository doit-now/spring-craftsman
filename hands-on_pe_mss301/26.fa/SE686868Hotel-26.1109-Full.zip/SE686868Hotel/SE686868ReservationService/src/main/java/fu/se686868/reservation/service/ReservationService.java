package fu.se686868.reservation.service;

import fu.se686868.reservation.dto.*;
import fu.se686868.reservation.entity.ReservationStatus;

public interface ReservationService {
    ReservationDTO create(ReservationDTO d);

    ReservationDTO update(long id, ReservationDTO d);

    ReservationDetailDTO get(long id);

    void cancel(long id);

    PageDTO list(int page, int size, String guestName, ReservationStatus status);
}
