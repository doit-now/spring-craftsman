package fu.se686868.reservation.config;

import fu.se686868.reservation.dto.*;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

/** Feign synchronous: Reservation -> Room qua HTTP, không gọi thẳng RoomRepository. */
@FeignClient(name = "roomClient", url = "${room.service.url}")
public interface RoomClient {
    @GetMapping("/api/rooms/{id}")
    ApiResponseDTO findRoom(@PathVariable("id") long id);
}
