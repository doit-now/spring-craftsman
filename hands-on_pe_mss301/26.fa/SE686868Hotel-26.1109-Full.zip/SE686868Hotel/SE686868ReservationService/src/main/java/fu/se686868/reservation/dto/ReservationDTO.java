package fu.se686868.reservation.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import fu.se686868.reservation.entity.ReservationStatus;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.util.*;

/** Date và định dạng dd/MM/yyyy ĐÚNG đề. Date-only, không phải timestamp ISO-8601. */
public class ReservationDTO {
    private Long reservationId;

    @Size(max = 100)
    private String guestName;

    @Email
    @Size(max = 100)
    private String guestEmail;

    @Size(max = 20)
    private String guestPhone;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "UTC")
    private Date checkInDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", timezone = "UTC")
    private Date checkOutDate;

    @Min(1)
    @Max(10)
    private Integer numberOfGuests;

    private BigDecimal totalAmount;
    private ReservationStatus status;
    private Long roomId;

    public ReservationDTO() {}

    public ReservationDTO(
            Long reservationId,
            String guestName,
            String guestEmail,
            String guestPhone,
            Date checkInDate,
            Date checkOutDate,
            Integer numberOfGuests,
            BigDecimal totalAmount,
            ReservationStatus status,
            Long roomId) {
        this.reservationId = reservationId;
        this.guestName = guestName;
        this.guestEmail = guestEmail;
        this.guestPhone = guestPhone;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.numberOfGuests = numberOfGuests;
        this.totalAmount = totalAmount;
        this.status = status;
        this.roomId = roomId;
    }

    public Long getReservationId() {
        return reservationId;
    }

    public void setReservationId(Long reservationId) {
        this.reservationId = reservationId;
    }

    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }

    public String getGuestEmail() {
        return guestEmail;
    }

    public void setGuestEmail(String guestEmail) {
        this.guestEmail = guestEmail;
    }

    public String getGuestPhone() {
        return guestPhone;
    }

    public void setGuestPhone(String guestPhone) {
        this.guestPhone = guestPhone;
    }

    public Date getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }

    public Date getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(Date checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public Integer getNumberOfGuests() {
        return numberOfGuests;
    }

    public void setNumberOfGuests(Integer numberOfGuests) {
        this.numberOfGuests = numberOfGuests;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public ReservationStatus getStatus() {
        return status;
    }

    public void setStatus(ReservationStatus status) {
        this.status = status;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }
}
