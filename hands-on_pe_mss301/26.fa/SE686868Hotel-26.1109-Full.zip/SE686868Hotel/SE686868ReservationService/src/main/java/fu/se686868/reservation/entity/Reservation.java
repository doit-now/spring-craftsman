package fu.se686868.reservation.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.Date;

/** Shared DB theo đề: roomId là FK SQL, không khai báo @ManyToOne tới Entity của service khác. */
@Entity
@Table(name = "reservations")
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reservation_id")
    public Long reservationId;

    @Column(name = "guest_name", nullable = false, length = 100)
    public String guestName;

    @Column(name = "guest_email", nullable = false, length = 100)
    public String guestEmail;

    @Column(name = "guest_phone", nullable = false, length = 20)
    public String guestPhone;

    @Temporal(TemporalType.DATE)
    @Column(name = "check_in_date", nullable = false)
    public Date checkInDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "check_out_date", nullable = false)
    public Date checkOutDate;

    @Column(name = "number_of_guests", nullable = false)
    public Integer numberOfGuests;

    @Column(name = "total_amount", precision = 18, scale = 2, nullable = false)
    public BigDecimal totalAmount;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 15, nullable = false)
    public ReservationStatus status;

    @Column(name = "room_id", nullable = false)
    public Long roomId;
}
