package fu.se686868;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Se686868HotelApplicationTests {

    @Test
    void contextLoads() {}
}
