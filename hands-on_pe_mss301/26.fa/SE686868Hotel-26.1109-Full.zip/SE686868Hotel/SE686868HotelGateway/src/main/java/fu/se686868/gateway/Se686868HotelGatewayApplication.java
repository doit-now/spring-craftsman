package fu.se686868.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Se686868HotelGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(Se686868HotelGatewayApplication.class, args);
    }
}
