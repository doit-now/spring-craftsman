package fu.se686868.hotelgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Se686868HotelGatewayApplicationTests {

    @Test
    void contextLoads() {}
}
