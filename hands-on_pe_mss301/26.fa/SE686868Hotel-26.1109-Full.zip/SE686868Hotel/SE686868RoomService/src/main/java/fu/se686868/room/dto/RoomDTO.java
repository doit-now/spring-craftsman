package fu.se686868.room.dto;

import fu.se686868.room.entity.*;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;

/**
 * Create: bắt buộc trường; Update: cho phép null để giữ nguyên dữ liệu (partial update theo đề).
 */
public class RoomDTO {
    private Long roomId;

    @Size(max = 20)
    private String roomNumber;

    private RoomType roomType;

    @DecimalMin("0.01")
    private BigDecimal pricePerNight;

    @Min(1)
    @Max(10)
    private Integer capacity;

    @Min(1)
    private Integer floor;

    private RoomStatus status;

    public RoomDTO() {}

    public RoomDTO(
            Long roomId,
            String roomNumber,
            RoomType roomType,
            BigDecimal pricePerNight,
            Integer capacity,
            Integer floor,
            RoomStatus status) {
        this.roomId = roomId;
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.pricePerNight = pricePerNight;
        this.capacity = capacity;
        this.floor = floor;
        this.status = status;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public RoomType getRoomType() {
        return roomType;
    }

    public void setRoomType(RoomType roomType) {
        this.roomType = roomType;
    }

    public BigDecimal getPricePerNight() {
        return pricePerNight;
    }

    public void setPricePerNight(BigDecimal pricePerNight) {
        this.pricePerNight = pricePerNight;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public Integer getFloor() {
        return floor;
    }

    public void setFloor(Integer floor) {
        this.floor = floor;
    }

    public RoomStatus getStatus() {
        return status;
    }

    public void setStatus(RoomStatus status) {
        this.status = status;
    }
}
