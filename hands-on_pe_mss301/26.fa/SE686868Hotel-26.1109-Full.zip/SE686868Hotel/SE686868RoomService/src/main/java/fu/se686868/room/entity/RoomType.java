package fu.se686868.room.entity;

public enum RoomType {
    SINGLE,
    DOUBLE,
    SUITE,
    DELUXE
}
