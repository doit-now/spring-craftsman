package fu.se686868.room.entity;

public enum RoomStatus {
    AVAILABLE,
    OCCUPIED,
    MAINTENANCE
}
