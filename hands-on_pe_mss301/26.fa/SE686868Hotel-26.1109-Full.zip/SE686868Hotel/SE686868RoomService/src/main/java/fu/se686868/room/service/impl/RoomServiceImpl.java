package fu.se686868.room.service.impl;

import fu.se686868.room.common.BusinessException;
import fu.se686868.room.dto.*;
import fu.se686868.room.entity.*;
import fu.se686868.room.repository.RoomRepository;
import fu.se686868.room.service.RoomService;

import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

/**
 * BUSINESS RULE: số phòng là duy nhất; price > 0; capacity 1..10; floor >=1; DELETE là SOFT DELETE
 * -> MAINTENANCE, không xóa dòng DB.
 */
@Service
@Transactional
public class RoomServiceImpl implements RoomService {
    private final RoomRepository repo;

    public RoomServiceImpl(RoomRepository repo) {
        this.repo = repo;
    }

    private Room find(long id) {
        return repo.findById(id)
                .orElseThrow(
                        () -> new BusinessException(HttpStatus.NOT_FOUND, 4, "Room not found"));
    }

    private RoomDTO toDto(Room r) {
        return new RoomDTO(
                r.roomId, r.roomNumber, r.roomType, r.pricePerNight, r.capacity, r.floor, r.status);
    }

    private void check(Room r) {
        if (r.roomNumber == null
                || r.roomNumber.isBlank()
                || r.roomNumber.length() > 20
                || r.roomType == null
                || r.pricePerNight == null
                || r.pricePerNight.compareTo(BigDecimal.ZERO) <= 0
                || r.capacity == null
                || r.capacity < 1
                || r.capacity > 10
                || r.floor == null
                || r.floor < 1
                || r.status == null)
            throw new BusinessException(
                    HttpStatus.NOT_ACCEPTABLE,
                    2,
                    "Invalid room fields (number, type, price, capacity, floor, status)");
    }

    @Override
    public RoomDTO create(RoomDTO d) {
        Room r = new Room();
        toEntity(r, d);
        r.status = RoomStatus.AVAILABLE; // BR: default khi tạo.
        check(r);
        duplicate(r.roomNumber, null);
        return toDto(repo.saveAndFlush(r));
    }

    @Override
    public RoomDTO update(long id, RoomDTO d) {
        Room r = find(id);
        toEntity(r, d);
        check(r);
        duplicate(r.roomNumber, id);
        return toDto(repo.saveAndFlush(r));
    }

    private Room toEntity(Room r, RoomDTO d) {
        if (d.getRoomNumber() != null) {
            r.roomNumber = d.getRoomNumber();
        }
        if (d.getRoomType() != null) {
            r.roomType = d.getRoomType();
        }
        if (d.getPricePerNight() != null) {
            r.pricePerNight = d.getPricePerNight();
        }
        if (d.getCapacity() != null) {
            r.capacity = d.getCapacity();
        }
        if (d.getFloor() != null) {
            r.floor = d.getFloor();
        }
        if (d.getStatus() != null) {
            r.status = d.getStatus();
        }
        return r;
    }

    private void duplicate(String number, Long current) {
        boolean exists =
                current == null
                        ? repo.existsByRoomNumberIgnoreCase(number)
                        : repo.existsByRoomNumberIgnoreCaseAndRoomIdNot(number, current);
        if (exists)
            throw new BusinessException(
                    HttpStatus.IM_USED,
                    3,
                    "Duplicate room number"); // 226 là HTTP theo đề, không phải REST thông lệ.
    }

    @Override
    @Transactional(readOnly = true)
    public RoomDTO get(long id) {
        return toDto(find(id));
    }

    @Override
    public void maintenance(long id) {
        Room r = find(id);
        r.status = RoomStatus.MAINTENANCE; // BR: phòng bảo trì KHÔNG nhận đặt mới.
        repo.save(r);
    }

    @Override
    @Transactional(readOnly = true)
    public PageDTO list(int page, int size, RoomType type, RoomStatus status) {
        if (page < 0 || size < 1 || size > 100)
            throw new BusinessException(HttpStatus.NOT_ACCEPTABLE, 2, "page>=0, size=1..100");
        Pageable pageable = PageRequest.of(page, size);

        Page<Room> result;

        if (type == null && status == null) {
            result = repo.findAll(pageable);
        } else {
            // Filter tại DB trước khi phân trang.
            result = repo.search(type, status, pageable);
        }

        // Chuyển Entity sang DTO bằng Lambda Expression.
        Page<RoomDTO> dtoPage = result.map(room -> toDto(room));

        return PageDTO.from(dtoPage);
    }
}
