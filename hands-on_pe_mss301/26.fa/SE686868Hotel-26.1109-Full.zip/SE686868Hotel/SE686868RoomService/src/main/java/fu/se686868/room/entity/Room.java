package fu.se686868.room.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;

/** Entity map CHÍNH XÁC tên bảng / cột có sẵn; không dùng ddl-auto=update. */
@Entity
@Table(name = "rooms")
public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "room_id")
    public Long roomId;

    @Column(name = "room_number", nullable = false, length = 20, unique = true)
    public String roomNumber;

    @Enumerated(EnumType.STRING)
    @Column(name = "room_type", nullable = false, length = 10)
    public RoomType roomType;

    @Column(name = "price_per_night", nullable = false, precision = 18, scale = 2)
    public BigDecimal pricePerNight;

    @Column(name = "capacity", nullable = false)
    public Integer capacity;

    @Column(name = "floor", nullable = false)
    public Integer floor;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 15)
    public RoomStatus status;
}
