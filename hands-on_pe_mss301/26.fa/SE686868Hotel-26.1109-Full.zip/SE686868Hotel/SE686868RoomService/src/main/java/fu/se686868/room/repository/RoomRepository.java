package fu.se686868.room.repository;

import fu.se686868.room.entity.Room;
import fu.se686868.room.entity.RoomStatus;
import fu.se686868.room.entity.RoomType;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RoomRepository extends JpaRepository<Room, Long> {

    boolean existsByRoomNumberIgnoreCase(String roomNumber);

    @Query(
            """
            SELECT r FROM Room r
            WHERE (:type IS NULL OR r.roomType = :type)
              AND (:status IS NULL OR r.status = :status)
            """)
    Page<Room> search(
            @Param("type") RoomType type, @Param("status") RoomStatus status, Pageable pageable);

    boolean existsByRoomNumberIgnoreCaseAndRoomIdNot(String roomNumber, Long roomId);
}
