package fu.se668868.department;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Se668868DepartmentServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
