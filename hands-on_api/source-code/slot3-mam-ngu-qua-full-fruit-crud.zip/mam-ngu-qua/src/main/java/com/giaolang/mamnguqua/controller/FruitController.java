package com.giaolang.mamnguqua.controller;

import com.giaolang.mamnguqua.entity.Fruit;
import com.giaolang.mamnguqua.service.FruitService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@RestController
//@CrossOrigin(origins = "http://localhost:3979") //cho phép chỉ FE 3979 ĐC VÀO
@Tag(name = "The API offers fruits resource", description = "All endpoints to mannupulate fruits: CRUD")
@CrossOrigin(origins = "http://localhost:3979") //cho phép mọi FE đều vào đc
@RequestMapping("/api/fruits")  //các endpoint của controller này đều bắt đầu bằng
                                  // /api/fruits
                                  // GET ALL: /api/fruits
                                  // GET ONE: /api/fruits/1
                                  // POST   : /api/fruits    JSON
                                  // UPDATE : /api/fruits/2  JSON
public class FruitController {

    @Autowired
    private FruitService fruitService;

    @GetMapping
    public ResponseEntity<List<Fruit>> getAll() {

        return ResponseEntity.status(HttpStatus.OK).body(fruitService.getAll());
        //return ResponseEntity.ok(fruitService.getAll());
    }

    @GetMapping("/{id}")
    //public ResponseEntity<Fruit> getOne(@PathVariable("id") Long id) {
    public ResponseEntity<Fruit> getOne(@PathVariable Long id) {

        return ResponseEntity.status(HttpStatus.OK).body(fruitService.getOne(id));
        //return ResponseEntity.ok(fruitService.getOne(id));
    }

    @GetMapping("/types") //trả về 3 type lẽ ra là 1 table riêng - Category
                             //để dùng cho dropdown combobox xổ xuống ở FE
    public ResponseEntity<List<String>> getTypes() {

        List<String> types = List.of("Trái cây tươi",
                "Chế biến sẵn",
                "Trái cây sấy/lon");
        return ResponseEntity.status(HttpStatus.OK).body(types);
        //CategoryService có hàm getAll() trả về tất cả cate
    }

    @PostMapping   //chuẩn công nghiệp sẽ nhận vào DTO và gọi hàm map() để biến đổi từ
                     //DTO thành Entity do Service, Repo nó chơi với Entity
    public ResponseEntity<Fruit> save(@RequestBody Fruit f) {

        return ResponseEntity.status(HttpStatus.CREATED).body(fruitService.save(f));
    }

    @PutMapping("/{id}")   //chuẩn công nghiệp sẽ nhận vào DTO và gọi hàm map() để biến đổi từ
    //DTO thành Entity do Service, Repo nó chơi với Entity
    public ResponseEntity<Fruit> updateById(@PathVariable Long id, @RequestBody Fruit f) {

        return ResponseEntity.status(HttpStatus.OK).body(fruitService.updateById(id, f));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable Long id) {
        fruitService.deleteById(id);
        return ResponseEntity.noContent().build();
    }  //trả về hộp rỗng

}
