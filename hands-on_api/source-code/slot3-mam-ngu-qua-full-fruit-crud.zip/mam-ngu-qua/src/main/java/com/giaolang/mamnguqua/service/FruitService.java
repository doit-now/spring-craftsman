package com.giaolang.mamnguqua.service;

import com.giaolang.mamnguqua.entity.Fruit;
import com.giaolang.mamnguqua.repository.FruitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service  //chịu trách nhiệm CRUD table, trả về cho bên Controller
public class FruitService {

    //tiêm FruitRepo vào
    @Autowired
    private FruitRepository fruitRepo;

    public List<Fruit> getAll() {
        return fruitRepo.findAll();
    }

    public Fruit getOne(Long id) {
        return fruitRepo.findById(id).orElseThrow(() -> new RuntimeException("Fruit not found with given id"));
        //  trả ra hộp[Fruit, null]  .orElse để mỏ hộp hoặc lấy đc Fruit
        //                                hoặc lấy đc null, thì ném ngoại lệ Runtime(...)

    }

    public Fruit save(Fruit obj) {
        return fruitRepo.save(obj);
    }

    public void deleteById(Long id) {
        if(!fruitRepo.existsById(id)) {
            throw new RuntimeException("Fruit not found with given id");
        }
        fruitRepo.deleteById(id);
    }

    public Fruit updateById(Long id, Fruit obj) {
        if(!fruitRepo.existsById(id)) {
            throw new RuntimeException("Fruit not found with given id");
        }
        obj.setId(id); //tình huống DTO ko có id
        return fruitRepo.save(obj);
    }

}
