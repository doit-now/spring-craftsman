package com.giaolang.mamnguqua.config;

import com.giaolang.mamnguqua.entity.Fruit;
import com.giaolang.mamnguqua.repository.FruitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component //IoC container - Inversion of Control - SpringBoot giành việc new object
public class DataInitializer implements CommandLineRunner {

    //tiêm thằng FruitRepository (Dependency Injection - có 3 cách tiêm)
    @Autowired
    private FruitRepository fruitRepo;

    @Override
    public void run(String... args) throws Exception {

        //tạo sẵn 1 vài trái cây khi ta run cái app
        //xài Builder của Lombok, hoặc new Fruit(tham số đưa vào kiểu truyền thống)
        Fruit cau = Fruit.builder()
                .name("Mãng cầu")
                .description("Mãng cầu là loại trái cây...")
                .price(30000)
                .type("Trái cây tươi")
                .build();
        Fruit sung = Fruit.builder()
                .name("Sung")
                .description("Sung là loại trái cây...")
                .price(40000)
                .build();
        Fruit dua = Fruit.builder()
                .name("Dừa")
                .description("Dừa là loại trái cây...")
                .price(50000)
                .build();

        fruitRepo.save(cau);
        fruitRepo.save(sung);
        fruitRepo.save(dua);


    }


}
