package com.giaolang.mamnguqua.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginResponse {

    //trả về cho FE
    private String email;
    private String role;
    private String token;      //thẻ bài bảo mật giúp gọi tiếp các API khác
    private int status;        //trạng thái login
    private String message;    //câu thông báo

}
