package com.giaolang.mamnguqua.controller;

import com.giaolang.mamnguqua.dto.request.LoginRequest;
import com.giaolang.mamnguqua.dto.response.LoginResponse;
import com.giaolang.mamnguqua.entity.UserAccount;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Cung cấp các API liên quan đến xác thực API sử dụng JWT
 * <p>
 * <p>
 * Các endpoint - api
 * POST /api/auth/login (gửi lên server email và pass)-> ai cx gọi đc, miễn ko bị CORS
 * và nhận về: UserAccount, hoặc JWT Token
 * <p>
 * @version 2026.0203
 * @author giao.lang
 * @since 2026
 */

@RestController
@RequestMapping("/api/auth")  //base url, các hàm bên trong sẽ nối thêm đuôi /login /logout
@Tag(name = "APIs liên quan authen", description = "Các API dành cho bảo mật và phân quyền dùng JWT")
public class AuthController {

    @PostMapping
    //public UserAccount login()
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest obj ) {

        //xuống db where obj.email và obj.pass, TODO
        //nếu hợp lệ trả về LoginResponse
        //auto mapper, convert từ obj    -> UserAccount -> LoginResponse
        //                        2 field     6 field        5 field khác
        LoginResponse ret = new LoginResponse();
        ret.setEmail(obj.getEmail());
        ret.setRole("ADMIN");  //DB LÊN
        ret.setToken("CHUỖI HASH BĂM DÀI... JWT TOKEN HỌC SAU");
        ret.setStatus(200);
        ret.setMessage("Login thành công");
        return ResponseEntity.ok(ret);
    }
}
