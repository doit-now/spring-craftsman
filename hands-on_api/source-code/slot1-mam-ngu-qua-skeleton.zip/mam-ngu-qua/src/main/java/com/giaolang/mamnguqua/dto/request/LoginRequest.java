package com.giaolang.mamnguqua.dto.request;


import jakarta.persistence.Column;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class này đóng vai JSON object mà FE gửi tên API POST /login
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginRequest {

    //email cấm trùng
    @NotBlank(message = "Email is required! Email không được bỏ trống")
    @Email(message = "Invalid email! Email không hợp lệ")
    private String email;

    @NotBlank(message = "Password is required! Password không được bỏ trống")
    @Size(min = 1, max = 30, message = "Password is 1 to 30 characters length! Tên người từ 5...50 ký tự")  //pass test nhập ngắn
    private String password;  //phải mã hoá, học sau...
}
