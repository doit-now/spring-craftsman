package com.giaolang.mamnguqua.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "UserAccount")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder  //là 1 design pattern, kĩ thuật thiết kế 1 class
          //hỗ trợ việc new object 1 cách linh hoạt
          //bằng cách dùng . . . . . liên tục thay cho gọi từng hàm setter
public class UserAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //key tự tăng
    @Column(name = "Id")  //tên cột trong DB
    private Long id;

    @Column(name = "FullName", columnDefinition = "nvarchar(50)", nullable = false)
    @NotBlank(message = "Fullname is required! Tên không được bỏ trống")
    @Size(min = 5, max = 50, message = "Fullname is 5 to 50 characters length! Tên người từ 5...50 ký tự")
    private String fullName;

    //email cấm trùng
    @Column(name = "Email", nullable = false, unique = true)
    @NotBlank(message = "Email is required! Email không được bỏ trống")
    @Email(message = "Invalid email! Email không hợp lệ")
    private String email;

    @Column(name = "Password", nullable = false)
    @NotBlank(message = "Password is required! Password không được bỏ trống")
    @Size(min = 1, max = 30, message = "Password is 1 to 30 characters length! Tên người từ 5...50 ký tự")  //pass test nhập ngắn
    private String password;  //phải mã hoá, học sau...

    //tương tự
    private String role;      //ADMIN, STAFF, MEMBER
                              //có thể tách bảng hoặc dùng enum
    private Boolean active;   //thực tế, table User có nhiều cột
                              //avatar, ngày tạo, ngày cập nhật cuối...


}
//lưu ý: cấm tuyệt đối tạo table tên là user trong SQL Server, vì user là keyword trong SQL Server
