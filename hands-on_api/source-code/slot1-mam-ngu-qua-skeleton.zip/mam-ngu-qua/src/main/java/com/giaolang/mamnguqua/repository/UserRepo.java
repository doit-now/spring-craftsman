package com.giaolang.mamnguqua.repository;

import com.giaolang.mamnguqua.entity.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepo extends JpaRepository<UserAccount, Long> {
    //có sẵn luôn tất cả các hàm CRUD table UserAccount ăn theo cột key Id kiểu Long

    //và nếu muốn độ thêm các hàm khác trên các cột khác của table UserAccount
    //hãy khai báo các hàm ở đây, theo cú pháp đặc biệt, Spring Data tự sinh giúp câu SQL
    //hàm này có sẵn, built-in: save, findById
    //hàm save bao hàm vừa insert vừa update!!!

    //hàm này ko có sẵn: findByFullName() -> gõ theo cú pháp là có code ngầm tự sinh

    public UserAccount findByEmail(String email);
    //ko cần viết code, Spring JPA tự lo code!!!
}
