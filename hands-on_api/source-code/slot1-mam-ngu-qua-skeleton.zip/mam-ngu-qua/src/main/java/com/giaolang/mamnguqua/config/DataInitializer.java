package com.giaolang.mamnguqua.config;

import com.giaolang.mamnguqua.entity.UserAccount;
import com.giaolang.mamnguqua.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

//@RestController: API;
//@Controller: Thymeleaf, JSP, Server-Side Rendering - SSR
//@Component
//@Service
//@Repository
//@Configuration
//@Bean
//tự SpringBoot new các class, cất trong RAM server - gọi là IoC Container
//                                                    Inversion of Control
//              new xong tiêm/chích vào chỗ cần thiết - DI - Dependency Injection
//              có 3 cách tiêm: field, constructor, setter; thông qua keyword @Autowire
@Component
public class DataInitializer implements CommandLineRunner {

    //cần các repo để insert table
    @Autowired  //new ở đâu đó - IoC container và gán vào đây. Trong ram nó là Singleton
    private UserRepo userRepo;  //ko new mà vẫn xài đc, tại sao

    @Override
    public void run(String... args) throws Exception {
        //UserAccount adAcc = new UserAccount(...); //dài, nhiều field cần đổ
        UserAccount adAcc = UserAccount.builder()
                .email("ad@a.com")
                .password("a")
                .role("ADMIN")
                .fullName("Admin Hoàng Ngọc Trinh")
                .build();
        userRepo.save(adAcc);
    }
}
//để class này tự chay khi khởi động SpringBoot, thì ta phải ép nó thuộc về nhóm CommandLineRunner
