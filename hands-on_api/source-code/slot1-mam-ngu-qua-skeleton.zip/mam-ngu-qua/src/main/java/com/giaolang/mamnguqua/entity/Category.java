package com.giaolang.mamnguqua.entity;

public class Category {
}
