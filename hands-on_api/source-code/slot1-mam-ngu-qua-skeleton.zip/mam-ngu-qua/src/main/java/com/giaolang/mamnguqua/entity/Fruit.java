package com.giaolang.mamnguqua.entity;

public class Fruit {
}
