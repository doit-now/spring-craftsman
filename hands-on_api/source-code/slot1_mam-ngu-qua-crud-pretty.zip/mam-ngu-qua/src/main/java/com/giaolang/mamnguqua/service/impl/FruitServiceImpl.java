package com.giaolang.mamnguqua.service.impl;

import com.giaolang.mamnguqua.entity.Fruit;
import com.giaolang.mamnguqua.repository.FruitRepository;
import com.giaolang.mamnguqua.service.FruitService;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.NoSuchElementException;

@Service  //chịu trách nhiệm CRUD table, trả về cho bên Controller
@RequiredArgsConstructor
public class FruitServiceImpl implements FruitService {

    //tiêm FruitRepo vào
    //@Autowired
    private final FruitRepository fruitRepo;

    //Trả về tất cả trái cây. Hàm này và API này sẽ ko tốt về performance nếu table
    //có nhiều data
    @Override
    @Transactional(readOnly = true) //đánh dấu đây là hàm chỉ đọc, ko thay đổi data, giúp tối ưu performance
    public List<Fruit> getAll() {
        return fruitRepo.findAll();
    }

    //Hàm lấy danh sách trái cây nhưng phân trang.
    //Phân trang là kĩ thuật chia toàn bộ số dòng của table thành các x khối đều nhau
    //khối gọi là trang, mỗi khối có y dòng.
    //x page, y rows, ví dụ data đang có 100 trang, mỗi trang 10 dòng
    //10  10  10  10  10  10  10 .... 10 10 8
    //repository hỗ trợ sẵn hàm lấy data theo trang, mình cần setup thông số page, size

    //muốn lấy trang mấy, mỗi trang có bao nhiêu dòng. Trang đếm từ 0
    @Override
    @Transactional(readOnly = true)
    public Page<Fruit> getPage(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return fruitRepo.findAll(pageable);
    }

    @Override
    @Transactional(readOnly = true)
    public Fruit getOne(Long id) {
        return fruitRepo.findById(id).orElseThrow(() -> new NoSuchElementException());
        //  trả ra hộp[Fruit, null]  .orElse để mỏ hộp hoặc lấy đc Fruit
        //                                hoặc lấy đc null, thì ném ngoại lệ Runtime(...)

    }

    @Override
    @Transactional(readOnly = true)
    public List<String> getAllTypes() {
        List<String> types = List.of("Trái cây tươi",
                "Chế biến sẵn",
                "Trái cây sấy/lon");
        return types;
    }

    @Override
    //@Transactional(readOnly = false) //đánh dấu đây là hàm thay đổi data, giúp tối ưu performance
    @Transactional
    public Fruit save(Fruit obj) {
        //check thêm code: trái cây ko đc trùng tên
        //repo mặc định ko check theo tên, chỉ có hàm existsById(), ta độ thêm hàm exitsByName()
        //nhưng cần viết code, khai báo đúng là tự repo tự generate
        if (fruitRepo.existsFruitByName(obj.getName())) {
            throw new DataIntegrityViolationException("Fruit name must be unique, please choose another name");
        }
        return fruitRepo.save(obj);
    }

    @Override
    @Transactional
    public void deleteById(Long id) {
        if(!fruitRepo.existsById(id)) {
            throw new NoSuchElementException("Fruit not found with given id");
        }
        fruitRepo.deleteById(id);
    }

    @Override
    @Transactional
    public Fruit updateById(Long id, Fruit obj) {
        if(!fruitRepo.existsById(id)) {
            throw new NoSuchElementException("Fruit not found with given id");
        }
        obj.setId(id); //tình huống DTO ko có id
        return fruitRepo.save(obj);
    }

}
