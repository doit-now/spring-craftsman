package com.giaolang.mamnguqua.repository;

import com.giaolang.mamnguqua.entity.Fruit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FruitRepository extends JpaRepository<Fruit, Long> {
    //tự động Hibernate và JPA sẽ generate/implement 1 class, 1 object chứa toàn bộ
    //các hàm CRUD Fruit, dựa trên key
    //nhưng đồng thời nó hỗ trợ ta generate 1 loạt các hàm chưa biết, chưa có, nếu bạn viết hàm này theo đúng 1 quy ước đặt tên
    //2 loại hàm: có sẵn và        sẽ generate giúp
    //           -------              -------------
    //           biểu tượng đỏ        biểu tượng lá xanh

    public boolean existsFruitByName(String name);
}
