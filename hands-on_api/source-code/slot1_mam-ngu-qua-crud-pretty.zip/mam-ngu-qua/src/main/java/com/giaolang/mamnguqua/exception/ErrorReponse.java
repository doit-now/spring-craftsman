package com.giaolang.mamnguqua.exception;

import lombok.Data;
import lombok.Getter;

import java.time.LocalDateTime;

//class này chứa thông điệp BE trả về cho FE khi có lỗi xảy ra:
//lỗi do FE: gửi request cà chớn: JSON vớ vẩn, data vi phạm ràng buộc...
//lỗi do BE: lỗi code, lỗi logic, lỗi database...

@Getter  //chỉ cần hàm get() cho FE đọc
public class ErrorReponse {

    private int status; //mã lỗi HTTP, ví dụ 404, 500
    private String message; //thông điệp lỗi, ví dụ "Fruit not found with
    private String timestamp; //thời điểm lỗi xảy ra, ví dụ "2026-03-09T12:34:56"

    public ErrorReponse(int status, String message) {
        this.status = status;
        this.message = message;
        this.timestamp = LocalDateTime.now().toString();
    }
}

//new ErrorReponse(404, "Ko tìm thấy trái cây với id đã cho");
//sẽ đc đẩy vào trong body chủa http trả về, ResponseEntity<ErrorReponse>.  .body(new ErrorReponse(...)