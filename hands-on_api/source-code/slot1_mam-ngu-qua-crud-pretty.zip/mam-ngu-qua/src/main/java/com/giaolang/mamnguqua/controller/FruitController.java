package com.giaolang.mamnguqua.controller;

import com.giaolang.mamnguqua.entity.Fruit;
import com.giaolang.mamnguqua.service.impl.FruitServiceImpl;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * Fruit Controller - Cung cấp các end-point để quản lý, thao tác tài nguyên Fruit - table Fruit
 * <p>
 * Các end-point:
 * <p>GET ALL: /api/fruits
 * <p>GET ONE: /api/fruits/{id}
 * <p>GET TYPES: /api/fruits/types
 * <p>POST   : /api/fruits    JSON
 * <p>UPDATE : /api/fruits/{id}  JSON
 * <p>DELETE : /api/fruits/{id}
 * <p>
 * @version 2026.0309
 * @author giáo.làng
 * @since 2016
*/

@RestController
//@CrossOrigin(origins = "http://localhost:3979") //cho phép chỉ FE 3979 ĐC VÀO
@Tag(name = "The API offers fruits resource", description = "All endpoints to mannupulate fruits: CRUD")
@CrossOrigin(origins = "http://localhost:3979") //cho phép mọi FE đều vào đc
@RequestMapping("/api/fruits")  //các endpoint của controller này đều bắt đầu bằng
                                  // /api/fruits
                                  // GET ALL: /api/fruits
                                  // GET ONE: /api/fruits/1
                                  // POST   : /api/fruits    JSON
                                  // UPDATE : /api/fruits/2  JSON
@RequiredArgsConstructor
public class FruitController {

    //@Autowired
    private final FruitServiceImpl fruitService;
    //nếu ko dùng @Autowired thì phải dùng @RequiredArgsConstructor của Lombok
    //kết hợp biến final, final nghĩa là biến phải đc gán value ngay khi khai báo hoặc trong constructor

    /**
     * getAll(): Lấy về tất cả trái cây
     * @return
     * Danh sách trái cây dưới dạng JSON, kèm theo HTTP status code 200 OK
     * Nếu có lỗi xảy ra, trả về HTTP status code 500 Internal Server Error
     * @author giáo.làng
     * @since 2016
     * @version 2026.0309
     */
    @GetMapping
    public ResponseEntity<List<Fruit>> getAll() {

        return ResponseEntity.status(HttpStatus.OK).body(fruitService.getAll());
        //return ResponseEntity.ok(fruitService.getAll());
    }

    //FE       1 2 3      click 1 thì FE gửi lên BE: page=0&size=2
    @GetMapping("/page") //http://localhost:6969/api/fruits/page?page=2&size=2
    public ResponseEntity<Page<Fruit>> getPage(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "2") int size
    ) {
        return ResponseEntity.ok(fruitService.getPage(page, size));
    }

    /**
     * getOne(): Lấy về một trái cây theo id
     * @param id: id của trái cây cần lấy về
     * @return
     * Trái cây dưới dạng JSON, kèm theo HTTP status code 200 OK
     * Nếu không tìm thấy trái cây với id đã cho, trả về HTTP status code 404 Not Found
     * Nếu có lỗi xảy ra, trả về HTTP status code 500 Internal Server Error
     * @author giáo.làng
     * @since 2016
     * @version 2026.0309
     */
    @GetMapping("/{id}")
    //public ResponseEntity<Fruit> getOne(@PathVariable("id") Long id) {
    public ResponseEntity<Fruit> getOne(@PathVariable Long id) {

        return ResponseEntity.status(HttpStatus.OK).body(fruitService.getOne(id));
        //return ResponseEntity.ok(fruitService.getOne(id));
    }

    @GetMapping("/types") //trả về 3 type lẽ ra là 1 table riêng - Category
                             //để dùng cho dropdown combobox xổ xuống ở FE
    public ResponseEntity<List<String>> getTypes() {

        return ResponseEntity.status(HttpStatus.OK).body(fruitService.getAllTypes());
        //CategoryService có hàm getAll() trả về tất cả cate
    }


    /**
     * save(): Lưu một trái cây mới vào database
     * @param f: Trái cây mới cần lưu, được truyền vào dưới dạng JSON trong body của request
     * @return
     * Trái cây đã được lưu vào database dưới dạng JSON, kèm theo HTTP status code 201 Created
     * Nếu có lỗi xảy ra, trả về HTTP status code 500 Internal Server Error
     * @author giáo.làng
     * @since 2016
     * @version 2026.0309
     */
    @PostMapping   //chuẩn công nghiệp sẽ nhận vào DTO và gọi hàm map() để biến đổi từ
                     //DTO thành Entity do Service, Repo nó chơi với Entity
    public ResponseEntity<Fruit> save(@Valid @RequestBody Fruit f) {

        return ResponseEntity.status(HttpStatus.CREATED).body(fruitService.save(f));
    }

    @PutMapping("/{id}")   //chuẩn công nghiệp sẽ nhận vào DTO và gọi hàm map() để biến đổi từ
    //DTO thành Entity do Service, Repo nó chơi với Entity
    public ResponseEntity<Fruit> updateById(@PathVariable Long id, @Valid @RequestBody Fruit f) {

        return ResponseEntity.status(HttpStatus.OK).body(fruitService.updateById(id, f));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable Long id) {
        fruitService.deleteById(id);
        return ResponseEntity.noContent().build();
    }  //trả về hộp rỗng

}
