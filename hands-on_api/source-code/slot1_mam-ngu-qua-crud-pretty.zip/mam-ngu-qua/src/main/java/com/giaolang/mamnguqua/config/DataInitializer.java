package com.giaolang.mamnguqua.config;

import com.giaolang.mamnguqua.entity.Fruit;
import com.giaolang.mamnguqua.repository.FruitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component //IoC container - Inversion of Control - SpringBoot giành việc new object
public class DataInitializer implements CommandLineRunner {

    //tiêm thằng FruitRepository (Dependency Injection - có 3 cách tiêm)
    @Autowired
    private FruitRepository fruitRepo;

    @Override
    public void run(String... args) throws Exception {

        //tạo sẵn 1 vài trái cây khi ta run cái app
        //xài Builder của Lombok, hoặc new Fruit(tham số đưa vào kiểu truyền thống)

        List<Fruit> fruits = List.of(
                Fruit.builder()
                        .name("Mãng cầu")
                        .description("Mãng cầu là loại trái cây...")
                        .price(30000)
                        .type("Trái cây tươi")
                        .build(),
                Fruit.builder()
                        .name("Sung")
                        .description("Sung là loại trái cây...")
                        .price(40000)
                        .build(),
                Fruit.builder()
                        .name("Dừa")
                        .description("Dừa là loại trái cây...")
                        .price(50000)
                        .build(),
                Fruit.builder()
                        .name("Đu đủ")
                        .description("Đu đủ là loại trái cây...")
                        .price(60000)
                        .build(),
                Fruit.builder()
                        .name("Xoài")
                        .description("Xoài là loại trái cây...")
                        .price(70000)
                        .build()
        );
        fruitRepo.saveAll(fruits);
    }

//    public void run(String... args) throws Exception {
//
//        //tạo sẵn 1 vài trái cây khi ta run cái app
//        //xài Builder của Lombok, hoặc new Fruit(tham số đưa vào kiểu truyền thống)
//        Fruit cau = Fruit.builder()
//                .name("Mãng cầu")
//                .description("Mãng cầu là loại trái cây...")
//                .price(30000)
//                .type("Trái cây tươi")
//                .build();
//        Fruit sung = Fruit.builder()
//                .name("Sung")
//                .description("Sung là loại trái cây...")
//                .price(40000)
//                .build();
//        Fruit dua = Fruit.builder()
//                .name("Dừa")
//                .description("Dừa là loại trái cây...")
//                .price(50000)
//                .build();
//        Fruit du = Fruit.builder()
//                .name("Đu đủ")
//                .description("Đu đủ là loại trái cây...")
//                .price(60000)
//                .build();
//        Fruit xoai = Fruit.builder()
//                .name("Xoài")
//                .description("Xoài là loại trái cây...")
//                .price(70000)
//                .build();
//        //List<Fruit> fruits = List.of(cau, sung, dua,du, xoai);
//        List<Fruit> fruits = Arrays.asList(cau, sung, dua,du, xoai);
//        fruitRepo.saveAll(fruits);
////        fruitRepo.save(cau);
////        fruitRepo.save(sung);
////        fruitRepo.save(dua);
//    }


}
