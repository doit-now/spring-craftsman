package com.giaolang.mamnguqua.exception;


import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.NoSuchElementException;

@RestControllerAdvice //đánh dấu đây là class tập kết, thầu các Error Exception đem về đây xử lí báo lại cho FE
public class GlobalExceptionHandler {

    //mỗi hàm ứng với 1 Exception bạn muốn trả về cho FE
    @ExceptionHandler(NoSuchElementException.class)
    public ResponseEntity<ErrorReponse> handleNotFoundException(NoSuchElementException ex) {

        ErrorReponse errorResponse = new ErrorReponse(HttpStatus.NOT_FOUND.value(), "Resource (fruits, orders...) not found");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);

//        ErrorReponse errorResponse = new ErrorReponse(404, "Resource (fruits, orders...) not found");
//        return ResponseEntity.status(404).body(errorResponse);
    }

    //Đưa JSON cà chớn, Controller tự phát hiện giúp
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorReponse> handleUnreadable(HttpMessageNotReadableException ex) {
        ErrorReponse errorResponse = new ErrorReponse(HttpStatus.BAD_REQUEST.value(), "JSON cà chớn " + ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);

    }

    //Đưa data vi phạm validation, ví dụ: name trống, ngắn 1 kí tự (min 2)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorReponse> handleValidation(MethodArgumentNotValidException ex) {
        //có thể có nhiều error khi gửi JSON lên và map vào Fruit:
        //tên thì vừa ngắn, số thì nhỏ, năm sinh thì bé hơn năm X...
        //trả về 1 list vi phạm, và ta get(0) lấy lỗi đầu tiên, rồi getDefaultMessage() lấy thông điệp lỗi đã khai báo trong annotation validation
        String errorMessage = ex.getBindingResult().getFieldErrors().get(0).getDefaultMessage();

        ErrorReponse errorResponse = new ErrorReponse(HttpStatus.BAD_REQUEST.value(), errorMessage);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);

    }

    //Đưa data vi phạm validation, ví dụ: name trống, ngắn 1 kí tự (min 2)
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ErrorReponse> handleDuplicate(DataIntegrityViolationException ex) {

        ErrorReponse errorResponse = new ErrorReponse(HttpStatus.CONFLICT.value(), "Duplicate data: " + ex.getMostSpecificCause().getMessage());
        return ResponseEntity.status(HttpStatus.CONFLICT).body(errorResponse);

    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorReponse> handleGeneral(Exception ex) {

        ErrorReponse errorResponse = new ErrorReponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Internal Server Error: " + ex.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
    }
}
