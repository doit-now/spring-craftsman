package com.giaolang.mamnguqua.service;

import com.giaolang.mamnguqua.entity.Fruit;
import org.springframework.data.domain.Page;

import java.util.List;

public interface FruitService {

    public List<Fruit> getAll();
    public Page<Fruit> getPage(int page, int size);
    public Fruit getOne(Long id);
    public List<String> getAllTypes();

    public Fruit save(Fruit obj);
    public void deleteById(Long id);
    public Fruit updateById(Long id, Fruit obj);


}
