package com.giaolang.greetingapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreetingApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(GreetingApiApplication.class, args);

        //sout() ở đây, thì chắc chắn sẽ in ra sau khi SpringBoot và Tomcat chạy xong. Ta tách hàm in info start...
        printStartupInfo();
    }

    /**
     * Print startup information to console
     */
    private static void printStartupInfo() {   //raw string
        System.out.println("""
                
                ╔═══════════════════════════════════════════════════════════╗
                ║   🍎            LỜI CHÀO BÍNH NGỌ 2026               🍎   ║ 
                ╠═══════════════════════════════════════════════════════════╣
                ║                                                           ║
                ║  📌 Server:    http://localhost:6969                      ║
                ║  📚 Swagger:   http://localhost:6969/swagger-ui.html      ║ 
                ║  🚀 API Endpoints:                                        ║
                ║     • GET    /api/greeting                                ║
                ║     • GET    /api/greeting/vi                             ║
                ║     • GET    /api/greeting/en                             ║
                ║     • GET    /api/greeting/beer                           ║
                ║     • GET    /api/greeting/code                           ║
                ╚═══════════════════════════════════════════════════════════╝
                """);
    }

}
