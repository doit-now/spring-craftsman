package com.giaolang.greetingapi.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Các API (endpoint) trả về thông điệp đầu năm
 * <p>
 * Hãy gọi các API theo url dưới đây:
 * http://localhost:6969/api/greeting
 * <p>
 * http://localhost:6969/api/greeting/vi
 * <p>
 * http://localhost:6969/api/greeting/en
 * <p>
 * http://localhost:6969/api/greeting/beer
 * <p>
 * http://localhost:6969/api/greeting/code
 * <p>
 * @author giáo.làng
 * @since 2026
 * @version 2026.0226
 */
@RestController    //@Controller: sẽ trả về html/css/js, trả về trang web thuần
                      //@RestController: sẽ trả về text thuần, JSON, data thô
@RequestMapping("/api/greeting")
public class GreetingController {

    @GetMapping
    public String greet() {
        //nếu là @Controllert và Thymeleaf, JSP: trả về tên page có html...
        return "Chào Xuân Bính Ngọ 2026 - Code for food!!!";
    }
    @GetMapping("/vi")
    public String greetVi() {  //hộp trả về cho client là hộp mặc định server gói hàng gíup, dán nhãn 200 nếu giao thành công
        return "Tết Tết Tết Tết Tết hết òi!!! Học API thoy";
    }
    @GetMapping("/en")
    public ResponseEntity<String> greetEn() {
        return ResponseEntity.status(HttpStatus.CREATED).body("HAPPY CODE | HAPPY MONEY | HAPPY LIFE!!!");
    }                      //HỘP ĐỘ RIÊNG GỬI VỀ CLIENT, DÁN NHÃN 201 NẾU THÀNH CÔNG!!!

    @GetMapping("/beer")
    public ResponseEntity<String>  greetBeer() {
        //return ResponseEntity.status(793).body("TA SAY KHÔNG PHẢI VÌ TRINH MÀ LÀ VÌ JAV"); //okie chạy mlem, nhưng ko theo chuẩn mã status
        return ResponseEntity.ok().body("TA SAY KHÔNG PHẢI VÌ TRINH MÀ LÀ VÌ JAV");
        //                 mã 200 đc dùng
    }  //mã trạng thái thùng hàng trả về là xxx 1xx --- 9xx
      //4xx: 401, 403, 404
      //5xx: 503

    @GetMapping("/code")
    public ResponseEntity<Map<String, Object>> greetCode() {

        Map<String, Object> studentX = new HashMap<>();
        studentX.put("id", "SE1");
        studentX.put("name", "AN NGUYỄN");
        studentX.put("yob", 2004);
        studentX.put("maxim", "Chơi không học cuối năm đi bán muối!!! Nhưng bữa nay đi mua vàng");
        //return ResponseEntity.ok().body(studentX);
        return ResponseEntity.status(HttpStatus.OK).body(studentX);
    }
}
