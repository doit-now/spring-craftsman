package com.giaolang.coffee.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class LoginController {

    //việc 1: load trang trả về - GET TRUYỀN THỐNG
    //@GetMapping("/")
    @GetMapping({"/", "/login", "/ahihi"})
    public String showLogin() {
        return "login"; //trả về trang login.html
    }

    @PostMapping("/doLogin")
    //HÀM POST NHẬN 2 VALUE TỪ DƯỚI PAGE GỬI LÊN (NAME ATTRIBUTE)
    public String doLoginAhihi(@RequestParam("email") String username, @RequestParam("pass") String password, Model model, RedirectAttributes rediect) {
        //return "products"; //trả về trang products.html
        //        gọi trang products mà ko thông qua ProductController

        //cất email nhận đc vào cái hộp, gửi cho trang
        model.addAttribute("sentEmail", username);
        //HỘP, TỦ GỬI ĐỒ Ở TTTM,
        //                 SIÊU THỊ      key          giỏ, túi, đồ muốn gửi

        //return "products";               //KO ĐỔI URL, vẫn là doLogin

        //QUAN TRỌNG NÈ, CHỈ XÀI CHO REDIRECT, ĐÍNH KÈM THÊM THÔNG TIN CHO HỘP
        //MODEL CỦA BÊN GỌI /products
        rediect.addFlashAttribute("sentEmail", username);
        //email đã đính kèm thêm vào Model của bên Product-Controller

        //ẨN HIỆN LINK UPDATE|DELETE BÊN TRANG PRODUCTS
        //hard-coded trước, phần này lấy từ DB mới đúng
        if(username.equalsIgnoreCase("ngoctrinh"))
            rediect.addFlashAttribute("role", 1);  //1 là admin
        else
            rediect.addFlashAttribute("role", 2);  //2 là staff

        //cất số 1 vào thùng, gửi sang trang products để ẩn/hiện NEW|UPDATE|DELETE
        //MUỐN LẤY SỐ 1, DÙNG KEY ROLE

        return "redirect:/products";   //ĐỔI URL   , là /products
    }   //CHÍNH THỨC PRODUCT CONTROLLER XUẤT HIỆN

    //xử lí FORM GỬI DATA LÊN, PHỤC VỤ POST
}
