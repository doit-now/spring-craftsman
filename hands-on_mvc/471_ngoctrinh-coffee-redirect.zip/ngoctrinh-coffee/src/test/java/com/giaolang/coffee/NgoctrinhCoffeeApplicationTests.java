package com.giaolang.coffee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NgoctrinhCoffeeApplicationTests {

    @Test
    void contextLoads() {
    }

}
