package com.giaolang.coffee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgoctrinhCoffeeV4finalApplication {

    public static void main(String[] args) {
        SpringApplication.run(NgoctrinhCoffeeV4finalApplication.class, args);
    }

}
