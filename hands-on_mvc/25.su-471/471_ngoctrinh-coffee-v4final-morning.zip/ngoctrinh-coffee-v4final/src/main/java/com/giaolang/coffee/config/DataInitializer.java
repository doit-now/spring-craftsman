package com.giaolang.coffee.config;

import com.giaolang.coffee.entity.Category;
import com.giaolang.coffee.service.CategoryService;
import com.giaolang.coffee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

//TỰ CHẠY 1 LẦN DUY NHẤT KHI KHI TOMCAT ĐC CHẠY, LÀ IOC CONTAINER NÓ CHẠY, DÙNG ĐỂ TẠO TABLE, TẠO SẴN DATA TRONG TABLE
//BÀI PE CHO SẴN TÊN TABLE, SẴN DATA, COPY DATA TỪ ĐỀ THI VÀO ĐÂY!!!
@Component  //mày phải là bean mới đc gọi
public class DataInitializer implements CommandLineRunner {

    //nhờ vả 3 service giúp tạo table, chèn sẵn data
    @Autowired
    private CategoryService cateService;

    @Autowired
    private ProductService productService;

    @Override
    public void run(String... args) throws Exception {
        //TẠO OBJECT, NHỜ SERVICE ĐẨY XUỐNG
        //TẠO TABLE 1 TRƯỚC, N SAU (DO KHOÁ NGOẠI THAM CHIẾU KHOÁ CHÍNH)
        Category cat1 = new Category("Trà sữa", "Uống trà sữa, hoài nghi pass môn này");
        Category cat2 = new Category("Cà phê", "Uống Cà phê Java top server 100");
        Category cat3 = new Category("Beer-tăng lực", "Uống bia trộn Java thì shock code thăng hoa");
        Category cat4 = new Category("Bánh kẹo", "Đời ngọt ngào mướt mượt như Ngọc Trinh");

        //xuống table hoy khi tomcat chạy
        cateService.saveCategory(cat1);
        cateService.saveCategory(cat2);
        cateService.saveCategory(cat3);
        cateService.saveCategory(cat4);

    }
}
