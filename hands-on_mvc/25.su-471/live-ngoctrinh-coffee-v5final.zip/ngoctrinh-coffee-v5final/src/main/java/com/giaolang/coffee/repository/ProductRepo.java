package com.giaolang.coffee.repository;

import com.giaolang.coffee.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepo extends JpaRepository<Product, String> {

    //ko cần viết hàm crud table Product vì ta xài derived query methods

    //SPRING BOOT, SPRING JPA, SPRING HIBERNATE CÓ 2 CƠ  CHẾ SINH HÀM TỰ ĐỘNG CHO MỖI ENTITY/TABLE
    //NHỮNG HÀM NỔI TIẾNG, PHỔ BIẾN, HAY DÙNG THƯỜNG XUYÊN
    //JPA/HIBERNATE NÓ SẼ SINH SẴN TRƯỚC CÁC HÀM NÀY: save() findAll() findAllBy...()
    //delete()... -> BUILT-IN CÓ SẴN RỒI, KO CẦN KHAI BÁO Ở REPO, MÀ SERVICE CHẤM XÀI LUN

    //NHỮNG HÀM ĐẶC THÙ, ĐẶC BIỆT RIÊNG, ÍT KHI DÙNG
    //THÌ CHẤM BÊN SERVICE KO ĐỦ, MÀ PHẢI GÕ TÊN HÀM BÊN NÀY, ĐỂ RA LỆNH CHO JPA/HIBERNATE
    //BIẾT CẦN GENERATE RA CODE CHO HÀM ĐẶC BIỆT NÀY
    //CÚ PHÁP VIẾT HÀM DẠNG NÀY LÀ CÓ CÚ PHÁP RIÊNG: ĐỘNG TỪ + PHÂN LOẠI TRẢ VỀ + KIỂU WHERE...
    //TỰ SINH CÂU SQL VÀ CODE KHI BIÊN DỊCH CHÍNH CLASS
    //HÀM DẠNG NÀY GỌI TÊN LÀ: DERIVED QUERY METHOD: HÀM DẪN XUẤT, PHÁT SINH TỪ CÂU QUERY GẮN TRÊN TÊN HÀM
    public List<Product> searchAllByNameContainingIgnoreCase(String keyword);

    //HÀM BUILT-IN NỔI TIẾNG: HÀM SINH TRƯỚC
    //HÀM HIẾM MUỘN: SINH SAU
    //ĐỀU PHẢI VIẾT THEO TEMPLATE: DERIVED QUERY METHOD



}
