package com.giaolang.coffee.config;

import com.giaolang.coffee.entity.Account;
import com.giaolang.coffee.entity.Category;
import com.giaolang.coffee.entity.Product;
import com.giaolang.coffee.service.AccountService;
import com.giaolang.coffee.service.CategoryService;
import com.giaolang.coffee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

//TỰ CHẠY 1 LẦN DUY NHẤT KHI KHI TOMCAT ĐC CHẠY, LÀ IOC CONTAINER NÓ CHẠY, DÙNG ĐỂ TẠO TABLE, TẠO SẴN DATA TRONG TABLE
//BÀI PE CHO SẴN TÊN TABLE, SẴN DATA, COPY DATA TỪ ĐỀ THI VÀO ĐÂY!!!
@Component  //mày phải là bean mới đc gọi
public class DataInitializer implements CommandLineRunner {

    //nhờ vả 3 service giúp tạo table, chèn sẵn data
    @Autowired
    private CategoryService cateService;

    @Autowired
    private ProductService productService;

    @Autowired
    private AccountService accountService;

    @Override
    public void run(String... args) throws Exception {

        accountService.saveAccount(new Account("ad@a.com", "ad", 1));
        accountService.saveAccount(new Account("st@a.com", "st", 2));
        accountService.saveAccount(new Account("mb@a.com", "mb", 3));

        //TẠO OBJECT, NHỜ SERVICE ĐẨY XUỐNG
        //TẠO TABLE 1 TRƯỚC, N SAU (DO KHOÁ NGOẠI THAM CHIẾU KHOÁ CHÍNH)
        Category cat1 = new Category("Trà sữa", "Uống trà sữa, hoài nghi pass môn này");
        Category cat2 = new Category("Cà phê", "Uống Cà phê Java top server 100");
        Category cat3 = new Category("Beer-tăng lực", "Uống bia trộn Java thì shock code thăng hoa");
        Category cat4 = new Category("Bánh kẹo", "Đời ngọt ngào mướt mượt như Ngọc Trinh");

        //ta tạo dữ liệu table product, product thì phải thuộc về cate nào đó
        Product p1c1 = new Product("TS01", "Trà Sữa Hàng Xóm Nấu", 79, 39_000); //39K
        Product p2c1 = new Product("TS02", "Trà Sữa Ngọc Trinh Nấu", 79, 68_000); //68K
        cat1.addProduct(p1c1);
        cat1.addProduct(p2c1);

        Product p1c2 = new Product("CF01", "Cafe Nguyên Bản Vị Java", 35, 5_700_000); //học phí
        Product p2c2 = new Product("CF02", "Cafe Vị Ngọc Trinh", 35, 2_350_000); //lệ phí đổi ngành
        Product p3c2 = new Product("CF03", "Cafe Vị Java Đậm Đà Vị Ngọc Trinh", 6789, 52_000_000); //lương tạm đủ uống cafe
        cat2.addProduct(p1c2);
        cat2.addProduct(p2c2);
        cat2.addProduct(p3c2);

        //xuống table hoy khi tomcat chạy, CASCADE ALL
        //NGHĨA LÀ TABLE 1 ĐI XUỐNG THÌ TABLE N XUỐNG LUÔN!!!
        cateService.saveCategory(cat1); //LIST MÓN TRÀ XUỐNG TABLE LUÔN
        cateService.saveCategory(cat2); //LIST MÓN CAFE XUỐNG TABLE LUÔN
        cateService.saveCategory(cat3);
        cateService.saveCategory(cat4);

    }
}
