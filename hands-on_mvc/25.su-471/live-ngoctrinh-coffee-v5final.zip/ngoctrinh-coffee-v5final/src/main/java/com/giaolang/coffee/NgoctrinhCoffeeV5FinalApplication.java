package com.giaolang.coffee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgoctrinhCoffeeV5FinalApplication {

    public static void main(String[] args) {
        SpringApplication.run(NgoctrinhCoffeeV5FinalApplication.class, args);
    }

}
