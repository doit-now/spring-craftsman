package com.giaolang.coffee.repository;

import com.giaolang.coffee.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepo extends JpaRepository<Account,Long> {

    public Account findByEmail(String email);
    //hàm tự sinh nhưng độ theo nhu cầu -derived query method
}
