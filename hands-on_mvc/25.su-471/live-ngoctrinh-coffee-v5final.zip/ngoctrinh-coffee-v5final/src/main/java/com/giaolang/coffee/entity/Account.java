package com.giaolang.coffee.entity;


import jakarta.persistence.*;

@Entity
@Table(name = "Account")
public class Account {  //POJO: PLAIN OLD JAVA OBJECT

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "Id")
    private Long id; //key tự tăng phải là Long wrapper (long)

    @Column(name = "Email", length = 100, nullable = false, unique = true)
    private String email;

    @Column(name = "Password", length = 30, nullable = false)
    private String password;

    @Column(name = "Role", nullable = false)
    private int role; //xem đề bài role = giá trị gì
    //                  1 admin, 2 staff, 3 member
    //private boolean active; //true/false
    //private String fullname;
    //private String phone;

    public Account() {
    }

    public Account(String email, String password, int role) {
        this.role = role;
        this.password = password;
        this.email = email;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "Account{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", role=" + role +
                '}';
    }
}
