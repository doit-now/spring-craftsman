package com.giaolang.coffee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgoctrinhV3Application {

    public static void main(String[] args) {
        SpringApplication.run(NgoctrinhV3Application.class, args);
    }

}
