package com.giaolang.coffee.repository;

import com.giaolang.coffee.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepo extends JpaRepository<Product,String> {

    //mặc định JPA sẽ cung cấp cho bạn rất nhiều hàm, tự nó code luôn cho bạn
    //bạn chỉ cần đặt tên hàm theo 1 quy tắc, dính đến tên field, là sẽ có hàm luôn

    //SPRING JPA CUNG CẤP 2 LOẠI HÀM MÀ BẠN KO CẦN PHẢI CODE
    //1. HÀM CÓ SẴN CỨ VIỆC NGAY BÊN SERVICE, KO CẦN KHAI BÁO TÊN HÀM Ở ĐÂY
    //built-in method: save(), findAll(), findById()...

    //2. HÀM TỰ SINH RA THEO CÁCH BẠN GÕ TÊN HÀM THEO CÚ PHÁP
    //derived query method
    //BẠN CẦN GÕ TÊN HÀM BẠN MUỐN TẠO Ở ĐÂY, KO CẦN VIẾT CODE
    public List<Product> searchAllByNameContainingIgnoreCase(String keyword);
    //tự sinh hàm select * from Product where Name like %keyword%''


}
