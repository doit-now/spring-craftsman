package com.giaolang.coffee.controller;

import com.giaolang.coffee.entity.Product;
import com.giaolang.coffee.service.CategoryService;
import com.giaolang.coffee.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller //bean luôn
public class ProductController {

    //NHỜ SERVICE GIÚP LÁY FULL DATA TỪ TABLE
    //TỰ SERVICE CHƠI VỚI REPO. NGUYÊN LÝ SRP
    @Autowired
    private ProductService productService;

    @Autowired  //phục vụ cho danh sách treo đầu dê...
    private CategoryService categoryService;

    @GetMapping("/products")
    public String showProducts(@RequestParam(name = "kw", required = false, defaultValue = "") String keyword, Model model) {

        List<Product> productList;

        if (keyword.equals("")) {
            //show full
            productList = productService.getAllProducts();
        }
        else {
            //search theo keyword hoy, thiếu hàm search rồi
            productList = productService.searchProductsByName(keyword);//search gì đó;  //where like!!!!!!!!!!!!
        }

        model.addAttribute("prods", productList);

        //thùng hàng đi kèm trang chứa full sản phầm từ table
        return "products"; //.html
    }

    //link edit đc nhấn
    @GetMapping("/products/edit/{id}")
    public String editProduct(@PathVariable("id") String id, Model model) {

        //có id rồi, where và ném thằng này về trang form - detail
        Product product = productService.getProductById(id);

        //                         Product selectedOne = product; ở trên
        model.addAttribute("selectedOne", product);

        model.addAttribute("cates", categoryService.getAllCategories());

        //THÊM 1 BIẾN FLAG, PHẤT CỜ TUỲ TÌNH HUỐNG, ĐẨY BIẾN NÀY CHO -FORM ĐỂ BIẾT MODE CỦA MÀN HÌNH LÀ CREATE|UPDATE
        //                   String formMode = "edit";
        model.addAttribute("formMode", "edit");

        //thùng hàng đi kèm trang chứa full sản phầm từ table
        return "product-form"; //.html
    }
    //link new đc nhân
    @GetMapping("/products/new")
    public String newProduct(Model model) {

        //constructor rỗng tạo 1 object mang giá trị default ở các field bên trong
        //chuỗi là rỗng, số là 0, boolean là sai
        model.addAttribute("selectedOne", new Product());

        model.addAttribute("cates", categoryService.getAllCategories());
        //thùng hàng đi kèm trang chứa full sản phầm từ table

        model.addAttribute("formMode", "new");

        return "product-form"; //.html
    }

    //button save đc nhấn
    @PostMapping("/products/save")
    //làm ko khéo, 1 đống @RequestParam map từng field ở form vào từng biến ở tham số hàm
    //public String saveProduct(@RequestParam("name") String name, @Res....) {
    public String saveProduct(@Valid @ModelAttribute("selectedOne") Product product, BindingResult result, Model model, @RequestParam("formMode") String formMode) {
        //@Valid phải đứng trước lệnh @ModelAttribute, đứng trước lệnh gom data từ object dưới html gửi lên, mang ý nghĩa, tui sẽ check data anh gửi từ html lên có hợp lệ như khai báo trong entity hay ko
        //nếu ko hợp lệ, gom lỗi vào trong object BindingResult.
        //biến gom lỗi phải nằm ngay sau @ModelAttribute

        //trong link /edit link /new ta đã gửi xuống product-form cái biến formMode = edit, new
        //ta nên gửi ngược lại cái giá trị này lên trên hàm save để ta biết hàm này đc goi
        //ở mode nào, new hay edit
        //new -> ta đc quyền làm cái trò: ID CÓ TRÙNG HAY KO
        //EDIT -> SAVE BT
        //if formMode == new, == edit  .equals("new")

        //nếu có lỗi nhập thì vòng lại màn hình product-form in câu chửi, và yêu cầu sửa
        if (result.hasErrors()) {

            //đưa lại cái danh sách cates vì cates list đc xử lí riêng
            model.addAttribute("cates", categoryService.getAllCategories());
            model.addAttribute("formMode", formMode);

            return "product-form";  //quay trở lại màn hình detail show lỗi
        }

        //nếu nhập mlem, thì save bình thường...

        //check key trùng nè
        if (formMode.equals("new")) {
            //viết thêm hàm key trùng!!! GET ID ĐC GỬI TỪ FORM
            if (productService.existsProductById(product.getId())) {
                //CHỬI, VÀ KO CHO ĐI TIẾP
                //TỨC LÀ VÒNG LẠI MÀN HÌNH NEW
                //đưa lại cái danh sách cates vì cates list đc xử lí riêng
                model.addAttribute("cates", categoryService.getAllCategories());
                model.addAttribute("formMode", formMode);
                model.addAttribute("duplicated", "Trùng key rồi!");

                return "product-form";  //quay trở lại màn hình detail show lỗi
            }

        }

        //gọi service save hoy, tạm bỏ qua key trùng, validation
        productService.saveProduct(product);

        return "redirect:/products"; //url nhen, ko phải tên trang!!!
    }      //gọi url mới, đổi url trên browser, tránh resubmission

    //link delete đc nhấn
    //link edit đc nhấn
    @GetMapping("/products/delete/{id}")
    public String deleteProduct(@PathVariable("id") String id, Model model) {

        productService.deleteProductById(id);

        //thùng hàng đi kèm trang chứa full sản phầm từ table
        return "redirect:/products"; //.html
    }
    //link n
    //link search đc nhấn

}
