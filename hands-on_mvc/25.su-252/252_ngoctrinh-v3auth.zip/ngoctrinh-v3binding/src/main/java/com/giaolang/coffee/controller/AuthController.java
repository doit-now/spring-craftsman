package com.giaolang.coffee.controller;

import com.giaolang.coffee.entity.Account;
import com.giaolang.coffee.service.AccountService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    @Autowired
    AccountService accountService;

    //chế 1 link logout
    @GetMapping({"/logout"})
    public String doLogout(Model model, HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }


    //show màn hình login  @Get
    @GetMapping({"/", "/login"})
    public String showLogin(Model model) {
        return "login";
    }

    //xử lí nút bấm [login]  @Post
    @PostMapping("/do-login")
    public String doLogin(@RequestParam("email") String email, @RequestParam("pass") String password, Model model, HttpSession session) {

        Account account = accountService.authenticate(email, password);
        //null hoặc 1 account, đã loại role member rồi chỉ còn admin và staff
        if (account == null) {
            model.addAttribute("error", "Wrong credentials");
            return "login";
        }

        //cất thông tin account để dành cho các trang xài tới lui lúc check quyền
        //cất lâu dài!!! dùng Session, thùng chứa tồn tại lâu dài hơn Model
        session.setAttribute("loggedInAccount", account);
        //RAM server có biến toàn cục:
        //           Account loggedInAccount = account;  //acc vừa lấy từ table!!!

        //ổn với staff và admin, sang trang main
        return "redirect:/products";


    }
    //xử lí nút bấm/link logout @Get


}
