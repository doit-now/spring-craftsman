package com.giaolang.coffee.service;

import com.giaolang.coffee.entity.Account;
import com.giaolang.coffee.repository.AccountRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountService {

    @Autowired
    private AccountRepo accountRepo;

    //hàm này nhận vào email và password, trả về null hoặc 1 account mà match email/pass
    //làm cẩn thận hơn, còn ném ngoại lệ tuỳ tình huống: đúng mail, sai pass -> nhánh reset
    //                                                   sai mail (ko care pass) -> nhánh sign-up
    //                                                   đúng mail sai pass nhiều lần -> lock
    public Account authenticate(String email, String password) {
        //nhờ repo tìm Account theo email!!! tui ko tìm vừa email và pass
        Account acc = accountRepo.findByEmail(email);
        if (acc == null) {
            return null;  //chuẩn nên ném ra 1 ngoại lệ email ko tồn tại
        }
        if (!acc.getPassword().equals(password)) {
            return null;  //ném ngoại lệ pass sai
        }
        //kiểm tra luôn cột active = 1, 0
//        if (!acc.getActive() == 1) {
//            return null;  //ném ngoại lệ account đang bị disable
//        }
        //sai role ko cho vào, chỉ chấp nhận role 1 ad, role 3 staff
        //member vào chửi luôn!!!
        if (acc.getRole() == 2) {  //member ko cho vào!!!
            return null; //ném ngoại lệ ko có quyền vào app
        }


        return acc;  //match email và pass thì return
    }

    //PHỤC VỤ CHO VIỆC TẠO ACCOUNT NGAY LÚC CHẠY APP
    public void saveAccount(Account acc) {
        accountRepo.save(acc);
    }
}
