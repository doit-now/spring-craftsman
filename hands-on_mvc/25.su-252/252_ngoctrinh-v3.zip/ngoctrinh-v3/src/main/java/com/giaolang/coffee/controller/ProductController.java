package com.giaolang.coffee.controller;

import com.giaolang.coffee.entity.Product;
import com.giaolang.coffee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller //bean luôn
public class ProductController {

    //NHỜ SERVICE GIÚP LÁY FULL DATA TỪ TABLE
    //TỰ SERVICE CHƠI VỚI REPO. NGUYÊN LÝ SRP
    @Autowired
    private ProductService productService;

    @GetMapping("/products")
    public String showProducts(Model model) {

        List<Product> productList = productService.getAllProducts();

        model.addAttribute("prods", productList);
        //thùng hàng đi kèm trang chứa full sản phầm từ table
        return "products"; //.html
    }
}
