package com.giaolang.coffee.controller;

import com.giaolang.coffee.entity.Account;
import com.giaolang.coffee.service.AccountService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    @Autowired
    private AccountService accountService;

    //tối thiểu 3 hàm xử lí các request từ browser
    //1. SHOW RA TRANG LOGIN -> GET URL
    @GetMapping({"/", "/login"})
    public String showLogin() {
        return "login"; //khỏi gửi thùng hàng, chỉ show 2 ô email/pass + nút login
    }

    //2. XỦ LÍ NÚT BẤM [LOGIN] -> POST URL
    @PostMapping("/do-login")
    public String doLogin(@RequestParam("email") String email, @RequestParam("pass") String password, Model model, HttpSession session) {

        Account acc = accountService.authenticate(email, password);

        if (acc == null) {
            //sai 1 cái gì đó: sai email, hoặc pass, hoặc member bày đặt login
            model.addAttribute("error", "Wrong credentials");
            return "login";
        }

        //thành công rồi, thì sang trang produts
        //CẤT GIỮ DÀI LÂU THÔNG TIN USER ĐÃ LOGIN
        session.setAttribute("loggedInUser", acc);
        //              Account loggedInUser = acc;

        //trong ram có 1 thùng chứa tồn tại lâu dài giữa các trang, đc gọi là session
        //bỏ đồ, lấy đồ y chang thùng chứa model truyền thống
        //nó chỉ chết khi hết thời gian default (thường 30 phút), hoặc mình chủ động kill thùng

        return "redirect:/products"; //khỏi gửi thùng hàng, chỉ show 2 ô email/pass + nút login
    }
    //3. XỬ LÍ LOGOUT -> GET -> URL
    @GetMapping("/logout")
    public String doLogout(HttpSession ss) {

        ss.invalidate(); //huỷ cái thùng session!!! mất luôn user đã login

        return "redirect:/login"; //khỏi gửi thùng hàng, chỉ show 2 ô email/pass + nút login
    }

}
