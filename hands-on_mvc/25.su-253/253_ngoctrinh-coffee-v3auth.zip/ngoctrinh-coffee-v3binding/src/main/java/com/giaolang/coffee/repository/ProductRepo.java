package com.giaolang.coffee.repository;

import com.giaolang.coffee.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepo extends JpaRepository<Product,String> {

    public boolean existsById(String id);

    public List<Product> searchAllByNameContainingIgnoreCase(String kw);
    
}


