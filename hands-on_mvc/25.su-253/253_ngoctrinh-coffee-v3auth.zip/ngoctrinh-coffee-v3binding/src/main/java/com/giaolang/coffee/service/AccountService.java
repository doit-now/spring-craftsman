package com.giaolang.coffee.service;

import com.giaolang.coffee.entity.Account;
import com.giaolang.coffee.repository.AccountRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountService {
    
    @Autowired
    private AccountRepo accountRepo;
    
    //cần mấy hàm??? 2 hàm
    //save Account xuống DB, code first, có account sẵn
    public void saveAccount(Account account) {
        accountRepo.save(account);  //hàm tự sinh mà ko cần gõ trong repo luôn
    }
    
    //login trả về Account hợp lệ để đi tiếp các màn hình
    public Account authenticate(String email, String password) {
        
        Account account = accountRepo.findByEmail(email);
        if (account == null) {  //email ko tồn tại
            return null;        //TODO: NÊN NÉM NGOẠI LỆ X NÀO ĐÓ BIỂU THỊ SAI EMAIL    
        }
        if (!account.getPassword().equals(password)) { //DECODE PASSWORD
            return null;    //PASS SAI NÊN NÉM 1 NGOẠI LỆ KHÁC BIỂU THỊ SAI PASS
        }

        //CHECK ROLE LUÔN, NẾU ROLE = 2 LÀ MEMBER, CHO NULL LUÔN, HOẶC NÉM NGOẠI LỆ BẠN KO CÓ QUYỀN
        if (account.getRole() == 2) {
            return null;  //nên ném ngoại lệ Z biểu thị ko có quyền
        }

        //CHECK ACTIVE???
//        if (account.getActive == false) {
//            return null;
//        }
        
        //KO SAI GÌ CẢ THÌ MLEM, TRẢ VỀ ACCOUNT HỢP LỆ, TRONG ACC CÓ LUÔN ROLE
         return account;  //CHỈ CÒN LẠI ADMIN VÀ STAFF
    }
    
}
