package com.giaolang.coffee.entity;

import ch.qos.logback.core.boolex.EvaluationException;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "Product")
public class Product {

    @Id
    @Column(name = "Id")
    @NotBlank(message = "Id is requiresd!")
    @Size(min = 4, max = 4, message = "Id length must be 4 characters")
    private String id; //key là chuỗi

    @Column(name = "Name", nullable = false, columnDefinition = "NVARCHAR(50)")
    @NotBlank(message = "Name is requiresd! Tên ko được bỏ trống!")
    @Size(min = 5, max = 50, message = "Name length is in the range of 5...50 characters")
    @Pattern(
            regexp = "^(\\p{Lu}\\p{Ll}+)(\\s\\p{Lu}\\p{Ll}+)*$",
            message = "Mỗi từ phải bắt đầu hoa, chỉ chứa chữ (Unicode), không số/ký tự đặc biệt, không khoảng trắng thừa"
    )
    private String name;

    @Column(name = "Quantity")
    @NotNull(message = "Quantity is required!")
    @Min(value = 5, message = "Quantity is in the range of 5...200")
    @Max(value = 200, message = "Quantity is in the range of 5...200")
    private int quantity;

    @Column(name = "Price", nullable = false)
    @NotNull(message = "Price is required!")
    @Min(value = 5, message = "Price is in the range of 5...10M")
    @Max(value = 10_000_000, message = "Price is in the range of 5...10M")
    private double price;

    //MỐI QUAN HỆ GIỮA PRODUCT >--- CATEGORY
    //TUI PRODUCT THUỘC VỀ CATE NÀO?
    @ManyToOne
    @JoinColumn(name = "CateId")  //cột FK ở table, góc nhìn DB
    private Category cate;        //góc nhìn OOP

    public Category getCate() {
        return cate;
    }

    public void setCate(Category cate) {
        this.cate = cate;
    }

    public Product() {
    }

    public Product(String id, String name, int quantity, double price) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                '}';
    }
}
