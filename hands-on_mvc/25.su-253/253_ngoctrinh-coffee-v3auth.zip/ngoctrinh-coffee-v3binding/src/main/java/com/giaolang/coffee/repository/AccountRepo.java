package com.giaolang.coffee.repository;

import com.giaolang.coffee.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepo extends JpaRepository<Account, Long> {

    //có sẵn các hàm CRUD cơ bản rồi
    public Account findByEmail(String email);
    //câu hỏi: có nên findByEmail và Password hay ko???
    //chỉ tìm theo email để ta có thể chửi đc 2 câu: sai email, sai password!!!
    //                                               sign-up       reset
}
