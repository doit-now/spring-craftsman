package com.giaolang.coffee.repository;

import com.giaolang.coffee.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepo extends JpaRepository<Category,Long> {

    //TA XÀI SPRING JPA/HIBERNATE, SẼ GIÚP TA TỰ GENERATE CÁC HÀM CRUD, SEARCH, CÓ WHERE MIỄN LÀ BẠN GÕ TÊN HÀM CRUD TABLE THEO ĐÚNG CHUẨN NÓ YÊU CẦU
    //TRONG TÊN HÀM PHẢI CÓ TÊN CỘT MÌNH MUỐN THAO TÁC, VÀ THÊM VÀI ĐỘNG TỪ VÀ TỪ AND OR...
    //TỰ CÓ CODE, TỰ CÓ CÂU JPQL (SELECT DẠNG OBJECT)
    //BÊN SERVICE CHỈ VIỆC KHAI BÁO BIẾN CategoryRepo là có hàm luôn!!!!
}
