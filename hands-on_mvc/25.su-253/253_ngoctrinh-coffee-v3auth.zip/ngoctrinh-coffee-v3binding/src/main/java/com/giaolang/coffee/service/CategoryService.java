package com.giaolang.coffee.service;

import com.giaolang.coffee.entity.Category;
import com.giaolang.coffee.repository.CategoryRepo;
import com.giaolang.coffee.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

//@Component
@Service //1 trong 2 okie, học rồi!!!
public class CategoryService {
    //GUI/CONTROLLER --- SERVICE --- REPO --- JPA/HIBERNATE --- JDBC DRIVER --- TABLE
    //CRUD TABLE CATE, NHƯNG NHỜ VẢ THẰNG REPO
    //REPO PHẢI ĐC NEW MỚI DÙNG ĐC, TA TIÊM CHÍCH VÀO, CÓ 3 CÁCH TIÊM: ...
    @Autowired
    private CategoryRepo categoryRepo;

//    @Autowired  chích qua constructor, ko cần autowire nếu chỉ có 1 constructor
//    public CategoryService(CategoryRepo categoryRepo) {
//        this.categoryRepo = categoryRepo;
//    }

    //LẤY HẾT CATES ĐỂ ĐỔ VÀO CHỖ TREO ĐẦU DÊ BÁN THỊT HEO - DROPDOWN
    public List<Category> getAllCates() {
        return categoryRepo.findAll();
    }  //hàm này ko thấy trong interface Repo, nhưng gõ đúng cú pháp find...
       //là có hàm

    //HÀM NÀY DÙNG ĐỂ TẠO MỚI CATE NHƯNG DÙNG TRONG TÌNH HUỐNG TẠO SẴN DATA CHO CATE TRONG TABLE THEO STYLE CODE FIRST
    //ĐỀ THI KO YÊU CẦU TẠO MÀN HÌNH THÊM XOÁ SỬA CATE!!!
    public void saveCategory(Category cat) {
        categoryRepo.save(cat);
    }
}
