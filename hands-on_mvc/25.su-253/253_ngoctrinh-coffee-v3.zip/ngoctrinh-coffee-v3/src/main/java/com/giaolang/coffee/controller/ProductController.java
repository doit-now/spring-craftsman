package com.giaolang.coffee.controller;

import com.giaolang.coffee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ProductController {

    @Autowired
    ProductService productService;

    //1 url load toàn bộ trang products
    //trang products đc gọi từ login, và đc gọi sau khi
    @GetMapping("/products")
    public String showProducts(Model model) {
        //lấy data từ table, thảy vào thùng đưa cho trang....
        //nhờ Service, tiêm vô
        model.addAttribute("products", productService.getAllProducts());

        return "products"; //.html
    }
}
