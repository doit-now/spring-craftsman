package com.giaolang.coffee.repository;

public interface AccountRepo {
}
