package com.giaolang.coffee.entity;

//1 Cate có nhiều Prod

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name ="Category")
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO) //tự tăng số key
    @Column(name = "Id")
    private Long id; //key tự tăng, phải là Long, học rồi

    @Column(name = "Name", nullable = false, columnDefinition = "NVARCHAR(50)")
    private String name;   //treo đầu dê bán thịt heo chỉ cần 2 cột id, name

    @Column(name = "Description", nullable = false, columnDefinition = "NVARCHAR(100)")
    private String description;

    //MỐI QUAN HỆ VỚI THẰNG PRODUCT, 1 CATE CÓ NHIỀU PRODUCT - LIST<>
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "cate")
    private List<Product> productList = new ArrayList<>();

    //LIST NÀY PHẢI ĐC ADD VÀO CÁC PRODUCT, TA CẦN HÀM ADD() REMOVE() HỌC RỒI
    public void addProduct(Product o){
        productList.add(o);
        o.setCate(this); //học rồi
    }

    public void removeProduct(Product o){
        productList.remove(o);
        o.setCate(null);
    }


    public Category() {
    }

    //bỏ id ra constructor vì là key tự tăng!!!
    public Category(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Category{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
