package com.giaolang.coffee.controller;

import com.giaolang.coffee.entity.Product;
import com.giaolang.coffee.service.CategoryService;
import com.giaolang.coffee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ProductController {

    @Autowired
    ProductService productService;

    @Autowired
    CategoryService categoryService;  //dùng để xổ ra treo đầu dê bán thịt heo... hàm getAllCates()

    //1 url load toàn bộ trang products
    //trang products đc gọi từ login, và đc gọi sau khi
    @GetMapping("/products")
    public String showProducts(Model model) {
        //lấy data từ table, thảy vào thùng đưa cho trang....
        //nhờ Service, tiêm vô
        //List<> products = productService.getAllProducts());
        model.addAttribute("products", productService.getAllProducts());

        return "products"; //.html
    }

    //hàm /edit
    @GetMapping("/products/edit/{id}")
    public String editProduct(@PathVariable("id") String id, Model model) {

        //có id đưa lên, nhờ Service lấy giùm đc 1 sp, where theo id
        Product result = productService.getProductById(id);

        //                       Product selectedOne = result;
        model.addAttribute("selectedOne", result);

        //ta gửi thêm cả list of categories để làm danh sách xổ xuống
        model.addAttribute("cates", categoryService.getAllCates());
        return "product-form"; //.html

    }
    //hàm /new
    @GetMapping("/products/new")
    public String createProduct(Model model) {

        model.addAttribute("selectedOne", new Product());

        //ta gửi thêm cả list of categories để làm danh sách xổ xuống
        model.addAttribute("cates", categoryService.getAllCates());

        return "product-form"; //.html

    }
    //hàm /save (save cho cả edit và tạo mới) POST ĐÓ EM
    @PostMapping("/products/save")
//    public String saveProduct(@RequestParam("id") String id, @RequestParam("name") String name, @RequestParam("quantity") int quant, @RequestParam("price") double giaTien) {

    public String saveProduct(@ModelAttribute("selectedOne") Product product) {

        productService.saveProduct(product);

        return "redirect:/products"; //gọi url mới, load lại ds
                                     //đề phòng resubmission, ta đổi url

    }
    //hàm /delete
    @GetMapping("/products/delete/{id}")
    public String deleteProduct(@PathVariable("id") String id, Model model) {

        productService.deleteProduct(id);

        return "redirect:/products";

    }
    //...
}
