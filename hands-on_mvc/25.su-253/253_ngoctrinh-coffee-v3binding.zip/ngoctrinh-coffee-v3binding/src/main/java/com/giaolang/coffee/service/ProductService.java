package com.giaolang.coffee.service;

import com.giaolang.coffee.entity.Product;
import com.giaolang.coffee.repository.CategoryRepo;
import com.giaolang.coffee.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    //CLASS CHÍNH, VÌ APP CẦN CREATE, UPDATE, DELETE, SEARCH, SHOW ALL PRODUCT, CLASS TRUNG TÂM CỦA APP!!!
    //ĐẰNG NÀO CX PHẢI NHỜ PRODUCT-REPO GIÚP, HÀM CÓ SẴN KO CẦN PHẢI GÕ...
    @Autowired
    private ProductRepo productRepo;

    //CÁC HÀM CRUD ĐỂ ĐC DÙNG BỞI
    //GUI/CONTROLLER --- SERVICE --- REPO --- JPA/HIBERNATE --- JDBC --- TABLE

    public List<Product> getAllProducts() {
        return productRepo.findAll(); //hàm tự sinh của repo
    }

    public Product getProductById(String id) {
        return productRepo.findById(id).get();
    }        //hàm tự sinh, tìm theo id

    public void saveProduct(Product product) {
        productRepo.save(product);
    }  //hàm tự sinh, dùng chung cho /create, /edit 1 sản phẩm
       //nếu key là có sẵn là update
       //nếu key là mới, thì create

    public void deleteProduct(Product product) {
        productRepo.delete(product);
    }   //hàm tự sinh

    public void deleteProduct(String id) {
        productRepo.deleteById(id); //hàm tự sinh luôn
    }



}
