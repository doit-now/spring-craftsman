package com.giaolang.coffee.config;

import com.giaolang.coffee.entity.Category;
import com.giaolang.coffee.entity.Product;
import com.giaolang.coffee.repository.CategoryRepo;
import com.giaolang.coffee.repository.ProductRepo;
import com.giaolang.coffee.service.CategoryService;
import com.giaolang.coffee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    //gọi service mà chèn xuống table, data mẫu đề thi sẽ cho, gõ ch đúng đủ
    @Autowired
    //private CategoryRepo categoryRepo;
    private CategoryService categoryService;

    @Autowired
    //private ProductRepo productRepo;
    private ProductService productService;

    @Override
    public void run(String... args) throws Exception {

        //tạo mới Cate, Product, đẩy chúng xuống DB
        Category cate1 = new Category("Trà sữa", "Uống trà sữa tạch môn HSF302");
        Category cate2 = new Category("Cà phê", "Cà phê Java mỗi ngày, lương vài K$");
        Category cate3 = new Category("Beer-tăng lực", "Bia trộn Java ra cái gì???");
        Category cate4 = new Category("Bánh kẹo", "Đời ngọt ngào như Ngọc Trinh");

        //chuẩn bị product, ăn theo cate, ĐỔ DOMINO CASCADE
        Product p1c1 = new Product("TS01", "Trà Sữa Bà Hàng Xóm Nấu", 100, 25_000);
        Product p2c1 = new Product("TS02", "Trà Sữa Chuẩn Vị Ngọc Trinh", 100, 30_000);

        Product p1c2 = new Product("CF01", "Cà Phê Java Nguyên Bản", 100, 5_700_000);

        Product p2c2 = new Product("CF02", "Cà Phê Java Đậm Đà Ngọc Trinh", 100, 5_700_000);

        Product p3c2 = new Product("CF03", "Cà Ngọc Trinh Phê Hem", 100, 2_350_000);

        //móc Cate với Prod
        cate1.addProduct(p1c1);
        cate1.addProduct(p2c1);
        cate2.addProduct(p1c2);
        cate2.addProduct(p2c2);
        cate2.addProduct(p3c2);


        categoryService.saveCategory(cate1);
        categoryService.saveCategory(cate2);
        categoryService.saveCategory(cate3);
        categoryService.saveCategory(cate4);

    }
}
