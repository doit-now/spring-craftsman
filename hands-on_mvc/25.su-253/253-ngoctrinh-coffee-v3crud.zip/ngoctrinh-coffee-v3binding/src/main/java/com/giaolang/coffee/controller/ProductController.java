package com.giaolang.coffee.controller;

import com.giaolang.coffee.entity.Product;
import com.giaolang.coffee.service.CategoryService;
import com.giaolang.coffee.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class ProductController {

    @Autowired
    ProductService productService;

    @Autowired
    CategoryService categoryService;  //dùng để xổ ra treo đầu dê bán thịt heo... hàm getAllCates()

    //1 url load toàn bộ trang products
    //trang products đc gọi từ login, và đc gọi sau khi
    @GetMapping("/products")
    public String showProducts(@RequestParam(name = "kw", required = false, defaultValue = "") String keyword, Model model) {
        //lấy data từ table, thảy vào thùng đưa cho trang....
        //nhờ Service, tiêm vô
        //List<> products = productService.getAllProducts());

        if (keyword.equals("")) { //ko gõ kw, show full, hoặc đi từ login sang
            model.addAttribute("products", productService.getAllProducts());
        }
        else {
            model.addAttribute("products", productService.searchProductsByName(keyword));
        }

        return "products"; //.html
    }

    //hàm /edit
    @GetMapping("/products/edit/{id}")
    public String editProduct(@PathVariable("id") String id, Model model) {

        //có id đưa lên, nhờ Service lấy giùm đc 1 sp, where theo id
        Product result = productService.getProductById(id);

        //                       Product selectedOne = result;
        model.addAttribute("selectedOne", result);

        //ta gửi thêm cả list of categories để làm danh sách xổ xuống
        model.addAttribute("cates", categoryService.getAllCates());

        //TA GỬI THÊM 1 BIẾN FLAG, PHẤT CỜ TUỲ NGỮ CẢNH
        //                     String formMode = "edit"; gửi xuống thymeleaf
        model.addAttribute("formMode", "edit");

        return "product-form"; //.html

    }
    //hàm /new
    @GetMapping("/products/new")
    public String createProduct(Model model) {

        model.addAttribute("selectedOne", new Product());

        //ta gửi thêm cả list of categories để làm danh sách xổ xuống
        model.addAttribute("cates", categoryService.getAllCates());

        //TA GỬI THÊM 1 BIẾN FLAG, PHẤT CỜ TUỲ NGỮ CẢNH
        //                     String formMode = "new"; gửi xuống thymeleaf
        model.addAttribute("formMode", "new");

        return "product-form"; //.html

    }
    //hàm /save (save cho cả edit và tạo mới) POST ĐÓ EM
    @PostMapping("/products/save")
//    public String saveProduct(@RequestParam("id") String id, @RequestParam("name") String name, @RequestParam("quantity") int quant, @RequestParam("price") double giaTien) {

    public String saveProduct(@Valid @ModelAttribute("selectedOne") Product product, BindingResult result, Model model, @RequestParam("formMode") String formMode) {
        //mỗi lần bấm nút Save, ô hidden gửi lên caí mode new/edit
        //@Valid phải đứng trước @ModelAtttribute, báo hiệu bật tính năng kiểm tra data từ dưới form đưa lên có khớp với khai báo trong @Entity hay ko
        //Nếu ko khớp, ghi nhận lại toàn bộ lỗi validation, cất vào 1 object tên là BindingResult
        //1 thằng chặn đầu, 1 thằng chặn đuôi phần check validation
        //BẮT BUỘC FORM PHẢI DÙNG CƠ CHẾ BINDING OBJECT THÌ MÓI XÀI ĐC VALIDATION

        if (result.hasErrors()) {  //nếu có lỗi nhập liệu, quay trở lại form nhập liệu, ko save gì cả
            //in thông báo lỗi lấy từ biến result, biến này tự đc đưa vào thùng chứa model luôn
            //và ưa obj bi lỗi trở ngược lại form, ko cần thùng cứa model, model có sẵn obj lỗi

            //gửi lại cates
            model.addAttribute("cates", categoryService.getAllCates());
            //model.addAttribute("formMode", "new");

            return "product-form";
        }

        //TODO VỀ NHÀ LÀM THÊM, CHECK BIẾN FORMMODE
        if (formMode.equals("new")) {
            //thêm code check xem id đã tồn tại chưa, tạo mới sản phẩm mà lại gõ id trùng, chửi chắc luôn!!!
            //viết thêm trong Repo, Service hàm ktra key tồn tại hay chưa!!!!!!
            boolean existence = productService.checkProductExistence(product.getId());
            if (existence) {
                //return cates nữa
                //in câu thông báo id trùng
                model.addAttribute("formMode", "new");
                model.addAttribute("cates", categoryService.getAllCates());
                return "product-form";
            }
            // //quay lại màn hình nhập
        }

        //ko trùng, hoặc edit thì đều phải save()!!!!!!!!!!

        productService.saveProduct(product);

        return "redirect:/products"; //gọi url mới, load lại ds
                                     //đề phòng resubmission, ta đổi url

    }
    //hàm /delete
    @GetMapping("/products/delete/{id}")
    public String deleteProduct(@PathVariable("id") String id, Model model) {

        productService.deleteProduct(id);

        return "redirect:/products";

    }
    //...
}
