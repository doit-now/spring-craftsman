package com.giaolang.coffee.service;

import org.springframework.data.jpa.repository.JpaRepository;

public class AccountService {

}
