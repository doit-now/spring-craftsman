package com.giaolang.dieudao.config;

//làm cho class này đc new tự động - mày phải là bean @
//và chạy tự động 1 lần duy nhất ngay khi Tomcat chạy xong
//ta cho nó kế thừa 1 class / interface có sẵn của Spring và viết hàm tự chạy
//hàm này sẽ insert data khởi đầu để app sẵn sàng - seeding data


import com.giaolang.dieudao.entity.Category;
import com.giaolang.dieudao.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    //TIÊM REPO, HOẶC SERVICE VÀO ĐÂY, DƯỚI HÀM run() GỌI XÀI!!!!
    //QUÊN GETBEAN() ĐI
    @Autowired
    private CategoryService cateService; //tự tiêm thằng Impl

    @Override
    public void run(String... args) throws Exception {
        //gọi Repo, hoặc Service ở đây để seeding data!!!!!!!!!!!!!
        //CODE FIRST ĐÓ EM: TOÀN LÀ OOP TRƯỚC TIÊN, KỂ CẢ LỆNH INSERT DATA
        //TOÀN LÀ CODE, LÁT HỒI CÓ TABLE, CÓ CẢ 1 - N, CÓ CẢ DATA, TOÀN TỪ CODE

        Category c1 = new Category(null, "Trái cây VietGAP 1/7", "Canh tác trên quy trình...");

        Category c2 = new Category(null, "Trái cây nhập khẩu 1/7", "Tem kiểm định nhập khẩu...");

        Category c3 = Category.builder()
                .name("Trái cây sấy khô 1/7")
                .description("Đảm bảo chất lượng như trái cây tươi")
                .build();
        cateService.createCategory(c1);
        cateService.createCategory(c2);
        cateService.createCategory(c3);


    }
}
