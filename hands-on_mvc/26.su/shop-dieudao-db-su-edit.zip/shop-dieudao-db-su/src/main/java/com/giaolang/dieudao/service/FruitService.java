package com.giaolang.dieudao.service;

import com.giaolang.dieudao.entity.Fruit;

import java.util.List;

public interface FruitService {

    //table trung tâm, nên đủ CRUD table Fruit

    public List<Fruit> getAllFruits();

    //C (Create)
    public void createFruit(Fruit obj);

    //thêm hàm R (Retrieve, Read) 1 trái cây, phục vụ cho View và Edit
    //lấy đúng 1 trái cây theo id - String
    public Fruit getFruitById(String id);

    //thêm hàm U (Update)
    public void updateFruit(String id, Fruit obj);

    //thêm hàm D (Delete)
    public void deleteFruitById(String id);
}