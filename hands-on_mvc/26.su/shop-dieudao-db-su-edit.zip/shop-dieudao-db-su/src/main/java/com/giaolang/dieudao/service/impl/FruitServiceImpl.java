package com.giaolang.dieudao.service.impl;

import com.giaolang.dieudao.entity.Fruit;
import com.giaolang.dieudao.repository.FruitRepository;
import com.giaolang.dieudao.service.FruitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FruitServiceImpl implements FruitService {

    //tiêm thằng FruitRepository, có đống hàm CRUD table Fruit
    @Autowired
    private FruitRepository fruitRepo;

    @Override
    public List<Fruit> getAllFruits() {
        return fruitRepo.findAll();
    }                   //hàm có sẵn tự sinh của thằng Repo

    @Override
    public void createFruit(Fruit obj) {
        fruitRepo.save(obj);  //key null tạo mới, key trùng update
    }

    @Override
    public Fruit getFruitById(String id) {
        //return fruitRepo.findById(id).orElse(null);
        return fruitRepo.findById(id).get();
    }  //Fruit có thể null nếu đưa id ko tồn tại

    @Override
    public void updateFruit(String id, Fruit obj) {
        //check id có tồn tại trong db chưa, update dòng đã tồn tại...

        fruitRepo.save(obj); //xài cùng hàm save() cho CREATE, UPDATE

    }

    @Override
    public void deleteFruitById(String id) {
        fruitRepo.deleteById(id);
    }
    //ngược lại thì trả về 1 trái cây đc new trong RAM
       //ta dùng hàm này để ném trái cây sang trang detail.html edit.html
}

