package com.giaolang.dieudao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopDieudaoDbApplicationTests {

    @Test
    void contextLoads() {
    }

}
