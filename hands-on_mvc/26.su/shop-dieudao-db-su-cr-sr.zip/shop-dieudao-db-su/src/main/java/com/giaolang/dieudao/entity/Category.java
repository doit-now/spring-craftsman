package com.giaolang.dieudao.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity  //mày sẽ ánh xạ - map xuống table
//@Table(name="category")  ko có dòng này, tên table mặc định là tên class, chữ thường
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //cách generate key tự tăng
    private Long id;

    @Column(unique = true, columnDefinition = "nvarchar(50)", nullable = false)
    private String name;

    @Column(columnDefinition = "nvarchar(200)", nullable = false)
    private String description;  //tuyệt đối ko đặt tên cột là desc, user, account ở SQLServer

    //1 Category có N nhiều ----------< Fruit trái cây
    //                List, ArrayList
    @OneToMany
    @JoinColumn(name = "cate_id") //cột FK khi xuống table Fruit, tên cột tuỳ ý
    private List<Fruit> fruits = new ArrayList<>();

    //lúc này, Category có các đặc tính: id | name | description | fruits
    //                                    1   TCVG    ....         null
}
