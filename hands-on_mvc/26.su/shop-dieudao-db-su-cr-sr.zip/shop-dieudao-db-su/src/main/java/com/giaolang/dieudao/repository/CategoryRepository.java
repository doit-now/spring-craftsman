package com.giaolang.dieudao.repository;

import com.giaolang.dieudao.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository //ko cần @ ở đây do inteface Cha đã là bean - hạt đậu tự Spring new giúp, DI giúp
public interface CategoryRepository extends JpaRepository<Category, Long> {

    //trong inteface này, kế thừa từ Cha JpaRepository đã có sẵn 1 loạt
    //các hàm CRUD table Category, ta chỉ việc khai báo biến
    //CategoryRepository cateRepo ở class khác và thoải mái chấm . để sờ hàm
    //CRUD CÓ SẴN, ví dụ .save()  .findAll()  .exist...()  .delete()
    //KO CẦN LÀM GÌ THÊM TRONG INTERFACE NÀY
    //NẾU CHỈ CÓ Ý ĐỊNH XÀI HÀM  CÓ SẴN

    //ngoài ra bạn CÓ THỂ ĐỘ THÊM CÁC HÀM MÀ KO CÓ SẴN
    // THÌ KHAI BÁO TÊN HÀM ĐỘ Ở ĐÂY, LUC BUILD APP VÀ RUN APP, SPRING TỰ
    //GENERATE HÀM GIÚP TA, NHƯNG MUỐN GENERATE GIÚP, TA PHẢI ĐẶT TÊN HÀM
    //THEO 1 QUY TẮC ĐỊNH TRƯỚC, XEM DOCUMENT CỦA SPRING DATA/JPA SẼ CÓ HƯỚNG
    //DẪN, HOẶC IDE SẼ GỢI Ý BẠN...

    //HÀM SEARCH THEO KEYWORD NÀO ĐÓ, THEO COLUMN NÀO ĐÓ, HÀM LOGIN BẰNG EMAIL
    //HÀM NÀY KO CÓ SẴN, NHƯNG KHÉO KHAI BÁO LÀ CÓ HÀM NÀY LUÔN!!!!
    //HÀM DẠNG NÀY GỌI LÀ HÀM DẪN XUẤT / PHÁT SINH TỪ CÂU QUERY -
    //DERIVED QUERY METHODS, QUERY METHODS!! -> KEYWORD NHỜ LLM CHAT
    //ví dụ: searchByNameOrAddressContainingIgnoreCase...()
}
