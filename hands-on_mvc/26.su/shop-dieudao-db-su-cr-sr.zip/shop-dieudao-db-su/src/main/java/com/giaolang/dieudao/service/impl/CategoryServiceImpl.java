package com.giaolang.dieudao.service.impl;

import com.giaolang.dieudao.entity.Category;
import com.giaolang.dieudao.repository.CategoryRepository;
import com.giaolang.dieudao.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {

    //mantra: gui - controller - service - repo - spring-data/jpa/hibernate - jdbc - table
    //tiêm thằng repo vào
    @Autowired  //DEPENDENCY INJECTION
    private CategoryRepository cateRepo;  //ko chơi new, ko chơi getBean()

    @Override
    public List<Category> getAllCategories() {
        return cateRepo.findAll();  //hàm tự sinh có sẵn select * from Category
    }

    @Override
    public void createCategory(Category obj) {
        cateRepo.save(obj);  //nếu obj.id là null, hoặc chưa tồn tại Long id;
    }                        //thì sẽ là SQL insert into Category values(...)
}
