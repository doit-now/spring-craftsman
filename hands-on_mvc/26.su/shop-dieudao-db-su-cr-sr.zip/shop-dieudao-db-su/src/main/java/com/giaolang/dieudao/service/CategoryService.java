package com.giaolang.dieudao.service;

import com.giaolang.dieudao.entity.Category;
import org.springframework.stereotype.Service;

import java.util.List;

//@Service
public interface CategoryService {

    //class này, interface này chứa hàm CRUD table Category, nhưng ko có code
    //THI PE KO CẦN LÀM ĐỦ CRUD VÌ:

    //THI PE TẬP TRUNG CRUD TABLE FRUIT, TABLE PHÍA N TRONG MỐI QUAN HỆ 1 -< N
    //                                         1 CATEGORY CÓ NHIỀU FRUIT - CRUD FRUIT

    //NHƯNG MÔN SWP391 THÌ CRUD ĐỦ CHO CATEGORY, ORDER, FRUIT, USER,...

    //Ở ĐÂY TA CHỈ LÀM 2 HÀM: getAllCates() dùng cho danh sách dropdown, xổ xuống khi
    //                          tạo mới trái cây, phải chọn trái cây thuộc về cate nào
    //                          y chang như tạo Student phải chọn tỉnh / thành nơi sinh

    //                        createCate(obj) dùng cho seeding!!!!!!!!!!!

    public List<Category> getAllCategories();  //Cates  - ko có code, chờ impl

    public void createCategory(Category obj);  //gọi hàm .save() của Repo
                                               //Repo phải đc tiêm vào bên impl

}
