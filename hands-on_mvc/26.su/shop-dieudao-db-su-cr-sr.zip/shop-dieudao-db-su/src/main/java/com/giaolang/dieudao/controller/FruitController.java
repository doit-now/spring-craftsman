package com.giaolang.dieudao.controller;

import com.giaolang.dieudao.entity.Fruit;
import com.giaolang.dieudao.service.CategoryService;
import com.giaolang.dieudao.service.FruitService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/dieudao/fruits")
public class FruitController {

    @Autowired
    private FruitService fruitService;

    //cần thêm CateService để gửi danh sách Category - treo đầu dê... cho bên detail, edit, create form để cho user lựa chọn category cho 1 trái cây!!!
    @Autowired
    private CategoryService cateService;


    @GetMapping("create")
    public String showCreateForm(Model box) {
        //gửi 1 trái cây trống default bên trong, xuống màn hình create
        //show trống trơn..., chờ set lại value (tạo mới từ tay ko)
        box.addAttribute("selectedOne", new Fruit());

        //gửi thêm list Cates để tạo danh sách lựa chọn Cates
        box.addAttribute("cates", cateService.getAllCategories());

        return "fruit/create";
    }

    @PostMapping("create")
    public String createFruit(@Valid @ModelAttribute("selectedOne") Fruit obj, BindingResult result, Model box, RedirectAttributes flashBox) {

        //nếu có lỗi thì trả lại trang edit để sửa, còn data đưa lên mlem thì ta save và về trang list
        if (result.hasErrors()) {
            //gửi thêm list Cates để tạo danh sách lựa chọn Cates
            box.addAttribute("cates", cateService.getAllCategories());
            return "fruit/create";
        }

        //phải gọi FruitService đi xuống table Fruit, xong quay trở lại trang list
        //xem trái cây đc cập nhật
        fruitService.createFruit(obj);

        //nếu save thành công thì gửi message thông báo về trang chính
        flashBox.addFlashAttribute("noti", "Create successfully");

        return "redirect:/dieudao/fruits";
    }



    @PostMapping("edit/{id}")
    public String editFruit(@PathVariable("id") String id,
                            @Valid @ModelAttribute("selectedOne") Fruit obj, BindingResult result, Model box, RedirectAttributes flashBox) {

        //nếu có lỗi thì trả lại trang edit để sửa, còn data đưa lên mlem thì ta save và về trang list
        if (result.hasErrors()) {
            //gửi thêm list Cates để tạo danh sách lựa chọn Cates
            box.addAttribute("cates", cateService.getAllCategories());
            return "fruit/edit";
        }

        //phải gọi FruitService đi xuống table Fruit, xong quay trở lại trang list
        //xem trái cây đc cập nhật
        fruitService.updateFruit(id, obj);
        flashBox.addFlashAttribute("noti", "Update successfully");

        return "redirect:/dieudao/fruits";
    }

    @GetMapping("edit/{id}")
    public String showEditForm(@PathVariable("id") String id, Model box) {
        box.addAttribute("selectedOne", fruitService.getFruitById(id));

        //gửi thêm list Cates để tạo danh sách lựa chọn Cates
        box.addAttribute("cates", cateService.getAllCategories());

        return "fruit/edit";
    }



    @GetMapping("delete/{id}") //cắt id ra khỏi cái url /dieudao/fruits/delete/  /SS  /DD CẮT RA BẰNG @PathVariable
    public String deleteFruitById(@PathVariable("id") String id, RedirectAttributes flashBox) {

        fruitService.deleteFruitById(id);

        //ship giỏ trái cây sang trang list
        //box.addAttribute("fruitBag", fruitService.getAllFruits());

        //gửi giỏ trái cây đã bị xoá 1 cháu, copy code ở dưới lên
        flashBox.addFlashAttribute("noti", "Delete successfully");

        return "redirect:/dieudao/fruits";
    }


    @GetMapping("{id}") //cắt id ra khỏi cái url /dieudao/fruits/MC  /SS  /DD CẮT RA BẰNG @PathVariable
    public String getFruit(@PathVariable("id") String id, Model box) {
        //có id của trái cây rồi, MC, SS, DD, CRY... ta where trả về 1 trái
        //đẩy trái này sang trang detail.html hoặc view.html
        box.addAttribute("selectedOne", fruitService.getFruitById(id));

        //gửi thêm list Cates để tạo danh sách lựa chọn Cates
        box.addAttribute("cates", cateService.getAllCategories());

        return "fruit/detail";  //tách thư mục trang web
    }


    //hàm trả về trang list.html nay đang nằm ở thư mục fruit/
    @GetMapping
    public String getAllFruits(@RequestParam(name = "kw", required = false, defaultValue = "") String keyword, Model box) {

        //ship giỏ trái cây sang trang list
        box.addAttribute("fruitBag",
                fruitService.searchFruit(keyword));
        box.addAttribute("yourKW", keyword);

        //String s1 = null; //chỉ tốn 1 vùng ram biến 8 byte
        //String s2 = "";  //chuỗi rỗng, tốn 2 vùng ram 8 byte, vùng new chuỗi

        return "fruit/list";  //fruit/list.html
    }
}
