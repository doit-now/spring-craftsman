package com.giaolang.dieudao.repository;

import com.giaolang.dieudao.entity.Fruit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FruitRepository extends JpaRepository<Fruit, String> {
    //CHÚ Ý CỘT KEY CỦA ENTITY CÓ DATA TYPE GÌ THÌ DÙNG ĐÚNG Ở ĐÂY

    //1 ĐỐNG HÀM CÓ SẴN ĐỦ CRUD: .save()  .delete()  .findAll()...

    //1 đống hàm độ đặt tên theo quy tắc viết tại đây tên hàm, lát hồi tự có code đc implement

    public List<Fruit> findAllByNameContainingIgnoreCaseOrDescriptionContainingIgnoreCase(String name, String description);

}
