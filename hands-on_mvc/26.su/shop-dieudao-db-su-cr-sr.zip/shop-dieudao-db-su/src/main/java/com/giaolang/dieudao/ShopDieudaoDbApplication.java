package com.giaolang.dieudao;

import com.giaolang.dieudao.entity.Category;
import com.giaolang.dieudao.repository.CategoryRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class ShopDieudaoDbApplication {

    public static void main(String[] args) {

        //đây là câu lệnh tạo container để chứa các bean, chứa các object
        //đc tự new bởi Spring, và sẽ đc tiêm @Autowire vào các bean khác

        //ta thí nghiệm ở đây là lấy cái object CategoryRepository đc new tự
        //động bởi Container, qua hàm getBean() đã học
        // ta chưa xài cách tiêm, chưa xài @Autowire vì chưa làm class để
        //nhận mũi tiêm. Đúng chuẩn: CategoryService đc tiêm CategoryRepository
        ApplicationContext ctx = SpringApplication.run(ShopDieudaoDbApplication.class, args);

        /*


        //cxt là container, và ta đi getBean() hoy
        //CategoryRepository cateRepo = (CategoryRepository) ctx.getBean("categoryRepository");
        CategoryRepository cateRepo = ctx.getBean(CategoryRepository.class);

        //chuẩn bị insert 3 dòng Category: Trái cây VietGAP, Trái cây nhập khẩu, Trái cây sấy khô

        Category c1 = new Category(null, "Trái cây VietGAP", "Canh tác trên quy trình...");

        Category c2 = new Category(null, "Trái cây nhập khẩu", "Tem kiểm định nhập khẩu...");

        Category c3 = Category.builder()
                        .name("Trái cây sấy khô")
                                .description("Đảm bảo chất lượng như trái cây tươi")
                                        .build();
        cateRepo.save(c1);
        cateRepo.save(c2);
        cateRepo.save(c3);
        //HÀM SAVE() CỦA REPO LÀ HÀM CÓ SẴN, TỰ SINH BỞI SPRING DATA (CON CỦA SPRING)
        //HÀM NÀY DỄ THƯƠNG VÌ:
        //NẾU TA ĐƯA 1 OBJECT / ENTITY TƯƠNG ỨNG MÀ
        //OBJECT NÀY CÓ CỘT KEY BẰNG NULL, HOẶC CỘT KEY VALUE CHƯA TỒN TẠI, SAVE LÀ INSERT
        //OBJECT NÀY CÓ CỘT KEY ĐÃ TỒN TẠI TRONG TABLE                    , SAVE LÀ UPDATE

        */
    }

}
