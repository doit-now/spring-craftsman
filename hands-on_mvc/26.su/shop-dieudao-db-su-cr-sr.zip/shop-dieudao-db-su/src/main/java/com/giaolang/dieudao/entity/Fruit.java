package com.giaolang.dieudao.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Fruit {

    @Id
    @NotBlank(message = "KEY không được bỏ trống, ko chứa toàn dấu cách, cấm trùng!!!")
    private String id;  //id ko tự tăng

    @Column(columnDefinition = "nvarchar(50)", unique = true, nullable = false)
    @NotBlank(message = "Tên không được bỏ trống, ko chứa toàn dấu cách")
    @Size(min = 2, max = 50, message = "Name must be 2..50 characters length")
    private String name;

    @Column(columnDefinition = "nvarchar(200)", nullable = false)
    @NotBlank(message = "Desc không được bỏ trống, ko chứa toàn dấu cách")
    @Size(min = 10, max = 200, message = "Desc must be 10..200 characters length")
    private String description;

    //min max học sau
    @Min(value = 1, message = "Price must be in 1...20")
    @Max(value = 20, message = "Price must be in 10...20")
    private double price;

    //N trái cây thuộc về cùng 1 Category, mối quan hệ N --- 1
    //OOP chỉ quan tâm object
    @ManyToOne
    @JoinColumn(name = "cate_id") //cột FK khi xuống table Fruit, tên cột tuỳ ý
    private Category cate;  //.getName() chính là join table!!!
}
