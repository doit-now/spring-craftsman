package com.giaolang.dieudao.controller;

import com.giaolang.dieudao.service.FruitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/dieudao/fruits")
public class FruitController {

    @Autowired
    private FruitService fruitService;

    @GetMapping("delete/{id}") //cắt id ra khỏi cái url /dieudao/fruits/delete/  /SS  /DD CẮT RA BẰNG @PathVariable
    public String deleteFruitById(@PathVariable("id") String id, Model box) {

        fruitService.deleteFruitById(id);

        //ship giỏ trái cây sang trang list
        box.addAttribute("fruitBag", fruitService.getAllFruits());

        //gửi giỏ trái cây đã bị xoá 1 cháu, copy code ở dưới lên

        return "fruit/list";
    }


    @GetMapping("{id}") //cắt id ra khỏi cái url /dieudao/fruits/MC  /SS  /DD CẮT RA BẰNG @PathVariable
    public String getFruit(@PathVariable("id") String id, Model box) {
        //có id của trái cây rồi, MC, SS, DD, CRY... ta where trả về 1 trái
        //đẩy trái này sang trang detail.html hoặc view.html
        box.addAttribute("selectedOne", fruitService.getFruitById(id));

        return "fruit/detail";  //tách thư mục trang web
    }


    //hàm trả về trang list.html nay đang nằm ở thư mục fruit/
    @GetMapping
    public String getAllFruits(Model box) {

        //ship giỏ trái cây sang trang list
        box.addAttribute("fruitBag", fruitService.getAllFruits());

        return "fruit/list";  //fruit/list.html
    }
}
