package com.giaolang.dieudao.service;

import com.giaolang.dieudao.entity.Category;

import java.util.List;

public interface CategoryService {

    //CHỨA HÀM CRUD KO CODE, CHỜ THẰNG IMPL NÓ LO GIÚP
    //BÊN THẰNG IMPL NÓ SẼ PHẢI TIÊM THẰNG REPO VÀO
    //MANTRA: UI - CONTROLLER - SERVICE (IMPL) - REPO - SPRING JPA/HIBERNATE - JDBC - TABLE

    //BÀI THI PE THÌ KO CẦN LÀM CRUD CỦA CATEGORY VÌ TABLE CHÍNH LÀ TABLE FRUIT

    //FRUIT THÌ ĐỦ CRUD
    //CATEGORY CHỈ CẦN LÀM SELECT * FROM CATEGORY
    //ĐỂ FILL VÀO DANH SÁCH XỔ CATE CỦA MÀN HÌNH TẠO MỚI, EDIT TRÁI CÂY
    //GIỐNG NHƯ DANH SÁCH XỔ TỈNH THÀNH CỦA PERSON, PERSON THUỘC TỈNH NÀO
    //                                              TRÁI CÂY THUỘC CATEGORY NÀO

    //CHỈ LÀM HÀM GETALLCATES()
    public List<Category> getAllCates();
}
