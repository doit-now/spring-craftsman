package com.giaolang.dieudao;

import com.giaolang.dieudao.entity.Category;
import com.giaolang.dieudao.repository.CategoryRepository;
import com.giaolang.dieudao.service.CategoryService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.util.List;

@SpringBootApplication
public class ShopDieudaoDbApplication {

    public static void main(String[] args) {

        ApplicationContext ctx = SpringApplication.run(ShopDieudaoDbApplication.class, args);

        CategoryRepository repo = ctx.getBean("categoryRepository", CategoryRepository.class);

        //kiểm tra hàm coi có crud hem?
        //new Category và insert table
        //Category c1 = new Category(...); //truyền thống
        Category c1 = Category.builder()
                        .name("TRÁI CÂY VIETGAP")
                        .desc("SẢN XUẤT TRÊN QUY TRÌNH SẠCH...")
                        .build();
        Category c2 = Category.builder()
                .name("TRÁI CÂY NHẬP KHẨU")
                .desc("GIẤY CHỨNG NHẬN NHẬP KHẨU CHẤT LƯỢNG...")
                .build();

        repo.save(c1);
        repo.save(c2);

        //LẤY DATA ĐÃ INSERT VÀ IN RA HOY
        CategoryService cateService = ctx.getBean(CategoryService.class);
        List<Category> cates = cateService.getAllCates();
        System.out.println("The list of cates");
        for (Category x : cates) {
            System.out.println(x);
        }

    }

}
