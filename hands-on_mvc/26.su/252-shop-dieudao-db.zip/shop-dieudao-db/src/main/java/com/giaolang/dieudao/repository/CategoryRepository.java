package com.giaolang.dieudao.repository;

import com.giaolang.dieudao.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {

    //khai báo thêm các hàm chưa có trong Spring here, Spring tự viết code cho bạn
    //khai báo phải đúng cú pháp, học sau!!!!!!!!!!!!

    //hoặc dùng CRUD CÓ SẴN ĐÃ ĐỦ NHU CẦU CƠ BẢN
}

//INTERFACE NÀY CHỨA 1 ĐỐNG HÀM KO CÓ CODE NHƯNG GIÚP LÀM CRUD TABLE CATEGORY
//LÚC RUNTIME, SPRING JPA SẼ TỰ NEW GIÚP MÌNH 1 CLASS NGẦM IMPLEMENTS HẾT CÁC HÀM CRUD KO CODE, MÌNH CHỈ VIỆC XÀI THÔI
//ĐÃ HƠN, NÓ SẼ GENERATE THÊM CHO MÌNH CÁC HÀM NÓ CHƯA CÓ, MIỄN MÌNH KHAI BÁO THÊM CÁC HÀM Ở ĐÂY THEO ĐÚNG CÚ PHÁP QUY ƯỚC - NÓI SAU, AND OR THOẢI MÁI, TÌM KIẾM THEO LIKE, KO QUAN TÂM HOA THƯỜNG, AND OR, OKIE HẾT LUÔN, HỌC SAU!!!!!!!!!!!!
