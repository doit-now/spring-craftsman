package com.giaolang.dieudao.service.impl;

import com.giaolang.dieudao.entity.Category;
import com.giaolang.dieudao.repository.CategoryRepository;
import com.giaolang.dieudao.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {

    //tiêm thằng repo nhờ giúp
    @Autowired
    private CategoryRepository cateRepo;

    @Override
    public List<Category> getAllCates() {
        return cateRepo.findAll();
    }
}
