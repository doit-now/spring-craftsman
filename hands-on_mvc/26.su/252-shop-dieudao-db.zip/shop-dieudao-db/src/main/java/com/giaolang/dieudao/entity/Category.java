package com.giaolang.dieudao.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
//@Table(name = "tên-table-muốn-độ-khác-tên-mặc-định"
//mặc định lấy tên class làm tên table
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; //18 con số 0, key nhiều hơn dùng UUID - hexa dài

    //@Column(name = "ngoctrinh", unique = true, length = 50, nullable = false)
        //| ngoctrinh | varchar(5) unique not null
    @Column(columnDefinition = "nvarchar(50)", unique = true, nullable = false)
    private String name;

    @Column(name = "description", columnDefinition = "nvarchar(200)", nullable = false)
    private String desc;  //desc vẫn đc nhưng xuống DB phải là tên cột khác, TOANG vì cột desc đụng keyword asc, desc SORT TĂNG GIẢM
    //mặc định String biến thành varchar(255), PHẢI ĐỘ SANG NVARCHAR(?)

}
