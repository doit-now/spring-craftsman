package com.giaolang.dieudao.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Fruit {

    @Id
    private String id;  //id ko tự tăng

    @Column(columnDefinition = "nvarchar(50)", unique = true, nullable = false)
    private String name;

    @Column(columnDefinition = "nvarchar(200)", nullable = false)
    private String description;

    //min max học sau
    private double price;

    //N trái cây thuộc về cùng 1 Category, mối quan hệ N --- 1
    //OOP chỉ quan tâm object
    @ManyToOne
    @JoinColumn(name = "cate_id") //cột FK khi xuống table Fruit, tên cột tuỳ ý
    private Category cate;  //.getName() chính là join table!!!
}
