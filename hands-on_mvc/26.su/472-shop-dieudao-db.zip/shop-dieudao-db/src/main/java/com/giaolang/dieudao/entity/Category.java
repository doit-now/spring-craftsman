package com.giaolang.dieudao.entity;

import jakarta.persistence.*;

@Entity  //mày sẽ ánh xạ - map xuống table
//@Table(name="category")  ko có dòng này, tên table mặc định là tên class, chữ thường
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //cách generate key tự tăng
    private Long id;

    @Column(unique = true, columnDefinition = "nvarchar(50)", nullable = false)
    private String name;

    @Column(columnDefinition = "nvarchar(200)", nullable = false)
    private String description;  //tuyệt đối ko đặt tên cột là desc, user, account ở SQLServer
}
