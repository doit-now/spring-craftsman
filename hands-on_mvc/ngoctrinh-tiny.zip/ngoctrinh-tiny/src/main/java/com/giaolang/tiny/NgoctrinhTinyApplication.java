package com.giaolang.tiny;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgoctrinhTinyApplication {

    public static void main(String[] args) {
        SpringApplication.run(NgoctrinhTinyApplication.class, args);
    }

}
