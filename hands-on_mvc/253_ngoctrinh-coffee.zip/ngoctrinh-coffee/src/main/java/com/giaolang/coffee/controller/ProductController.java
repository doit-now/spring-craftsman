package com.giaolang.coffee.controller;

import com.giaolang.coffee.entity.Product;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

//phụ trách những url có dính đến product!!! No là bean @Controller
@Controller
//@RequestMapping()  khi nhiều url cùng có đoạn đầu url giống nhau
//                  nhân tử chung url để ở đây ví dụ a*b + a*c = a*(b + c)
//products
//products/1
//products/add
//products/view
//nhân tử chung là products @RequestMapping("/products")
public class ProductController {
    //controller sau khi nhận url sẽ xử lí gì đó, và phải trả về: trang, json

    @GetMapping("/products/new")
    public String create(Model model) {

        //câu lệnh cực kì quan trọng!!!!!!!!!!!!!!!!!!!!!!
        model.addAttribute("selectedId", 0);
        model.addAttribute("selectedProduct", new Product());

        return "product-form";
    }


    @GetMapping("/products/edit/{id}") //url có thể thay đổi, giống nhau đoạn đầu!!!
    public String edit(@PathVariable("id") String id, Model model) {

        model.addAttribute("selectedId", id);
        //đúng chuẩn: select trong database row có id này, mình hardcoded

        Product product;

        if (id.equalsIgnoreCase("NTCF1")) {
            product = new Product("NTCF1", "Cafe' Java đậm vị", 30_000);
        }
        else if (id.equalsIgnoreCase("NTCF2")) {
            product = new Product("NTCF2", "Cafe' Ngọc Trinh", 40_000);
        }
        else
            product = new Product("NTCF3", "Cafe' Java mix Ngọc Trinh", 50_000);

        model.addAttribute("selectedProduct", product);

        //gửi kèm 1 thùng, trong đó chứa id vừa click từ products table
        return "product-form";  //có cần redirect hay ko?
    }


    @GetMapping("/products")  //localhost:6969/products; hàm này đc gọi
    //hàm trả về trang products.html show ra toàn bộ các sản phẩm
    public String list(Model model) {

        //model.addAttribute("tham chiếu, tên món đồ", món đồ muốn gửi cho view html)
        //                       KEY                     VALUE
        //          thò tay vào thùng đồ tên là model, tìm món có tên KEY
        //                      đưa chìa khoá           lấy đc món đồ
        //                     hộc tủ số mấy               balo gì
        //TODO: LẤY DATA PRODUCT TỪ TABLE PRODUCT
        //MOCK DATA
//        List<Product> productList = new ArrayList<>();
//
//        productList.add(new Product("NTCF1", "Cafe' Java đậm vị", 30_000));
//        productList.add(new Product("NTCF2", "Cafe' Ngọc Trinh", 40_000));
//        productList.add(new Product("NTCF3", "Cafe' Java mix Ngọc Trinh", 50_000));

       List<Product> productList = List.of(
               new Product("NTCF1", "Cafe' Java đậm vị", 30_000),
               new Product("NTCF2", "Cafe' Ngọc Trinh", 40_000),
               new Product("NTCF3", "Cafe' Java mix Ngọc Trinh", 50_000));

        //gửi vào thùng để đi cùng view đến thằng Thymeleaf Engine để trộn, render trang web
        model.addAttribute("products", productList);
        model.addAttribute("msg", "CHÀO EM NGỌC TRINH");

        //                              CHÌA KHOÁ
        //                              SỐ HỘC TỦ     MÓN ĐỒ, LIST SẢN PHẨM
        return "products";  //tự thymeleaf sẽ ghép thêm .html
    }



}
