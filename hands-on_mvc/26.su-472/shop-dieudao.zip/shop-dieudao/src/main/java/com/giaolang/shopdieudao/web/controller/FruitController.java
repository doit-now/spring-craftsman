package com.giaolang.shopdieudao.web.controller;

import com.giaolang.shopdieudao.web.entity.Fruit;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Controller  //tự đc new nếu ai đó gọi url tương ứng
@RequestMapping("/dieudao/fruits")  //http:localhost:6969/dieudao/fruits
public class FruitController {

    @PostMapping("/edit") //localhost:6969/dieudao/fruits/edit
    //có 2 kĩ thuật lấy data từ ô nhập từ Browser gửi lên
    //kĩ thuật lấy nguyên object, kĩ thuật lấy từng field lẻ

    public String editFruit(@RequestParam("ngoctrinh") String name,
                            @RequestParam("desc") String desc,
                            @RequestParam("price") String price,
                            @RequestParam("id") String id, Model box) {
        //lôi toàn bộ data form của trình duyệt lên hàm này rồi, fill vào các biến Java
        //Service gọi Repo gọi...

        //debug, in log
        System.out.println("Edited Fruit: " + name + " " + desc + " " + price + " " + id);

        //gửi hộp nguyên trái cây
        Fruit f = new Fruit();
        box.addAttribute("fName", name);

        return "result"; //.html

    }

    @GetMapping("/edit/{id}")
    //hàm này đc gọi cho các url sau: localhost:6969/dieudao/fruits/edit/mc
    //hàm này đc gọi cho các url sau: localhost:6969/dieudao/fruits/edit/ss
    //hàm này đc gọi cho các url sau: localhost:6969/dieudao/fruits/edit/ngoctrinh
    public String editFruit(@PathVariable String id, Model box) {

        //ta có đc id từ url rồi, id = mc, hoặc ss, hoặc dd, hoặc đđ qua biến String id
        //lúc này gọi Service - Repo - JPA/Hibernate... để where để lấy 1 trái tương
        //ứng cần edit hoặc view

        //ta giả bộ trả về 1 trái cây hard-coded nào đó, vì chưa làm DB
        Fruit f = new Fruit(id, "TÊN TRÁI CÂY SẼ LẤY TỪ DB", "MÔ TẢ TRÁI CÂY LẤY TỪ DB...", new Random().nextDouble(100));  //dùng Builder cx okie
        //giả bộ random giá tiền cho cảm giác trái cây khác nhau tiền khác nhau

        //gửi 1 trái sang trang detail
        box.addAttribute("aFruit", f);

        return "fruit-form"; //mở trang detail
    }

    //các hàm CRUD Fruit table - tên table quy ước số ít, tên class cx số ít
    @GetMapping()  //vì hàm này ko nói url nên mặc định sẽ lấy url của class
                    //ở trên, ỏ các @RequestMapping
    public String getFruits(Model box) {
        //hộp chứa key-value ship cùng trang web

        //chuẩn bị sẵn 1 trái cây và ship sang trang web fruits.html
        //Tomcat nhận trang, chưa trả về trình duyệt ngay, nó bung box hộp
        //lấy data trong hộp fill vào các chỗ trong trang web -> render thành html thuần để trả về cho nơi gõ url - trình duyệt
        //box.addAttribute(key, value);
        //                 biến, value;  và bên trang web html
        //                               sờ biến qua ${tên-biến. nếu là obj}
        //new trái cây và ship trong hộp
        //TODO: chỗ này thực sự là của database: Service gọi Repo gọi JPA...
        Fruit cau = Fruit.builder()
                .id("MC")           //new Fruit();
                .name("MÃNG CẦU")
                .desc("MÃNG CẦU LÀ...")
                .price(5.0)
                .build();

        //box.addAttribute("cau", cau);
        box.addAttribute("objX", cau);
        //                            biến = value = con trỏ trỏ đến Fruit

        //thêm list trái cây - 3 trái
        List<Fruit> list = new ArrayList<>();
        list.add(cau);
        list.add(new Fruit("SS", "SUNG SƯỚNG", "SUNG LÀ TRÁI...", 6.0));
        list.add(new Fruit("DD", "DỪA DỪA", "DỪA DỪA CX CX LÀ TRÁI...", 7.0));

        //ship luôn theo hộp
        box.addAttribute("listXXX", list);

        return "fruits"; //hàm này ném về trình duyệt trang
                         //fruits.html - công nghệ SSR - server side rendering như JSP
    }
}
