package com.giaolang.shopdieudao.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller //tui trả trang web nhen
@RequestMapping({"/", "/index", "/ngoctrinh"})
//gõ 1 trong 3 url sau: http://localhost:6969/
//                      http://localhost:6969/index
//                      http://localhost:6969/ngoctrinh
//đều đến class này, trả về trang index.html
public class HomeController {

    @GetMapping
    public String home(Model box) {

        //Tomcat khi nhận đc url /  /ngoctrinh thì nó đi tìm hàm tương ứng
        //và gặp hàm home(), nếu có tham số Model box nghĩa là nó chuẩn sẵn 1 cái hộp trống sẽ đựng key-value
        //bạn dev dùng hộp này, đưa value vào, cất đồ vào hộp, sau khi cất xong,
        //gửi hộp này cho trang index
        box.addAttribute("xxx", "Hoàng Ngọc Trinh");
        //                           biến gửi sang index.html  có value HNT

        return "index";  //tự Tomcat ghép thêm .html phía sau
    }                    //index.html, và gửi thêm hộp box có data bên trong
                         //bên trang index sẽ mở hộp lấy data và ghép vào trang
                         //Tomcat trả trang đã ghép data
    //HÀM TRẢ VỀ TÊN TRANG .HTML
}
