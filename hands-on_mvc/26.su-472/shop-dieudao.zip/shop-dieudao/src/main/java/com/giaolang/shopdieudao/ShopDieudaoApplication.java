package com.giaolang.shopdieudao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopDieudaoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShopDieudaoApplication.class, args);
    }

}
