package com.giaolang.shopdieudao.web.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Fruit {

    private String id;
    private String name;
    private String desc;
    private double price;
}
