package com.giaolang.shopdieudao.api.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

//@Controller  trả về trang web <html> hoàn chỉnh nội dung trang
//             SSR - Server Side Rendering
//         user ---> browser ---> bấm/nhấn cái gì đó ---> controller trả về trang
//                                                   URL LÊN TOMCAT -> CONTROLLER

@RestController("myAPI") //trả về JSON - data thô
//         user ---> browser ---> bấm/nhấn cái app React, Axios/Fetch ---> controller trả về JSON
//                                                         URL LÊN TOMCAT -> CONTROLLER
@RequestMapping("/api/v6") //base url
//                  gõ đúng url này từ trình duyệt, từ POSTMAN, SWAGGER-UI
//                  THÌ CHẠM ĐC ĐẾN CLASS NÀY NHƯNG CHƯA CHẠM HÀM!!! CHẠM HÀM NÀO THÌ
//                  / PATH NÀO ĐÓ
public class FruitController {

    @GetMapping("/wc")
    public String helloWC() {
        return "Xin chào FIFA WORLD CUP 2026!!!";
    }

    @GetMapping("/fruits")
    public List<Fruit> getFruits() {
        List<Fruit> fruits = new ArrayList<>();
        fruits.add(new Fruit("MC", "MÃNG CẦU", "MÃNG CẦU LÀ...", 5.0));
        fruits.add(new Fruit("SS", "SUNG SƯỚNG", "SUNG SƯỚNG LÀ...", 6.0));
        fruits.add(new Fruit("DD", "DỪA DỪA", "DỪA DỪA CX CX LÀ...", 7.0));
        fruits.add(new Fruit("ĐĐ", "ĐU ĐỦ", "ĐU ĐỦ LÀ...", 8.0));
        fruits.add(new Fruit("XO", "XOÀI", "XOÀI LÀ...", 9.0));

        //Fruit xoai = new Fruit("XO", "XOÀI", "XOÀI LÀ...", 9.0);

        return fruits;
    }

}

//ta làm nhanh 1 class Fruit readonly - immutable: new rồi nhưng ko có hàm set()
//mà hàm get() ko có chữ get, mà chấm trực tiếp tên field => keyword 'record
record Fruit(String id, String name, String desc, double price) {}
//public class Fruit { private String id; .... }