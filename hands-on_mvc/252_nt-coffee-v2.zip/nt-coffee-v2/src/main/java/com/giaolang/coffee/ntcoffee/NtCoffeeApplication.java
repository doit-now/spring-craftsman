package com.giaolang.coffee.ntcoffee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NtCoffeeApplication {

    public static void main(String[] args) {
        SpringApplication.run(NtCoffeeApplication.class, args);
    }

}
