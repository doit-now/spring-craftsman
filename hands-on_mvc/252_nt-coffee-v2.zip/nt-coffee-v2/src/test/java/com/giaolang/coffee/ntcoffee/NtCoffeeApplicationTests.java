package com.giaolang.coffee.ntcoffee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NtCoffeeApplicationTests {

    @Test
    void contextLoads() {
    }

}
