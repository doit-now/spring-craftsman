package com.giaolang.ntcoffee.controller.web;

import com.giaolang.ntcoffee.entity.Account;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    @GetMapping({"/ngan98", "/login", "binh"})
    public String login(){
        return "login";
    }  //ko cân thùng Model box đi kèm, vì chỉ hiện thị login form

    @PostMapping("/auth")
    public String auth(@RequestParam("email") String email, @RequestParam("password") String pass, RedirectAttributes flashBox, HttpSession session) {
        //xài Session học sau
        //return "products";  //login thành công, show sản phẩm
        //trang rỗng vì hàm này ko thùng đồ
        //select * from Account where email = email-ở-trên and password = pass-ở trên tham số
        //if ko dòng nào trả về, thông báo invalid!!!
        //if có dòng trả về thì chuyển màn hình products, và lưu lại role!!!!!!!
        //bên trang products - liệt kê sản phẩm, ta sẽ disable link Edit, Delete nếu role ! Admin
        Account loggedAccount = null;
        if (email.equalsIgnoreCase("ad@gmail.com") && pass.equals("ad")){
            loggedAccount = new Account(1, email, pass, "Administrator nhen", 1);
        }
        if (email.equalsIgnoreCase("st@gmail.com") && pass.equals("st")){
            loggedAccount = new Account(2, email, pass, "Staff nhen", 2);
        }
        if (email.equalsIgnoreCase("mb@gmail.com") && pass.equals("mb")){
            loggedAccount = new Account(3, email, pass, "Member nhen", 3);
        }

        if (loggedAccount != null){
            //login thành công, gửi luôn loggedAccount sang bên products
            //nếu xài FlashAttribute, khi F5 bên products mất luôn info login, mất luôn loggedAccount
            //flashBox.addFlashAttribute("xAcc", loggedAccount);

            //ta xài session là cái hộp cất trữ lâu dài, chấp F5, chấp redirect
            session.setAttribute("xAcc", loggedAccount);

            //nên gọi url chuẩn thì có thùng products luôn
            return "redirect:/products";  //url đổi theo, vì bắt trình duyệt gọi url mói
        }
        //sai 1 trong 2 email hoặc pass, vòng về Login làm lại đi
        //gửi câu chửi ngược trở lại màn hình login

        flashBox.addFlashAttribute("errorMsg", "Sai thông tin login rồi bạn!");
        return "redirect:/login";


    }

}
