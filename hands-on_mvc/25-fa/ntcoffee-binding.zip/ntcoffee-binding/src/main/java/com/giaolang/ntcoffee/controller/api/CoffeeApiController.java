package com.giaolang.ntcoffee.controller.api;

import com.giaolang.ntcoffee.entity.Product;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

//1 class sẽ liên quan đến 2 câu chuyện:
//1.1. Ai new nó, new ở đâu?
//1.2 Ai gọi class này, gọi ở đâu?

//1.1: IoC Container, Spring sẽ new giúp
//phải có @Controller, @Service, @Repositor, @Bean
//        @RestController

//1.2: khi có 1 http request đến con Tomcat của app này
//     đến từ trình duyệt, đến từ swagger ui, đến từ postman, đến từ terminal, đến từ 1 app khác...
//CẦN CÓ 1 URL ĐỂ TRỎ ĐẾN CLASS NÀY

@RestController   //đặc chế cho web API
@RequestMapping("/api/v1/coffees")  //url để chạm class này
public class CoffeeApiController {

    @GetMapping("/hello")   //chạm class phải gõ api/v1/coffees
     //chạm hàm này phải gõ thêm api/v1/coffees/hello
    public String sayHello() {
        return "Hello Web API. This message comes from 1st API of my life!!!";
    }

    @GetMapping()   //chạm class phải gõ api/v1/coffees
    //chạm hàm này phải gõ thêm api/v1/coffees/acup
    public List<Product> getProducts() {

        List<Product> bag = new ArrayList<>();
        bag.add(new Product(1, "Coffee Ngọc Trinh", "Say Cafe như say Ngọc Trinh", 40_000));
        bag.add(new Product(2, "Coffee Highland", "Cà phê cao nguyên", 45_000));

        return bag;
    }

    @GetMapping("/acup")   //chạm class phải gõ api/v1/coffees
    //chạm hàm này phải gõ thêm api/v1/coffees/acup
    public Product getProduct() {
        return new Product(1, "Coffee Ngọc Trinh", "Say Cafe như say Ngọc Trinh", 40_000);
    }


}
