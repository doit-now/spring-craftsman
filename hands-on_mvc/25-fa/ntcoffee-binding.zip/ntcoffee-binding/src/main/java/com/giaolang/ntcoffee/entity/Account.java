package com.giaolang.ntcoffee.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Account {
    private int id;
    private String email;
    private String password;
    private String fullName;

    private int role;  //1: Admin, 2: Staff, 3: Member
}
