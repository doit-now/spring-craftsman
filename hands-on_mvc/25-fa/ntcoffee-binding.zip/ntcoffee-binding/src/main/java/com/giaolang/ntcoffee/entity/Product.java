package com.giaolang.ntcoffee.entity;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//@Entity
//luôn cần constructor rỗng, full tham số (loại trừ cột key tự tăng)
//nếu dùng lombok thì nhớ tuỳ loại key mà generate contructor cho đúng
@NoArgsConstructor
@AllArgsConstructor  //chỉ dùng neu ko có key tự tăng
@Data  //get, set, toString
public class Product {
    private long id;
    private String name;
    private String description;  //tên cột nguy hiểm đụng từ khoá SQL Server: desc, account, user
    private double price;

}
