package com.giaolang.ntcoffee.controller.web;

import com.giaolang.ntcoffee.entity.Account;
import com.giaolang.ntcoffee.entity.Product;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.List;

@Controller //phy5c vụ các url dính dáng đến entity Product
//url: http://localhost:6969/     /index   /ngoctrinh -> gọi trang index.html
//url: http://localhost:6969/products   -> trang products.html show danh sách sp
//url: http://localhost:6969/products/edit/101   -> trang product-form.html show detail có edit
//url: http://localhost:6969/products/delete/201   -> xoá, f5 lại cái trang products.html
//url: http://localhost:6969/products/delete/301   -> xoá, f5 lại cái trang products.html
//url: http://localhost:6969/products/create   -> trang product-form.html show detail có create/save
@RequestMapping("products")  //base url
public class CoffeeController {

    @GetMapping   //sẽ lấy base url map với hàm này
    public String listAllProducts(Model cage) {

        List<Product> bag = new ArrayList<>();
        bag.add(new Product(101, "Coffee Ngọc Trinh", "Say Cafe như say Ngọc Trinh", 40_000));
        bag.add(new Product(201, "Coffee Highland", "Cà phê cao nguyên", 45_000));
        bag.add(new Product(301, "Coffee Passio", "Cà phê xứ Xavalo", 35_000));

        //đưa vào thùng để pass sang trang products để render trong table 3 dòng tr tr tr
        cage.addAttribute("productList", bag);

        return "products";  //trả về trang products.html
    }

    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable("id") int delId, Model cage) {

        //TODO: xoá trong DB, dùng Service | Repo | JPA/Hibernate | JDBC | Table
        cage.addAttribute("deletedId", delId); //gửi ngược lại id đã xoá cho trang product, đúng chuẩn là read lại F5 lại trang products từ DB

        return "products";  //xoá xong vân trả products. Phải hụt 1 dòng, làm DB sẽ thấy
    }

    @GetMapping("/edit/{id}")
    public String editProduct(@PathVariable("id") int edtId, Model cage, HttpSession session, RedirectAttributes flashBox) {

        //CHẶN Ở EDIT - KO CHO XOÁ NẾU KO LÀ ADMIN ROLE != 1 KO CHO XOÁ
        Account acc = (Account) session.getAttribute("xAcc");
        if (acc == null){
            //chưa thèm login, học thuộc url, gõ thử xem vào đc ko, bắt về login
            return "redirect:/login";
        }
        if (acc.getRole() != 1) { //ko là admin, vẫn ở lại trang products, nhưng kèm báo lỗi
            flashBox.addFlashAttribute("editErrorMsg", "Bạn không có quyền");
            return "redirect:/products";
        }

        //TODO: select ra dòng cần edit, 1 dòng thôi
        List<Product> bag = new ArrayList<>();
        bag.add(new Product(101, "Coffee Ngọc Trinh", "Say Cafe như say Ngọc Trinh", 40_000));
        bag.add(new Product(201, "Coffee Highland", "Cà phê cao nguyên", 45_000));
        bag.add(new Product(301, "Coffee Passio", "Cà phê xứ Xavalo", 35_000));

        Product editedOne = bag.stream().filter(x -> x.getId() == edtId).findFirst().get();
        //cú pháp của biểu thức Lambda, và Stream API

        cage.addAttribute("edited", editedOne); //gửi ngược lại id đã xoá cho trang product, đúng chuẩn là read lại F5 lại trang products từ DB

        return "product-form";  //đổi sang trang detail
    }

    //hàm này phục vụ cho nút [Update] của màn hình product-form
    @PostMapping("/update")  //nối với baseURL ở đầu class đang có chữ /products
                                //để thành url full:  /products/update
    public String updateProduct(@ModelAttribute("edited") Product p,  Model box, RedirectAttributes boxFlash) {
        //TODO: gọi DB để xuống table

        //THẰNG NÀY ĐI KÈM THẰNG REDIRECT
        boxFlash.addFlashAttribute("xObj", p);
        return "redirect:/ngoctrinh";
    }
}
