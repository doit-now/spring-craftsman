package com.giaolang.ntcoffee.controller.web;

import com.giaolang.ntcoffee.entity.Product;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller //@ phục vụ req/res cho trả về trang web html
public class HomeController {

    @GetMapping({"/", "/index", "ngoctrinh"})
    public String home(Model model){
        //mỗi hàm trong Controller sẽ có 1 cái hộp tên là model thuộc class Model
        //hộp này chứa data, món đồ, bạn muốn gửi cho View, cho trang html
        //trong trang html sẽ lấy đồ trong hộp, đặt vào chỗ thích hợp thông qua các tag
        //model như cái ArrayList, add đồ vào..., nhớ đặt tên cho mỗi món đồ
        //bên trang get món đồ qua tên gọi
        //                         tên gọi-string    cho     món đồ gửi sang trang html-object
        model.addAttribute("owner", "Hoàng Ngọc Trinh");

        Product p = new Product(1, "Coffee Ngọc Trinh", "Say Cafe như say Ngọc Trinh", 40_000);
        model.addAttribute("aCup", p);

        return "index";  //return trang index.html đã đc mix, trộn, ko cần ghi html
    }
}
