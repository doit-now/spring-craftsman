package com.giaolang.dieudao.userservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v8/users")
public class UserController {

    @GetMapping
    public String getUsers() {
        return "The list of users...";  //TODO
    }
}
