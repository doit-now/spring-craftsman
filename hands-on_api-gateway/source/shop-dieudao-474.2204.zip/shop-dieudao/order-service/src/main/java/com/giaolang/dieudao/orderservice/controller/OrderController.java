package com.giaolang.dieudao.orderservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v8/orders")
public class OrderController {

    //chỉ làm 1 endpoint đơn giản trả về String, chưa làm JSON
    @GetMapping
    public String getOrders() {
        return "The list of orders...";  //TODO
    }
}
