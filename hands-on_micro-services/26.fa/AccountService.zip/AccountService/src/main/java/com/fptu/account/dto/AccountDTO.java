package com.fptu.account.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fptu.account.common.AccountStatus;
import java.util.Date;

public class AccountDTO {
    private Long accountId;
    private String fullName;
    private String email;
    private String phone;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date dateOfBirth;

    private Integer membershipPoints;
    private AccountStatus status;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date registeredDate;

    public AccountDTO() {}

    public Long getAccountId() { return accountId; }
    public void setAccountId(Long accountId) { this.accountId = accountId; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public Date getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(Date dateOfBirth) { this.dateOfBirth = dateOfBirth; }

    public Integer getMembershipPoints() { return membershipPoints; }
    public void setMembershipPoints(Integer membershipPoints) { this.membershipPoints = membershipPoints; }

    public AccountStatus getStatus() { return status; }
    public void setStatus(AccountStatus status) { this.status = status; }

    public Date getRegisteredDate() { return registeredDate; }
    public void setRegisteredDate(Date registeredDate) { this.registeredDate = registeredDate; }
}
