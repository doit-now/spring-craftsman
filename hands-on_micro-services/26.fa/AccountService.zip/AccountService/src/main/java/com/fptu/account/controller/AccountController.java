package com.fptu.account.controller;

import com.fptu.account.common.ApiStatus;
import com.fptu.account.common.AccountStatus;
import com.fptu.account.dto.AccountDTO;
import com.fptu.account.dto.ApiResponseDTO;
import com.fptu.account.dto.PageDTO;
import com.fptu.account.service.AccountService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    private final AccountService service;

    /** Nhận Service qua constructor. */
    public AccountController(AccountService service) {
        this.service = service;
    }

    /** API tạo mới dữ liệu. */
    @PostMapping
    public ResponseEntity<ApiResponseDTO> create(@RequestBody AccountDTO dto) {
        AccountDTO result = service.create(dto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponseDTO.of(ApiStatus.SUCCESS.getCode(), "Successful", result));
    }

    /** API cập nhật dữ liệu theo id. */
    @PutMapping("/{accountId}")
    public ResponseEntity<ApiResponseDTO> update(
            @PathVariable Long accountId,
            @RequestBody AccountDTO dto) {

        return ResponseEntity.status(HttpStatus.OK).body(
                ApiResponseDTO.of(ApiStatus.SUCCESS.getCode(), "Successful", service.update(accountId, dto))
        );
    }

    /** API lấy chi tiết theo id. */
    @GetMapping("/{accountId}")
    public ResponseEntity<ApiResponseDTO> getDetail(@PathVariable Long accountId) {
        return ResponseEntity.status(HttpStatus.OK).body(
                ApiResponseDTO.of(ApiStatus.SUCCESS.getCode(), "Successful", service.getById(accountId))
        );
    }

    /** API đổi trạng thái thay vì xóa vật lý. */
    @DeleteMapping("/{accountId}")
    public ResponseEntity<ApiResponseDTO> lock(@PathVariable Long accountId) {
        service.lock(accountId);
        return ResponseEntity.status(HttpStatus.OK).body(
                ApiResponseDTO.of(ApiStatus.SUCCESS.getCode(), "Account locked successfully", null)
        );
    }

    /** API lấy danh sách có phân trang và filter. */
    @GetMapping
    public ResponseEntity<ApiResponseDTO> getList(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) String fullName,
            @RequestParam(required = false) AccountStatus status) {

        return ResponseEntity.status(HttpStatus.OK).body(
                ApiResponseDTO.of(ApiStatus.SUCCESS.getCode(), "Successful",
                        service.getList(page, size, fullName, status))
        );
    }
}
