package com.fptu.account.service.impl;

import com.fptu.account.common.AccountStatus;
import com.fptu.account.common.ApiException;
import com.fptu.account.common.ApiStatus;
import com.fptu.account.dto.AccountDTO;
import com.fptu.account.dto.PageDTO;
import com.fptu.account.entity.Account;
import com.fptu.account.repository.AccountRepository;
import com.fptu.account.service.AccountService;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.http.HttpStatus;

import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

@Service
public class AccountServiceImpl implements AccountService {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

    private final AccountRepository repository;

    /** Nhận Repository qua constructor để thao tác với bảng accounts. */
    public AccountServiceImpl(AccountRepository repository) {
        this.repository = repository;
    }

    /** Tạo account mới với điểm, trạng thái và ngày đăng ký mặc định. */
    @Override
    public AccountDTO create(AccountDTO dto) {
        // Kiểm tra dữ liệu đầu vào trước khi lưu.
        validateCreate(dto);

        // Không cho phép email bị trùng.
        if (repository.existsByEmailIgnoreCase(dto.getEmail())) {
            throw new ApiException(HttpStatus.IM_USED, ApiStatus.DUPLICATE_EMAIL, "Email already exists");
        }

        // Chuyển DTO thành Entity để lưu database.
        Account account = toEntity(dto);

        // Gán các giá trị mặc định do server quản lý.
        account.setMembershipPoints(100);
        account.setStatus(AccountStatus.ACTIVE);
        account.setRegisteredDate(new Date());

        // Lưu Entity rồi chuyển kết quả về DTO.
        return toDTO(repository.save(account));
    }

    /** Cập nhật từng field được client gửi lên; field null sẽ giữ nguyên. */
    @Override
    public AccountDTO update(Long accountId, AccountDTO dto) {
        // Tìm account cần cập nhật.
        Account account = findAccount(accountId);

        if (dto.getFullName() != null) {
            if (dto.getFullName().isBlank() || dto.getFullName().length() > 100) {
                throw new ApiException(HttpStatus.NOT_ACCEPTABLE, ApiStatus.INVALID_DATA, "fullName is invalid");
            }
            account.setFullName(dto.getFullName().trim());
        }

        // Cho phép đổi email và kiểm tra không trùng account khác.
        if (dto.getEmail() != null) {
            if (!EMAIL_PATTERN.matcher(dto.getEmail()).matches() || dto.getEmail().length() > 100) {
                throw new ApiException(HttpStatus.NOT_ACCEPTABLE, ApiStatus.INVALID_DATA, "email is invalid");
            }
            if (repository.existsByEmailIgnoreCaseAndAccountIdNot(dto.getEmail(), accountId)) {
                throw new ApiException(HttpStatus.IM_USED, ApiStatus.DUPLICATE_EMAIL, "Email already exists");
            }
            account.setEmail(dto.getEmail().trim());
        }

        if (dto.getPhone() != null) {
            if (dto.getPhone().length() > 15) {
                throw new ApiException(HttpStatus.NOT_ACCEPTABLE, ApiStatus.INVALID_DATA, "phone is too long");
            }
            account.setPhone(blankToNull(dto.getPhone()));
        }

        if (dto.getMembershipPoints() != null) {
            if (dto.getMembershipPoints() < 0) {
                throw new ApiException(HttpStatus.NOT_ACCEPTABLE, ApiStatus.INVALID_DATA, "membershipPoints must be >= 0");
            }
            account.setMembershipPoints(dto.getMembershipPoints());
        }

        if (dto.getStatus() != null) {
            account.setStatus(dto.getStatus());
        }

        // Lưu thay đổi và trả DTO mới nhất.
        return toDTO(repository.save(account));
    }

    /** Lấy chi tiết một account theo id. */
    @Override
    public AccountDTO getById(Long accountId) {
        // Dùng helper findAccount để xử lý luôn trường hợp không tìm thấy.
        return toDTO(findAccount(accountId));
    }

    /** Khóa account bằng cách đổi status, không xóa record khỏi database. */
    @Override
    public void lock(Long accountId) {
        // Tìm account cần khóa.
        Account account = findAccount(accountId);

        // Soft delete: chỉ đổi trạng thái.
        account.setStatus(AccountStatus.LOCKED);
        repository.save(account);
    }

    /** Lấy danh sách account có phân trang và filter tùy chọn. */
    @Override
    public PageDTO getList(int page, int size, String fullName, AccountStatus status) {
        // Kiểm tra page và size trước khi query.
        validatePage(page, size);

        Pageable pageable = PageRequest.of(page, size, Sort.by("accountId").ascending());
        boolean hasName = fullName != null && !fullName.isBlank();
        Page<Account> result;

        // Chọn câu query phù hợp với filter client gửi.
        if (hasName && status != null) {
            result = repository.findByFullNameContainingIgnoreCaseAndStatus(fullName.trim(), status, pageable);
        } else if (hasName) {
            result = repository.findByFullNameContainingIgnoreCase(fullName.trim(), pageable);
        } else if (status != null) {
            result = repository.findByStatus(status, pageable);
        } else {
            result = repository.findAll(pageable);
        }

        // Chuyển danh sách Entity sang DTO.
        List<AccountDTO> content = result.getContent().stream()
                .map(this::toDTO)
                .toList();

        return new PageDTO(
                result.getSize(),
                result.getNumber(),
                result.getTotalPages(),
                result.getTotalElements(),
                result.isFirst(),
                result.isLast(),
                content
        );
    }

    /** Tìm Account Entity; nếu không có thì trả lỗi 404/status 4. */
    private Account findAccount(Long accountId) {
        return repository.findById(accountId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, ApiStatus.NOT_FOUND, "Account not found"));
    }

    /** Validate các field bắt buộc khi tạo account. */
    private void validateCreate(AccountDTO dto) {
        if (dto == null) throw new ApiException(HttpStatus.NOT_ACCEPTABLE, ApiStatus.INVALID_DATA, "Request body is required");

        if (dto.getFullName() == null || dto.getFullName().isBlank() || dto.getFullName().length() > 100) {
            throw new ApiException(HttpStatus.NOT_ACCEPTABLE, ApiStatus.INVALID_DATA, "fullName is required and max length is 100");
        }

        if (dto.getEmail() == null || !EMAIL_PATTERN.matcher(dto.getEmail()).matches()
                || dto.getEmail().length() > 100) {
            throw new ApiException(HttpStatus.NOT_ACCEPTABLE, ApiStatus.INVALID_DATA, "email is invalid");
        }

        if (dto.getPhone() != null && dto.getPhone().length() > 15) {
            throw new ApiException(HttpStatus.NOT_ACCEPTABLE, ApiStatus.INVALID_DATA, "phone max length is 15");
        }

        if (dto.getDateOfBirth() == null || !dto.getDateOfBirth().before(new Date())) {
            throw new ApiException(HttpStatus.NOT_ACCEPTABLE, ApiStatus.INVALID_DATA, "dateOfBirth must be in the past");
        }
    }

    /** Validate quy tắc phân trang của đề. */
    private void validatePage(int page, int size) {
        if (page < 0 || size < 1 || size > 100) {
            throw new ApiException(HttpStatus.NOT_ACCEPTABLE, ApiStatus.INVALID_DATA, "page must be >= 0 and size must be from 1 to 100");
        }
    }

    /** Đổi chuỗi rỗng thành null để lưu database gọn hơn. */
    private String blankToNull(String value) {
        if (value == null || value.isBlank()) return null;
        return value.trim();
    }

    /** Chuyển Account Entity thành AccountDTO để trả ra API. */
    private AccountDTO toDTO(Account account) {
        AccountDTO dto = new AccountDTO();
        dto.setAccountId(account.getAccountId());
        dto.setFullName(account.getFullName());
        dto.setEmail(account.getEmail());
        dto.setPhone(account.getPhone());
        dto.setDateOfBirth(account.getDateOfBirth());
        dto.setMembershipPoints(account.getMembershipPoints());
        dto.setStatus(account.getStatus());
        dto.setRegisteredDate(account.getRegisteredDate());
        return dto;
    }

    /**
     * Chuyển AccountDTO thành Account Entity để tạo mới.
     * Không set accountId vì database tự tăng.
     * Không set membershipPoints, status, registeredDate vì server tự gán trong create().
     */
    private Account toEntity(AccountDTO dto) {
        Account account = new Account();
        account.setFullName(dto.getFullName().trim());
        account.setEmail(dto.getEmail().trim());
        account.setPhone(blankToNull(dto.getPhone()));
        account.setDateOfBirth(dto.getDateOfBirth());
        return account;
    }
}
