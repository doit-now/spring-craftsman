package com.fptu.account.common;

public enum ApiStatus {
    SYSTEM_ERROR(0), SUCCESS(1), INVALID_DATA(2), DUPLICATE_EMAIL(3), NOT_FOUND(4), ACCOUNT_LOCKED(5);
    private final int code;
    ApiStatus(int code) { this.code = code; }
    public int getCode() { return code; }
}
