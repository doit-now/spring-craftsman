package com.fptu.account.common;

public enum AccountStatus {
    ACTIVE, LOCKED
}
