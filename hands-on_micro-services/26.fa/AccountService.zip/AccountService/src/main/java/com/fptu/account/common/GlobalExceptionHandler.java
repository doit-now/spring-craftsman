package com.fptu.account.common;
import com.fptu.account.dto.ApiResponseDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestControllerAdvice
public class GlobalExceptionHandler {
 /** Chuyển lỗi nghiệp vụ thành ApiResponseDTO. */
 @ExceptionHandler(ApiException.class)
 public ResponseEntity<ApiResponseDTO> handleApiException(ApiException ex) {
  return ResponseEntity.status(ex.getHttpStatus()).body(ApiResponseDTO.of(ex.getApiStatus().getCode(),ex.getMessage(),null));
 }
 /** Bắt lỗi ngoài dự kiến và trả HTTP 500. */
 @ExceptionHandler(Exception.class)
 public ResponseEntity<ApiResponseDTO> handleUnexpected(Exception ex) {
  return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ApiResponseDTO.of(ApiStatus.SYSTEM_ERROR.getCode(),"System error: "+ex.getMessage(),null));
 }
}
