package com.fptu.account.common;
import org.springframework.http.HttpStatus;
public class ApiException extends RuntimeException {
 private final HttpStatus httpStatus; private final ApiStatus apiStatus;
 /** Tạo exception gồm HTTP status và status nội tại. */
 public ApiException(HttpStatus httpStatus, ApiStatus apiStatus, String message) { super(message); this.httpStatus=httpStatus; this.apiStatus=apiStatus; }
 public HttpStatus getHttpStatus() { return httpStatus; } public ApiStatus getApiStatus() { return apiStatus; }
}
