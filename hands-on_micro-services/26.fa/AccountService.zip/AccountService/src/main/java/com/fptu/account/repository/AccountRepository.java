package com.fptu.account.repository;

import com.fptu.account.common.AccountStatus;
import com.fptu.account.entity.Account;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepository extends JpaRepository<Account, Long> {
    /** Kiểm tra email đã tồn tại hay chưa. */
    boolean existsByEmailIgnoreCase(String email);
    /** Kiểm tra email đã tồn tại hay chưa. */
    /** Kiểm tra email trùng với account khác khi update. */
    boolean existsByEmailIgnoreCaseAndAccountIdNot(String email, Long accountId);

    /** Tìm account theo một phần tên. */
    Page<Account> findByFullNameContainingIgnoreCase(String fullName, Pageable pageable);
    /** Lọc account theo status. */
    Page<Account> findByStatus(AccountStatus status, Pageable pageable);
    /** Lọc đồng thời theo tên và status. */
    Page<Account> findByFullNameContainingIgnoreCaseAndStatus(
            String fullName, AccountStatus status, Pageable pageable);
}
