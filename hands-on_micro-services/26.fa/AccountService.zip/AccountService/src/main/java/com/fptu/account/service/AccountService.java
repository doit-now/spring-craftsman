package com.fptu.account.service;
import com.fptu.account.common.AccountStatus; import com.fptu.account.dto.*;
public interface AccountService { AccountDTO create(AccountDTO dto); AccountDTO update(Long accountId,AccountDTO dto); AccountDTO getById(Long accountId); void lock(Long accountId); PageDTO getList(int page,int size,String fullName,AccountStatus status); }
