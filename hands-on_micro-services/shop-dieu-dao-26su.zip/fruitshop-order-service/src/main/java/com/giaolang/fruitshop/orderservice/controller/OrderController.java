package com.giaolang.fruitshop.orderservice.controller;

import com.giaolang.fruitshop.orderservice.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/orders")   //base url
public class OrderController {

    //tiêm - DI - Dependency Injection - thằng OrderService vào giúp controller trả về
    //có bao nhiêu cách tiêm chích: constructor, field, setter: @Autowire
    //Lombok còn trò construtor nhưng...
    @Autowired
    private OrderService orderService;

    @GetMapping("{id}")  //O1000
    public String getOrderById(@PathVariable("id") String orderId){
        //TODO: gọi OrderService | OrderRepo | JPA/Hibernate
        //lấy đc Order record id, date, total, cust id (FK trỏ bảng User)
        //gọi Userk API để xin fullname của cust id vừa lấy lên
        //API NÀY GỌI API BÊN 6969: RestTemplate, RestClient, OpenFeign...
        return orderService.getOrderById(orderId);
    }
}
