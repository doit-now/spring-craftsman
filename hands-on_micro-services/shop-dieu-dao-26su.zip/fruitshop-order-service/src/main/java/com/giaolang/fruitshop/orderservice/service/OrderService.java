package com.giaolang.fruitshop.orderservice.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Random;

//@Component
@Service
public class OrderService {

    //CRUD table Order...
    //TODO: chích tiêm OrderRepo...

    //chuẩn bị gọi User API ở bên 6969: RestTemplate, RestClient, OpenFeign
    private RestTemplate userAPI = new RestTemplate();

    //trả về dto Order...
    public String getOrderById(String orderId){
        //1. gọi OrderRepo để lấy ra đc Order record: id, date, total, cust_id FK
        //2. gọi sang User API ở 6969 để đưa FK cust_id và lấy về fullname
        //3. ráp fullname vừa lấy vào thông tin đơn hàng và return Order dto

        String custId = generateUserId();  //giả sử đơn hàng có mã khách hàng (FK) là CXX

        //truyền mã khách vào API bên User service để lấy fullname
        //                                                         /users/c099
        String custName = userAPI.getForObject("http://localhost:6969/api/v1/users/" + custId, String.class);

        //cuối hàm ráp và trả về thông tin đơn hàng - ORDER
        //ORDER: gồm mã đơn hàng | ngày/tháng | mã k/h-tên kh lấy từ gọi service User khác | total
        //       và chi tiết đơn hàng: mua Điều Đào với số lượng xxx...
        //Order: #0100 | To: #C099-HOANG NGOC TRINH | Total: 500.000đ | Details: [ Điều xxx, Đào xxx]

        String orderResponse = "Order: #" + orderId + " | To: "
                + custName + " | Total: 500.000đ | Details: [Điều xxx, Đào xxx]";

        return orderResponse;
    }

    //HÀM GENERATE RANDOM MÃ KHÁCH HÀNG, GIẢ LẬP CHO TÌNH HUỐNG MÃ KHÁCH HÀNG (FK) LẤY TỪ TABLE ORDER
    public String generateUserId() {

        //random mã k/h là con số từ 001...999 ghép với chữ C, ví dụ C100, C220
        return "C" + String.format("%03d", new Random().nextInt(999) + 1);
    }

}
