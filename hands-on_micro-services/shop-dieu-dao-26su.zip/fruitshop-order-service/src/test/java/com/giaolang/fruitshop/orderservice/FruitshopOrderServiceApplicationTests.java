package com.giaolang.fruitshop.orderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruitshopOrderServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
