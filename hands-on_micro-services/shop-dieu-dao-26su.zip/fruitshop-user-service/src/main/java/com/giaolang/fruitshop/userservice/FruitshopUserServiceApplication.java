package com.giaolang.fruitshop.userservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruitshopUserServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(FruitshopUserServiceApplication.class, args);
    }

}
