package com.giaolang.fruitshop.userservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Random;

@RestController
@RequestMapping("/api/v1/users") //base url
public class UserController {

    @GetMapping("{id}")  // ví dụ: /users/c001  /c0002   /s001  /s002
    public String getUserById(@PathVariable String id){
        //TODO: gọi UserService | UserRepo | gửi kèm user id muốn lấy từ table
        return "#" + id.toUpperCase() + "-" + generateName();
    }

    //HÀM GENERATE RANDOM TÊN USER, GIẢ LẬP CHO TÌNH HUỐNG TÊN KHÁCH HÀNG LẤY TỪ TABLE
    //ĐÚNG CHUẨN SẼ ĐỂ Ở CLASS HELPER BÊN PACKAGE utils/
    public String generateName() {

        Random random = new Random();
        List<String> lastNames = List.of("Nguyễn", "Lê", "Võ", "Phạm", "Trần");
        List<String> firstNames = List.of("An", "Bình", "Cường", "Dũng", "Giang");
        return lastNames.get(random.nextInt(lastNames.size())) + " " +
                firstNames.get(random.nextInt(firstNames.size()));
    }
}
