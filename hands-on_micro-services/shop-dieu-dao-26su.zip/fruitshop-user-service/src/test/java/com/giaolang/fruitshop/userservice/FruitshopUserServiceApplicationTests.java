package com.giaolang.fruitshop.userservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruitshopUserServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
