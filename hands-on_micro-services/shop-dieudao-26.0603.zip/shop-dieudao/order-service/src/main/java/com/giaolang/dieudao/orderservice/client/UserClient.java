package com.giaolang.dieudao.orderservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "user-service", url = "http://localhost:6969/api/v2/users")
public interface UserClient {
    //class này đóng vai vị khách client gọi tới User-Service qua api/v1/users
    //ta chỉ khai báo tên hàm map vào cái API bên User-Service, code hàm này tự SpringBoot lo như lúc ta chơi JpaRepository

    @GetMapping("{id}")
    public String getUserById(@PathVariable String id); //ko code nhen
                                          //tự SB sinh code để gọi user api
    //bên OrderService, OrderController
    //gọi:  UserClient client = new...
    //      client.getUserById("C999")
    //SB quay ngược: C999 ráp vào {id} và ráp ngược lên
    //http://localhost:6969/api/v1/users/C999 TỰ TẠO LỆNH GỌI API, NHẬN TRẢ VỀ, ĐẨY VÀO HÀM getUserById()
    //nhờ OpenFeign, ta gọi api từ xa như là gọi hàm nội bộ!!!!!
}
