package com.giaolang.dieudao.orderservice.controller;

import com.giaolang.dieudao.orderservice.client.UserClient;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v3/orders")
@RequiredArgsConstructor
public class OrderController {

    //tiêm thằng UserClient vào
    private final UserClient userClient;

    @GetMapping("{id}")
    public String getOrderById(@PathVariable("id") String id){
        //gọi thằng api  /api/v1/users/C999 -> #C999-Hoàng Ngọc Trinh
        //OpenFeign cho phép dev gọi API khác như là gọi hàm nội bộ
        //đề nghị dev tạo 1 interface (mùi giống JpaRepository<KeyType, EntityClass>) và Spring tự generate hàm cho mình
        String userName = userClient.getUserById("C999"); //xài OpenFeign như hàm bt
        return "ORDER #" + id + " | Customer: " + userName;
    }
}
