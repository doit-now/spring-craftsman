package com.giaolang.dieudao.userservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v2/users")
public class UserController {

    @GetMapping("{id}")  //đưa vào user-id, select table trả về id và name
    public String getUserById(@PathVariable String id){
        return "#" + id + "-Hoàng Ngọc Trinh";  //#C100-Hoàng Ngọc Trinh
    }
}
