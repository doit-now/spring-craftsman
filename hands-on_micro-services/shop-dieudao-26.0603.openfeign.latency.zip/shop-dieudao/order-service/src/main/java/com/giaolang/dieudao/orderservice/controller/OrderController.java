package com.giaolang.dieudao.orderservice.controller;

import com.giaolang.dieudao.orderservice.client.UserClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v6/orders")
public class OrderController {

    @Autowired
    private UserClient userClient;

    @GetMapping("{orderId}")
    public String getOrderById(@PathVariable String orderId) {

        //bấm giờ đo giây, có đúng mình chờ nhau, API của User Service trả về thành
        //công thì mới return "ORDER #" + orderId + " | CUSTOMER: " + userName;

        long start = System.currentTimeMillis(); //trước khi gọi API LOCK LẠI GIỜ

        String userName = userClient.getXXX("CUST-999"); //tua ngược vào trong interface mà xem
        //synchronous: api phải trả về đc chuỗi thì mình mới return đc!!!

        long end = System.currentTimeMillis(); //sau khi gọi API LOCK LẠI GIỜ
        //thằng này chỉ đc chạy sau 10s+

        //in hiệu số end - start ra số giây bị delay
        System.out.println("LATENCY (miliseconds): " + (end - start));

        return "ORDER #" + orderId + " | CUSTOMER: " + userName;
    } //http://localhost:2204/api/v6/orders/ODR9999
      //-> ORDER #ORD9999 | CUSTOMER: #CUST-999-HOANG NGOC TRINH
}
