package com.giaolang.dieudao.orderservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "user-service", url = "http://localhost:6969/api/v5/users/")
//~~~~ public interface UserRepository extends JpaRepository<User, long>
//     tự sinh hàm CRUD, hàm theo quy tắc đặt tên riêng...

public interface UserClient {

    //trong interface này bạn khai báo các lời gọi đến các API của user-service qua các hàm tự đặt tên
    //lát hồi Spring Boot kết hợp với thư viện OpenFeign sẽ tự sinh ra lời gọi, HTTP request
    //gửi tới user-service, để yc user-service API trả về JSON, String...
    //và gửi lại cho nơi gọi API ở OrderController, hoặc OrderService

    //viết hàm gọi API của bên kia y chang như làm 1 endpoint API
    @GetMapping("{xxx}")
    public String getXXX(@PathVariable String xxx);
    //OpenFeign chơi trò tua ngược...
}
