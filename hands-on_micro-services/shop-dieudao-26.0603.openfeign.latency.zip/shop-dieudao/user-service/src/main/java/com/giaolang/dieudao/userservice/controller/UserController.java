package com.giaolang.dieudao.userservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v5/users")  //base url
public class UserController {

    //API endpoint trả về tên khách hàng dựa trên id khách hàng
    //mình trả full: id-fullname - tạm thời hardcoded
    //đúng chuẩn trả về 1 DTO
    @GetMapping("{userId}")
    public String getUserById(@PathVariable String userId) throws InterruptedException {

        //TODO: lấy db lên...
        //GIẢ BỘ get user id bị delay, hoặc chậm, lag, thuật toán cùi, để nó return lâu cỡ 10s
        Thread.sleep(6868);  //1000 ~ 1 giây 1 second

        return userId + "-HOÀNG NGỌC TRINH";
    }  //http://localhost:6969/api/v5/users/C999 -> C999-HOÀNG NGỌC TRINH

}
